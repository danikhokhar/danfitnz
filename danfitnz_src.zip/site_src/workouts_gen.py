"""Generates the exercise library (all exercises, by muscle) and a large workout library
(muscle x equipment x level, stretches, HIIT, weekly splits) from the exercise database."""
import re, json, html

E = lambda s: html.escape(str(s), quote=True)

# Well-known exercises first (rough popularity order); everything else is scored by heuristics.
TOP = """Pushups Bodyweight_Squat Plank Goblet_Squat Dumbbell_Bench_Press Barbell_Squat Barbell_Deadlift Romanian_Deadlift
Pullups Wide-Grip_Lat_Pulldown Seated_Cable_Rows One-Arm_Dumbbell_Row Bent_Over_Barbell_Row Bent_Over_Two-Dumbbell_Row
Barbell_Bench_Press_-_Medium_Grip Incline_Dumbbell_Press Dumbbell_Shoulder_Press Standing_Military_Press Side_Lateral_Raise
Dumbbell_Bicep_Curl Hammer_Curls Barbell_Curl Triceps_Pushdown Bench_Dips Dips_-_Triceps_Version Standing_Dumbbell_Triceps_Extension
Dumbbell_Lunges Bodyweight_Walking_Lunge Split_Squat_with_Dumbbells Leg_Press Lying_Leg_Curls Leg_Extensions Standing_Calf_Raises
Barbell_Hip_Thrust Butt_Lift_Bridge Single_Leg_Glute_Bridge Glute_Kickback Crunches Reverse_Crunch Dead_Bug Russian_Twist
Flat_Bench_Lying_Leg_Raise Hanging_Leg_Raise Mountain_Climbers Jumping_Jacks Burpee Kettlebell_One-Legged_Deadlift
One-Arm_Kettlebell_Swings Kettlebell_Goblet_Squat Two-Arm_Kettlebell_Row Kettlebell_Sumo_High_Pull Inverted_Row
Incline_Push-Up Decline_Push-Up Push-Up_Wide Dumbbell_Flyes Incline_Dumbbell_Flyes Cable_Crossover Butterfly
Face_Pull Reverse_Flyes Front_Dumbbell_Raise Arnold_Dumbbell_Press Upright_Barbell_Row Dumbbell_Shrug Barbell_Shrug
Concentration_Curls EZ-Bar_Curl Close-Grip_Barbell_Bench_Press Lying_Triceps_Press Tricep_Dumbbell_Kickback
Stiff-Legged_Dumbbell_Deadlift Hack_Squat Front_Barbell_Squat Sumo_Deadlift Good_Morning Hyperextensions_Back_Extensions
Seated_Calf_Raise Box_Jump_Multiple_Response Squats_-_With_Bands Band_Pull_Apart Lateral_Raise_-_With_Bands
Chair_Squat Step-up_with_Knee_Raise Dumbbell_Step_Ups Superman Air_Bike Cross-Body_Crunch Oblique_Crunches_-_On_The_Floor
Side_Bridge Plank Ab_Roller Cable_Crunch Kettlebell_Figure_8 Kettlebell_Pistol_Squat Kettlebell_Thruster Kettlebell_Windmill""".split()
RANK = {k: n for n, k in enumerate(TOP)}
BAD_WORDS = ["smith", "leverage", "suspended", "bosu", "physioball", "exercise_ball", "rocking", "anti-gravity", "atlas",
             "sled", "yoke", "drill", "around_the", "pirate", "clock", "behind_the_neck", "bench_jump", "rear_pull-up", "middle_back_shrug", "tire", "log_", "chain", "reverse_band", "board", "rack_pull", "speed", "jerk", "snatch", "clean"]


def score(i, x):
    if i in RANK: return RANK[i]
    s = 200 + len(i) * 1.5
    if x.get("mechanic") == "compound": s -= 25
    s += {"beginner": 0, "intermediate": 20, "expert": 80}.get(x.get("level"), 30)
    if any(w in i.lower() for w in BAD_WORDS): s += 120
    if x.get("category") not in ("strength", "stretching", "plyometrics", "cardio"): s += 80
    if len(x.get("images") or []) < 2: s += 60
    return s


MUSCLES = ["abdominals", "abductors", "adductors", "biceps", "calves", "chest", "forearms", "glutes", "hamstrings",
           "lats", "lower back", "middle back", "neck", "quadriceps", "shoulders", "traps", "triceps"]
MUSCLE_NAME = {"abdominals": "Abs", "lower back": "Lower Back", "middle back": "Upper & Mid Back", "quadriceps": "Quads", "lats": "Lats"}
mname = lambda m: MUSCLE_NAME.get(m, m.title())
mslug = lambda m: re.sub(r"[^a-z0-9]+", "-", mname(m).lower()).strip("-")

GROUPS = {  # slug: (name, primary muscles, slot plan for selection diversity)
    "chest": ("Chest", ["chest"], [["chest"]] * 5),
    "back": ("Back", ["lats", "middle back", "lower back", "traps"], [["lats"], ["middle back"], ["lats", "middle back"], ["lower back"], ["traps", "middle back"], ["lats", "middle back"]]),
    "shoulders": ("Shoulders", ["shoulders"], [["shoulders"]] * 5 + [["traps"]]),
    "arms": ("Arms", ["biceps", "triceps", "forearms"], [["biceps"], ["triceps"], ["biceps"], ["triceps"], ["biceps", "forearms"], ["triceps"]]),
    "biceps-triceps": None,
    "legs": ("Legs", ["quadriceps", "hamstrings", "glutes", "calves"], [["quadriceps"], ["hamstrings"], ["quadriceps", "glutes"], ["hamstrings", "glutes"], ["calves"], ["quadriceps"]]),
    "glutes": ("Glutes", ["glutes", "hamstrings", "abductors"], [["glutes"], ["glutes"], ["hamstrings", "glutes"], ["glutes", "abductors"], ["glutes"]]),
    "abs": ("Abs & Core", ["abdominals"], [["abdominals"]] * 6),
    "full-body": ("Full Body", None, [["quadriceps"], ["chest"], ["lats", "middle back"], ["hamstrings", "glutes"], ["shoulders"], ["abdominals"]]),
    "upper-body": ("Upper Body", None, [["chest"], ["lats", "middle back"], ["shoulders"], ["middle back", "lats"], ["biceps"], ["triceps"]]),
    "lower-body": ("Lower Body", None, [["quadriceps"], ["hamstrings"], ["glutes"], ["quadriceps", "glutes"], ["calves"], ["abdominals"]]),
}
GROUPS.pop("biceps-triceps")
EQUIP = {  # slug: (label, allowed equipment, place, gear keys)
    "bodyweight": ("Bodyweight", {"body only"}, "at home with no equipment", ["mat", "pullupbar"]),
    "dumbbell": ("Dumbbell", {"dumbbell"}, "at home or in the gym with a pair of dumbbells", ["dumbbells", "bench"]),
    "kettlebell": ("Kettlebell", {"kettlebells"}, "with one kettlebell", ["kettlebell"]),
    "resistance-band": ("Resistance Band", {"bands"}, "anywhere with a set of resistance bands", ["bands", "tubebands"]),
    "gym": ("Gym", {"barbell", "cable", "machine", "dumbbell", "e-z curl bar"}, "in a commercial gym", ["gymbag", "gloves"]),
}
FILL = {"bodyweight": set(), "dumbbell": {"body only"}, "kettlebell": {"body only"}, "resistance-band": {"body only"}, "gym": {"body only"}}
LEVELS = {"beginner": ("Beginners", {"beginner"}, 5), "intermediate": ("Intermediate", {"beginner", "intermediate"}, 6)}


def fam(i):  # crude "same movement" key to avoid near-duplicates
    t = re.sub(r"(_-_.*|_with.*|_on.*|alternate_|alternating_|one-arm_|single-arm_|seated_|standing_|incline_|decline_|lying_|close-grip_|wide-grip_)", "", i.lower())
    return t.split("_")[-1].rstrip("s")[:5]


def is_hold(i, x):
    t = i.lower()
    return any(w in t for w in ["plank", "bridge", "hold", "wall_sit", "side_bridge", "superman", "hollow"]) and "glute_bridge" not in t and "butt_lift" not in t


def pick(pool, slots, n):
    chosen, fams = [], set()
    for sl in slots[:n] + slots * 2:
        if len(chosen) >= n: break
        for i, x in pool:
            if i in chosen or fam(i) in fams: continue
            if (x.get("primaryMuscles") or ["?"])[0] in sl:
                chosen.append(i); fams.add(fam(i)); break
    for i, x in pool:  # top up if slots couldn't be filled
        if len(chosen) >= n: break
        if i not in chosen and fam(i) not in fams: chosen.append(i); fams.add(fam(i))
    return chosen


def run(G):
    EXDATA, page, follow_box, bc, BASE, EXTRA_URLS, grid, A, OUT = (G[k] for k in ["EXDATA", "page", "follow_box", "bc", "BASE", "EXTRA_URLS", "grid", "A", "OUT"])
    pages, REELS, tcase, exslug, slugify = G["pages"], G["REELS"], G["tcase"], G["exslug"], G["slugify"]
    import exmedia
    have = exmedia.build_media(EXDATA, f"{OUT}/exercises")
    EX = {i: x for i, x in EXDATA.items() if i in have}
    for x in EX.values(): x["equipment"] = x.get("equipment") or "body only"
    ranked = sorted(EX.items(), key=lambda t: score(*t))

    def card(i, label=None, reps=None):
        x = EX[i]
        return (f'<a class="excard" href="/exercises/{exslug(i)}/" data-eq="{E(x.get("equipment") or "none")}"><div class="exfig">'
                f'<img src="/exercises/{i}_s.webp" alt="{E(x["name"])} animated demonstration" width="360" height="240" loading="lazy"></div>'
                f'<b>{E(label or x["name"])}</b>' + (f'<span class="n">{E(reps)}</span>' if reps else "") +
                f'<small>{E(", ".join(mname(m) for m in x.get("primaryMuscles") or []))}</small></a>')
    G["excard"] = lambda label, reps, i: card(i, label, reps) if i in EX else ""

    # ---------------- workout library ----------------
    WK = []  # dicts: slug, title, group, equip, level, items[(id, reps)], kind

    def reps_for(i, lvl, kind):
        x = EX[i]
        if kind == "stretch": return "30 sec" + (" / side" if any(w in i.lower() for w in ["one", "single", "side", "lunge", "kneeling", "lying"]) else "")
        if kind == "hiit": return "40s on / 20s off"
        if is_hold(i, x): return "3 × 30 sec" if lvl == "beginner" else "3 × 45 sec"
        if (x.get("primaryMuscles") or [""])[0] in ("abdominals", "calves", "forearms"): return "3 × 15" if lvl == "beginner" else "4 × 15"
        uni = any(w in i.lower() for w in ["one-arm", "one_arm", "single", "one-legged", "alternate", "lunge", "split_squat", "step"])
        base = "3 × 10" if lvl == "beginner" else "4 × 8–12"
        return base + (" / side" if uni else "")

    for gs, (gname, gm, slots) in GROUPS.items():
        for es, (elabel, eqset, place, gear) in EQUIP.items():
            prev = []
            for ls, (llabel, lvset, n) in LEVELS.items():
                ok_eq = eqset | FILL[es]
                pool = [(i, x) for i, x in ranked if (x.get("equipment") or "") in ok_eq and x.get("level") in ("beginner", "intermediate")
                        and x.get("category") in ("strength", "powerlifting", "plyometrics") and (gm is None or (x.get("primaryMuscles") or ["?"])[0] in gm)]
                if ls == "beginner":
                    pool = [p for p in pool if p[1]["level"] == "beginner"] + [p for p in pool if p[1]["level"] != "beginner"]
                else:
                    pool = [p for p in pool if p[0] not in prev] + [p for p in pool if p[0] in prev]
                if es != "bodyweight":  # keep the namesake equipment dominant
                    main = [p for p in pool if (p[1].get("equipment") or "") in eqset]
                    pool = main + [p for p in pool if p not in main]
                ch = pick(pool, slots, n)
                if len(ch) < 4: continue
                if prev and len(set(ch) - set(prev)) < 3: continue
                prev = ch
                title = f"{elabel} {gname} Workout for {llabel}"
                WK.append(dict(slug=f"{es}-{gs}-workout-{ls}", title=title, group=gs, gname=gname, equip=es, elabel=elabel, place=place,
                               gear=gear, level=ls, items=[(i, reps_for(i, ls, "strength")) for i in ch], kind="strength"))
    # stretching routines
    STR = {"full-body": ("Full Body", None), "lower-back": ("Lower Back", ["lower back"]), "hamstrings": ("Hamstring", ["hamstrings"]),
           "hips-glutes": ("Hip & Glute", ["glutes", "abductors", "adductors"]), "shoulders-chest": ("Shoulder & Chest", ["shoulders", "chest"]),
           "quads-calves": ("Quad & Calf", ["quadriceps", "calves"]), "neck-upper-back": ("Neck & Upper Back", ["neck", "traps", "middle back", "lats"])}
    stretches = [(i, x) for i, x in ranked if x.get("category") == "stretching" and x.get("equipment") in ("body only", "other") and i not in ("Frog_Hops", "Superman")]
    for ss, (sname, sm) in STR.items():
        pool = [(i, x) for i, x in stretches if sm is None or (x.get("primaryMuscles") or ["?"])[0] in sm]
        ch = []
        seen = set()
        for i, x in pool:
            m = (x.get("primaryMuscles") or ["?"])[0]
            if sm is None and m in seen: continue
            ch.append(i); seen.add(m)
            if len(ch) >= (8 if sm is None else 6): break
        if len(ch) >= 4:
            WK.append(dict(slug=f"{ss}-stretches", title=f"{sname} Stretches: {len(ch)}-Move Routine", group="stretching", gname=f"{sname} stretches",
                           equip="bodyweight", elabel="Bodyweight", place="at home with no equipment", gear=["mat"], level="beginner",
                           items=[(i, reps_for(i, "beginner", "stretch")) for i in ch], kind="stretch"))
    # HIIT / fat-burning circuits
    HIIT = {"beginner": "Mountain_Climbers Bodyweight_Squat Incline_Push-Up Star_Jump Bodyweight_Walking_Lunge Fast_Skipping Dead_Bug Plank",
            "intermediate": "Freehand_Jump_Squat Pushups Mountain_Climbers Split_Jump Lateral_Bound Knee_Tuck_Jump Russian_Twist Star_Jump"}
    for ls, (llabel, lvset, n) in LEVELS.items():
        ch = [i for i in HIIT[ls].split() if i in EX]
        WK.append(dict(slug=f"hiit-fat-burning-workout-{ls}", title=f"HIIT Fat-Burning Workout for {llabel} (No Equipment)", group="hiit", gname="HIIT",
                       equip="bodyweight", elabel="Bodyweight", place="at home with no equipment", gear=["mat", "jumprope"], level=ls,
                       items=[(i, reps_for(i, ls, "hiit")) for i in ch], kind="hiit"))

    BYSLUG = {w["slug"]: w for w in WK}

    def est_min(w):
        if w["kind"] == "stretch": return max(5, round(len(w["items"]) * 0.75))
        if w["kind"] == "hiit": return 3 * len(w["items"]) + 6
        sets = sum(int(re.match(r"(\d)", r).group(1)) for _, r in w["items"])
        return round(sets * 1.75 + 5)

    # weekly splits that link the workouts together
    SPLITS = []
    for es, (elabel, *_r) in EQUIP.items():
        for ls in LEVELS:
            fb, up, lo = (f"{es}-{g}-workout-{ls}" for g in ("full-body", "upper-body", "lower-body"))
            if fb in BYSLUG:
                SPLITS.append(dict(slug=f"3-day-{es}-full-body-plan-{ls}", title=f"3-Day {elabel} Full Body Plan for {LEVELS[ls][0]}",
                                   days=[("Monday", fb), ("Wednesday", fb), ("Friday", fb)], rest="Walk 8–10k steps on the other days.", level=ls, equip=es))
            if up in BYSLUG and lo in BYSLUG:
                SPLITS.append(dict(slug=f"4-day-{es}-upper-lower-split-{ls}", title=f"4-Day {elabel} Upper/Lower Split for {LEVELS[ls][0]}",
                                   days=[("Monday", up), ("Tuesday", lo), ("Thursday", up), ("Friday", lo)], rest="Rest or walk on Wednesday and the weekend.", level=ls, equip=es))
            ppl = [f"{es}-{g}-workout-{ls}" for g in ("chest", "back", "legs", "shoulders", "arms")]
            if all(p in BYSLUG for p in ppl):
                SPLITS.append(dict(slug=f"5-day-{es}-body-part-split-{ls}", title=f"5-Day {elabel} Body-Part Split for {LEVELS[ls][0]}",
                                   days=list(zip(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], ppl)), rest="Rest at the weekend; keep your steps up.", level=ls, equip=es))

    reel_used = {}
    for r in REELS:
        if r["type"] == "workout":
            for a, b in r["items"]:
                i = G["EXMAP"].get(a)
                if i: reel_used.setdefault(i, set()).add((slugify(tcase(" ".join(r["title"]))), tcase(" ".join(r["title"]))))
    used_in = {}
    for w in WK:
        for i, _ in w["items"]: used_in.setdefault(i, []).append(w)

    def splink(s): return f'<a href="/workouts/{s["slug"]}/">{E(s["title"])}<small>{len(s["days"])} days a week</small></a>'
    def wlink(w): return f'<a href="/workouts/{w["slug"]}/">{E(w["title"])}<small>{len(w["items"])} exercises · about {est_min(w)} min · {E(w["elabel"])}</small></a>'

    LVL_TXT = {"beginner": "Use a weight you could lift for 2–3 more reps than written. Rest 60–90 seconds between sets.",
               "intermediate": "Pick a weight that leaves about 1–2 reps in the tank on the last set. Rest 60–120 seconds on big lifts, 45–60 seconds on smaller ones."}
    for w in WK:
        rows = "".join(f"<tr><td>{k + 1}. <a href='/exercises/{exslug(i)}/'>{E(EX[i]['name'])}</a></td><td class='n'>{E(r)}</td></tr>" for k, (i, r) in enumerate(w["items"]))
        cards = "".join(card(i, EX[i]["name"], r) for i, r in w["items"])
        how = "".join(f"<h3>{k + 1}. {E(EX[i]['name'])}</h3><p>{E(' '.join((EX[i].get('instructions') or [''])[:2]))}</p><p><a href='/exercises/{exslug(i)}/'>Full step-by-step guide →</a></p>" for k, (i, _) in enumerate(w["items"]))
        musc = sorted({mname(m) for i, _ in w["items"] for m in EX[i].get("primaryMuscles") or []})
        if w["kind"] == "stretch":
            lead = f"A gentle {len(w['items'])}-move {w['gname'].lower()} routine you can do {w['place']}. Hold each stretch, breathe slowly and never force it into pain. Great after a workout, after sitting all day, or before bed."
            plan = "<h2>How to do this routine</h2><ul><li>Hold each stretch for 30 seconds (each side where shown) and breathe slowly.</li><li>Go to mild tension only — a stretch should never feel sharp.</li><li>Do it 3–7 days a week; 2 rounds if you have time.</li></ul>"
        elif w["kind"] == "hiit":
            lead = f"A no-equipment HIIT circuit for {LEVELS[w['level']][0].lower()} that you can do at home in about {est_min(w)} minutes. Work for 40 seconds, rest 20 seconds, move to the next exercise, and repeat the whole circuit {'2' if w['level'] == 'beginner' else '3'} times."
            plan = f"<h2>How to do the circuit</h2><ul><li>Warm up for 5 minutes (march on the spot, arm circles, easy squats).</li><li>40 seconds work, 20 seconds rest, then the next move.</li><li>Rest 1–2 minutes between rounds. Do {'2' if w['level'] == 'beginner' else '3'} rounds, 2–3 times a week.</li><li>Lower-impact option: step instead of jumping.</li></ul>"
        else:
            lead = (f"A {w['elabel'].lower()} {w['gname'].lower()} workout for {LEVELS[w['level']][0].lower()} that you can do {w['place']}. "
                    f"{len(w['items'])} exercises, about {est_min(w)} minutes, targeting {', '.join(musc[:5]).lower()}.")
            plan = (f"<h2>How to do this workout</h2><ul><li>Warm up for 5 minutes: brisk walk or easy cardio, then one light set of the first exercise.</li>"
                    f"<li>Do the exercises in order. Finish all sets of one before moving on.</li><li>{LVL_TXT[w['level']]}</li>"
                    f"<li>Do this workout 1–2 times a week{' (or 2–3 times for full-body sessions)' if w['group'] == 'full-body' else ''}, with at least one rest day before training the same muscles again.</li></ul>"
                    "<h2>How to progress</h2><p>When you can do every set with good form at the top of the rep range, add one rep per set the next week, or a small amount of weight (1–2.5 kg). Progress slowly — consistent small jumps beat big ones. For fat loss, pair this with a small calorie deficit and around 1.6–2 g of protein per kg of body weight.</p>")
        rel = [x for x in WK if x is not w and ((x["group"] == w["group"] and x["level"] == w["level"]) or (x["equip"] == w["equip"] and x["level"] == w["level"] and x["kind"] == w["kind"]))][:8]
        spl = [s for s in SPLITS if any(d[1] == w["slug"] for d in s["days"])]
        gear = [k for k in w["gear"] if k in A]
        body = (f"<p class='meta'><a href='/workouts/'>Workouts</a> · <a href='/workouts/#{E(w['group'])}'>{E(GROUPS.get(w['group'], (w['gname'],))[0])}</a></p>"
                f"<h1>{E(w['title'])}</h1><p class='lead'>{E(lead)}</p>"
                f"<table><tr><td>Level</td><td>{E(w['level'].title())}</td></tr><tr><td>Equipment</td><td>{E(w['elabel'] if w['equip'] != 'bodyweight' else 'None (bodyweight)')}</td></tr>"
                f"<tr><td>Time</td><td>About {est_min(w)} minutes</td></tr><tr><td>Muscles</td><td>{E(', '.join(musc))}</td></tr></table>"
                f"<h2>The workout</h2><table><tr><th>Exercise</th><th>Sets / reps</th></tr>{rows}</table>"
                f"<h2>See each exercise</h2><div class='exgrid'>{cards}</div><p class='meta'>Animations made from real photos (free-exercise-db, public domain). Tap any exercise for full instructions.</p>"
                f"{plan}<h2>Exercise notes</h2>{how}"
                + (f"<h2>Weekly plans that use this workout</h2><div class='grid'>{''.join(splink(s) for s in spl)}</div>" if spl else "")
                + (f"<h2>More workouts like this</h2><div class='grid'>{''.join(wlink(x) for x in rel)}</div>" if rel else "")
                + (f"<h2>Gear for this workout</h2>{grid(gear)}" if gear else "")
                + "<p class='note'>Stop if anything hurts (sharp pain is different from muscle burn). If you have an injury or health condition, check with your GP or a physio first.</p>" + follow_box())
        url = f"{BASE}/workouts/{w['slug']}/"
        sch = [{"@type": "HowTo", "name": w["title"], "description": lead, "totalTime": f"PT{est_min(w)}M",
                "image": [f"{BASE}/exercises/{w['items'][0][0]}_0.jpg"],
                "step": [{"@type": "HowToStep", "position": k + 1, "name": EX[i]["name"], "text": f"{EX[i]['name']}: {r}.", "url": f"{BASE}/exercises/{exslug(i)}/", "image": f"{BASE}/exercises/{i}_0.jpg"} for k, (i, r) in enumerate(w["items"])]},
               bc([("Home", BASE + "/"), ("Workouts", f"{BASE}/workouts/"), (w["title"], url)])]
        page(f"workouts/{w['slug']}/", f"{w['title']} | danfitnz", lead[:158], body, sch, "article")
        EXTRA_URLS.append(f"workouts/{w['slug']}/")

    for s in SPLITS:
        days = "".join(f"<tr><td>{d}</td><td><a href='/workouts/{ws}/'>{E(BYSLUG[ws]['title'])}</a></td></tr>" for d, ws in s["days"])
        lead = f"A simple {len(s['days'])}-day-a-week {EQUIP[s['equip']][0].lower()} training plan for {LEVELS[s['level']][0].lower()}. Each day links to a full workout with sets, reps and animated exercise demos."
        body = (f"<p class='meta'><a href='/workouts/'>Workouts</a> · <a href='/workouts/#plans'>Weekly plans</a></p><h1>{E(s['title'])}</h1><p class='lead'>{E(lead)}</p>"
                f"<h2>Your week</h2><table><tr><th>Day</th><th>Workout</th></tr>{days}</table><p><b>{E(s['rest'])}</b></p>"
                "<h2>How to run this plan</h2><ul><li>Follow it for 8–12 weeks before changing it.</li><li>Write down your weights and reps, and try to beat them a little each week.</li><li>Sleep 7–9 hours and eat enough protein; for fat loss keep a small calorie deficit.</li><li>Every 6–8 weeks, take an easier week with lighter weights.</li></ul>"
                + "".join(f"<h2>{d}: {E(BYSLUG[ws]['title'])}</h2><div class='exgrid'>{''.join(card(i, EX[i]['name'], r) for i, r in BYSLUG[ws]['items'])}</div>" for d, ws in s['days'][:len(set(x for _, x in s['days']))])
                + "<p><a href='/tools/plan-builder/'>Build a personal 7-day meal and workout plan →</a></p>" + follow_box())
        page(f"workouts/{s['slug']}/", f"{s['title']} | danfitnz", lead[:158], body,
             [bc([("Home", BASE + "/"), ("Workouts", f"{BASE}/workouts/"), (s["title"], f"{BASE}/workouts/{s['slug']}/")])], "article")
        EXTRA_URLS.append(f"workouts/{s['slug']}/")

    # workouts hub (replaces the simple one)
    vids = [p for p in pages if p["hub"] == "workouts"]
    sec = ""
    order = list(GROUPS) + ["hiit", "stretching"]
    names = {**{g: v[0] for g, v in GROUPS.items()}, "hiit": "HIIT & fat burning", "stretching": "Stretching & mobility"}
    chips = "<div class='chips2'>" + "".join(f"<a class='chip' href='#{g}'>{E(names[g])}</a>" for g in order) + "<a class='chip' href='#plans'>Weekly plans</a></div>"
    for g in order:
        ws = [w for w in WK if w["group"] == g]
        if ws: sec += f"<h2 id='{g}'>{E(names[g])} workouts</h2><div class='grid'>{''.join(wlink(w) for w in ws)}</div>"
    sec += "<h2 id='plans'>Weekly training plans</h2><div class='grid'>" + "".join(f"<a href='/workouts/{s['slug']}/'>{E(s['title'])}<small>{len(s['days'])} days a week</small></a>" for s in SPLITS) + "</div>"
    vgrid = "".join(f'<a href="/{p["path"]}">{E(p["name"])}<small>From our videos</small></a>' for p in vids)
    hd = f"{len(WK)} free workouts with sets, reps and animated exercise demos — bodyweight, dumbbell, kettlebell, band and gym workouts for every muscle, plus HIIT, stretching and {len(SPLITS)} weekly plans."
    page("workouts/", "Free Workouts: Home & Gym Workout Library | danfitnz", hd[:158],
         f"<h1>Workout library</h1><p class='lead'>{E(hd)}</p>{chips}{sec}<h2>From our videos</h2><div class='grid'>{vgrid}</div>{follow_box()}",
         [{"@type": "CollectionPage", "name": "Workout library", "url": f"{BASE}/workouts/", "description": hd},
          {"@type": "ItemList", "itemListElement": [{"@type": "ListItem", "position": k + 1, "url": f"{BASE}/workouts/{w['slug']}/", "name": w["title"]} for k, w in enumerate(WK)]},
          bc([("Home", BASE + "/"), ("Workouts", f"{BASE}/workouts/")])])

    # ---------------- exercise library ----------------
    EQUIP_GEAR = {"dumbbell": ["dumbbells", "bench"], "kettlebells": ["kettlebell"], "bands": ["bands", "tubebands"], "body only": ["mat", "pullupbar"],
                  "barbell": ["platebarbell", "squatrack"], "cable": ["tubebands", "doorbar"], "machine": ["gymbag", "gloves"], "other": ["mat"]}
    bym = {}
    for i, x in ranked: bym.setdefault((x.get("primaryMuscles") or ["other"])[0], []).append(i)
    for i, x in EX.items():
        sl = exslug(i)
        steps = "".join(f"<li>{E(t)}</li>" for t in x.get("instructions") or [])
        musc = ", ".join(mname(m) for m in x.get("primaryMuscles") or []); sec_m = ", ".join(mname(m) for m in x.get("secondaryMuscles") or [])
        pm = (x.get("primaryMuscles") or ["other"])[0]
        sim = [j for j in bym.get(pm, []) if j != i and EX[j].get("equipment") == x.get("equipment")][:6]
        if len(sim) < 6: sim += [j for j in bym.get(pm, []) if j != i and j not in sim][:6 - len(sim)]
        wks = used_in.get(i, [])[:8]; rv = sorted(reel_used.get(i, set()))
        gear = [k for k in EQUIP_GEAR.get(x.get("equipment") or "other", []) if k in A]
        body = (f"<p class='meta'><a href='/exercises/'>Exercise library</a> · <a href='/exercises/muscle/{mslug(pm)}/'>{E(mname(pm))}</a></p><h1>How to Do {E(x['name'])}</h1>"
                f"<p class='lead'>Step-by-step instructions, muscles worked and workouts that use the {E(x['name'].lower())}.</p>"
                f"<div class='exfig' style='max-width:600px'><img src='/exercises/{i}.webp' alt='{E(x['name'])} animated demonstration from start to end position' width='600' height='400'></div>"
                f"<table><tr><td>Main muscles</td><td>{E(musc or '—')}</td></tr><tr><td>Also works</td><td>{E(sec_m or '—')}</td></tr><tr><td>Equipment</td><td>{E((x.get('equipment') or 'none').title())}</td></tr><tr><td>Level</td><td>{E((x.get('level') or '').title())}</td></tr><tr><td>Type</td><td>{E((x.get('category') or '').title())}</td></tr></table>"
                f"<h2>How to do it</h2><ol>{steps}</ol>"
                "<h2>Form tips</h2><ul><li>Start light and own the movement before adding weight.</li><li>Control the lowering phase — don't drop into it.</li><li>Keep breathing; exhale on the hardest part.</li><li>Stop if you feel sharp pain (different from muscle burn).</li></ul>"
                + (f"<h2>Workouts with this exercise</h2><div class='grid'>{''.join(wlink(w) for w in wks)}{''.join(f'<a href=/workouts/{a}/>{E(b)}<small>From our videos</small></a>' for a, b in rv)}</div>" if wks or rv else "<p><a href='/workouts/'>Browse all workouts →</a></p>")
                + f"<h2>Similar exercises</h2><div class='exgrid'>{''.join(card(j) for j in sim)}</div>"
                + (f"<h2>Gear for this exercise</h2>{grid(gear)}" if gear else "")
                + "<p class='meta'>Exercise photos and instructions: free-exercise-db (public domain). Animation made from the real start and end photos.</p>" + follow_box())
        sch = [{"@type": "HowTo", "name": f"How to do {x['name']}", "image": [f"{BASE}/exercises/{fn}" for fn in x["images"]],
                "step": [{"@type": "HowToStep", "position": n + 1, "text": t} for n, t in enumerate(x.get("instructions") or [])]},
               bc([("Home", BASE + "/"), ("Exercises", f"{BASE}/exercises/"), (mname(pm), f"{BASE}/exercises/muscle/{mslug(pm)}/"), (x["name"], f"{BASE}/exercises/{sl}/")])]
        page(f"exercises/{sl}/", f"How to Do {x['name']}: Form, Muscles & Tips | danfitnz",
             f"How to do the {x['name'].lower()} with good form: animated demo, step-by-step instructions, muscles worked and workouts that use it.", body, sch)
        EXTRA_URLS.append(f"exercises/{sl}/")

    eqs = ["body only", "dumbbell", "barbell", "kettlebells", "cable", "machine", "bands", "other"]
    EQN = {"body only": "Bodyweight", "kettlebells": "Kettlebell", "bands": "Bands", "other": "Other"}
    filt = ("<div class='chips2' id='eqf'><a class='chip on' data-f='all' href='#'>All</a>" + "".join(f"<a class='chip' data-f='{E(e)}' href='#'>{E(EQN.get(e, e.title()))}</a>" for e in eqs) + "</div>"
            "<script>document.getElementById('eqf').addEventListener('click',function(e){var a=e.target.closest('a[data-f]');if(!a)return;e.preventDefault();var f=a.dataset.f;"
            "this.querySelectorAll('a').forEach(function(x){x.classList.toggle('on',x===a)});document.querySelectorAll('.exgrid .excard').forEach(function(c){var q=c.dataset.eq;c.style.display=(f==='all'||q===f||(f==='other'&&['body only','dumbbell','barbell','kettlebells','cable','machine','bands'].indexOf(q)<0))?'':'none'})});</script>")
    tiles = ""
    for m in MUSCLES + ["other"]:
        ids = bym.get(m, [])
        if not ids: continue
        nm = mname(m) if m != "other" else "Other"
        tiles += f"<a class='excard' href='/exercises/muscle/{mslug(m)}/'><div class='exfig'><img src='/exercises/{ids[0]}_s.webp' alt='{E(nm)} exercises' width='360' height='240' loading='lazy'></div><b>{E(nm)}</b><small>{len(ids)} exercises</small></a>"
        page(f"exercises/muscle/{mslug(m)}/", f"{nm} Exercises: {len(ids)} Moves With Animated Demos | danfitnz",
             f"{len(ids)} {nm.lower()} exercises with animated demos and step-by-step instructions — bodyweight, dumbbell, barbell, kettlebell, cable and machine.",
             f"<p class='meta'><a href='/exercises/'>Exercise library</a></p><h1>{E(nm)} exercises</h1><p class='lead'>{len(ids)} {E(nm.lower())} exercises, most popular first. Filter by equipment, then tap any exercise for full instructions.</p>{filt}"
             f"<div class='exgrid'>{''.join(card(i) for i in ids)}</div>"
             + (f"<h2>{E(nm)} workouts</h2><div class='grid'>{''.join(wlink(w) for w in [w for w in WK if sum((EX[i].get('primaryMuscles') or [''])[0] == m for i, _ in w['items']) >= 2][:12])}</div>")
             + follow_box(),
             [bc([("Home", BASE + "/"), ("Exercises", f"{BASE}/exercises/"), (nm, f"{BASE}/exercises/muscle/{mslug(m)}/")])])
        EXTRA_URLS.append(f"exercises/muscle/{mslug(m)}/")
    idx = json.dumps([[x["name"], exslug(i)] for i, x in ranked], separators=(",", ":"))
    search = ("<input id='exq' placeholder='Search 870+ exercises (e.g. squat, curl, plank)' style='width:100%;padding:12px 14px;border-radius:12px;border:1px solid #333;background:#16181d;color:#f5f5f5;font-size:16px'>"
              "<div id='exr' class='grid' style='margin-top:10px'></div><script>var EXI=" + idx + ";document.getElementById('exq').addEventListener('input',function(){var q=this.value.toLowerCase().trim(),r=document.getElementById('exr');"
              "if(q.length<2){r.innerHTML='';return}var h=EXI.filter(function(e){return e[0].toLowerCase().indexOf(q)>=0}).slice(0,24);r.innerHTML=h.map(function(e){return '<a href=\"/exercises/'+e[1]+'/\">'+e[0].replace(/[<>&]/g,'')+'</a>'}).join('')||'<p>No matches</p>'})</script>")
    page("exercises/", "Exercise Library: 870+ Exercises With Animated Demos | danfitnz",
         f"{len(EX)} exercises with animated demos made from real photos, step-by-step instructions and muscles worked — find exercises by muscle or equipment.",
         f"<h1>Exercise library</h1><p class='lead'>{len(EX)} exercises with animated demos made from real photos, step-by-step instructions and the muscles they work. Search, or pick a muscle.</p>{search}"
         f"<h2>Exercises by muscle</h2><div class='exgrid'>{tiles}</div><h2>Popular exercises</h2><div class='exgrid'>{''.join(card(i) for i, _ in ranked[:24])}</div>"
         f"<p><a href='/workouts/'>Browse {len(WK)} free workouts →</a></p><p class='meta'>Exercise photos and instructions: free-exercise-db (public domain).</p>{follow_box()}",
         [bc([("Home", BASE + "/"), ("Exercises", f"{BASE}/exercises/")])])
    EXTRA_URLS.append("exercises/")
    G["WK_COUNT"] = len(WK); G["SPLIT_COUNT"] = len(SPLITS)
    print(f"workouts_gen: {len(EX)} exercises, {len(WK)} workouts, {len(SPLITS)} plans")
