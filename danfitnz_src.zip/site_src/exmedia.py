"""Exercise media: downloads the public-domain free-exercise-db photos (cached) and makes
smooth looping animated WebP 'GIFs' from the real start/end photos, plus resized JPGs."""
import os, shutil, urllib.request
from concurrent.futures import ThreadPoolExecutor
from multiprocessing import Pool
from PIL import Image

RAW = ["https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises/",
       "https://cdn.jsdelivr.net/gh/yuhonas/free-exercise-db@main/exercises/"]
VER = "v1"  # bump to regenerate all media


def _fit(im, W, H):
    im = im.copy(); im.thumbnail((W, H), Image.LANCZOS)
    c = Image.new("RGB", (W, H), (255, 255, 255)); c.paste(im, ((W - im.width) // 2, (H - im.height) // 2)); return c


def _anim(frames, out, W, H, q, n, hold=850, step=60):
    fs = [_fit(f, W, H) for f in frames]
    if len(fs) == 1:
        fs[0].save(out, quality=q + 15); return
    A, B = fs[0], fs[1]
    seq = [A] + [Image.blend(A, B, k / (n + 1)) for k in range(1, n + 1)] + [B] + [Image.blend(B, A, k / (n + 1)) for k in range(1, n + 1)]
    du = [hold] + [step] * n + [hold] + [step] * n
    seq[0].save(out, save_all=True, append_images=seq[1:], duration=du, loop=0, quality=q, method=4)


def _make(job):
    i, srcs, cache = job
    d = os.path.join(cache, VER)
    outs = [os.path.join(d, f"{i}.webp"), os.path.join(d, f"{i}_s.webp")] + [os.path.join(d, f"{i}_{n}.jpg") for n in range(len(srcs))]
    if all(os.path.exists(o) for o in outs): return i, True
    try:
        fr = [Image.open(s).convert("RGB") for s in srcs]
    except Exception:
        return i, False
    for n, f in enumerate(fr): _fit(f, 600, 400).save(os.path.join(d, f"{i}_{n}.jpg"), quality=80, optimize=True, progressive=True)
    _anim(fr, outs[0], 600, 400, 52, 3)   # detail pages
    _anim(fr, outs[1], 360, 240, 50, 3)   # cards
    return i, True


def _dl(job):
    url_path, dest = job
    if os.path.exists(dest) and os.path.getsize(dest) > 1000: return True
    for base in RAW:
        try:
            urllib.request.urlretrieve(base + url_path, dest + ".part"); os.replace(dest + ".part", dest); return True
        except Exception:
            continue
    return False


def build_media(exdata, out_dir, cache=None):
    """Returns the set of exercise ids that have media."""
    cache = cache or os.environ.get("EX_CACHE") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "excache")
    raw = os.path.join(cache, "raw"); os.makedirs(raw, exist_ok=True); os.makedirs(os.path.join(cache, VER), exist_ok=True)
    dl = []; jobs = []
    for i, x in exdata.items():
        srcs = []
        for p in x.get("src", []):
            dest = os.path.join(raw, p.replace("/", "__")); dl.append((p, dest)); srcs.append(dest)
        if srcs: jobs.append((i, srcs, cache))
    with ThreadPoolExecutor(24) as ex: list(ex.map(_dl, dl))
    with Pool(max(2, os.cpu_count() or 2)) as p: res = p.map(_make, jobs, chunksize=8)
    ok = {i for i, good in res if good}
    os.makedirs(out_dir, exist_ok=True)
    for fn in os.listdir(os.path.join(cache, VER)):
        shutil.copy(os.path.join(cache, VER, fn), os.path.join(out_dir, fn))
    return ok
