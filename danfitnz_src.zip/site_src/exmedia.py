"""Exercise media: downloads the public-domain free-exercise-db photos (cached) and makes
smooth looping animated WebP 'GIFs' from the real start/end photos, plus resized JPGs."""
import os, shutil, urllib.request
from concurrent.futures import ThreadPoolExecutor
from multiprocessing import Pool
from PIL import Image

RAW = ["https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises/",
       "https://cdn.jsdelivr.net/gh/yuhonas/free-exercise-db@main/exercises/"]
VER = "v2"  # bump to regenerate all media


def _fit(im, W, H):
    im = im.copy(); im.thumbnail((W, H), Image.LANCZOS)
    c = Image.new("RGB", (W, H), (255, 255, 255)); c.paste(im, ((W - im.width) // 2, (H - im.height) // 2)); return c


def _flow(a, b):
    import cv2
    dis = cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
    return dis.calc(cv2.cvtColor(a, cv2.COLOR_RGB2GRAY), cv2.cvtColor(b, cv2.COLOR_RGB2GRAY), None)


def _warp(img, f, t):
    import cv2, numpy as np
    h, w = f.shape[:2]; gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    return cv2.remap(img, gx + f[..., 0] * t, gy + f[..., 1] * t, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)


def _tween(a, b, fab, fba, n):
    """Motion-interpolated in-between frames (optical flow morph) from pose a to pose b."""
    import numpy as np
    out = []
    for k in range(1, n + 1):
        t = k / (n + 1); t = t * t * (3 - 2 * t)  # ease in/out like a real rep
        wa = _warp(a, fba, t); wb = _warp(b, fab, 1 - t)
        out.append((wa * (1 - t) + wb * t).astype(np.uint8))
    return out


def _anim(frames, out, W, H, q, n, hold=380, step=45):
    fs = [_fit(f, W, H) for f in frames]
    if len(fs) == 1:
        fs[0].save(out, quality=q + 15); return
    A, B = fs[0], fs[1]
    try:
        import numpy as np
        a, b = np.array(A), np.array(B)
        fab, fba = _flow(a, b), _flow(b, a)
        ab = [Image.fromarray(x) for x in _tween(a, b, fab, fba, n)]
        ba = [Image.fromarray(x) for x in _tween(b, a, fba, fab, n)]
    except Exception:  # no OpenCV: plain crossfade
        ab = [Image.blend(A, B, k / (n + 1)) for k in range(1, n + 1)]
        ba = [Image.blend(B, A, k / (n + 1)) for k in range(1, n + 1)]
    seq = [A] + ab + [B] + ba
    du = [hold] + [step] * n + [hold] + [step] * n
    seq[0].save(out, save_all=True, append_images=seq[1:], duration=du, loop=0, quality=q, method=4)


def _make(job):
    i, srcs, cache = job
    d = os.path.join(cache, VER)
    outs = [os.path.join(d, f"{i}.webp"), os.path.join(d, f"{i}_s.webp")] + [os.path.join(d, f"{i}_{n}.jpg") for n in range(len(srcs))]
    if all(os.path.exists(o) for o in outs): return i, True
    try:
        fr = [Image.open(s).convert("RGB") for s in srcs]
    except Exception:
        return i, False
    for n, f in enumerate(fr): _fit(f, 600, 400).save(os.path.join(d, f"{i}_{n}.jpg"), quality=80, optimize=True, progressive=True)
    _anim(fr, outs[0], 600, 400, 50, 8)   # detail pages
    _anim(fr, outs[1], 360, 240, 45, 6)   # cards
    return i, True


def _dl(job):
    url_path, dest = job
    if os.path.exists(dest) and os.path.getsize(dest) > 1000: return True
    for base in RAW:
        try:
            urllib.request.urlretrieve(base + url_path, dest + ".part"); os.replace(dest + ".part", dest); return True
        except Exception:
            continue
    return False


def build_media(exdata, out_dir, cache=None):
    """Returns the set of exercise ids that have media."""
    cache = cache or os.environ.get("EX_CACHE") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "excache")
    raw = os.path.join(cache, "raw"); os.makedirs(raw, exist_ok=True); os.makedirs(os.path.join(cache, VER), exist_ok=True)
    dl = []; jobs = []
    for i, x in exdata.items():
        srcs = []
        for p in x.get("src", []):
            dest = os.path.join(raw, p.replace("/", "__")); dl.append((p, dest)); srcs.append(dest)
        if srcs: jobs.append((i, srcs, cache))
    with ThreadPoolExecutor(24) as ex: list(ex.map(_dl, dl))
    with Pool(max(2, os.cpu_count() or 2)) as p: res = p.map(_make, jobs, chunksize=8)
    ok = {i for i, good in res if good}
    os.makedirs(out_dir, exist_ok=True)
    for fn in os.listdir(os.path.join(cache, VER)):
        shutil.copy(os.path.join(cache, VER, fn), os.path.join(out_dir, fn))
    return ok
