# Executed inside build.py: renders scheduled blog posts (posts/*.json with date <= TODAY),
# category hubs, RSS feed, affiliate boxes, ad slots and infographics.
import glob
from graphics import visual as make_visual, og_image

CATS = CFG["categories"]
ALL_POSTS = []
for fp in sorted(glob.glob(os.path.join(HERE, "posts", "*.json"))):
    for p in json.load(open(fp)):
        ALL_POSTS.append(p)
LIVE = sorted([p for p in ALL_POSTS if p["date"] <= TODAY], key=lambda p: (p["date"], p.get("slot", 0)), reverse=True)
UPCOMING = [p for p in ALL_POSTS if p["date"] > TODAY]

def aff_box(keys):
    A = CFG["affiliates"]; ks = [k for k in keys if k in A and not k.startswith("_")]
    if not ks: return ""
    rows = "".join(f'<a class="aff" href="{E(A[k]["url"])}" rel="sponsored nofollow noopener" target="_blank"><img class="affimg" src="/products/{k}.png" alt="{E(A[k]["name"])}" width="640" height="400" loading="lazy"><b>{E(A[k]["name"])}</b><small>{E(A[k]["why"])}</small><span>See it on {E(A[k]["store"])} →</span></a>' for k in ks)
    return f'<div class="affwrap"><h2>Gear that helps</h2><div class="affgrid">{rows}</div><p class="meta">Some links are affiliate links: if you buy, danfitnz may earn a small commission at no extra cost to you. <a href="/affiliate-disclosure/">Disclosure</a> · <a href="/shop/">See all recommended gear →</a></p></div>'

def words(p):
    t = p["intro"] + " " + " ".join(p.get("takeaways", [])) + " " + p.get("dan", "") + " " + " ".join(q + " " + a for q, a in p.get("faq", [])) + " " + " ".join(" ".join(s.get("p", [])) + " " + " ".join(s.get("list", [])) for s in p["sections"])
    return len(t.split())

BLOG_LIST = []
for p in LIVE:
    path = f"blog/{p['slug']}/"; url = f"{BASE}/{path}"
    cat = p["category"]; catname = CATS.get(cat, cat)
    og = f"og/blog-{p['slug']}.png"; og_image(f"{OUT}/{og}", p["title"], catname)
    vis_html = ""
    if p.get("visual"):
        vp = f"img/blog/{p['slug']}.png"
        if not os.path.exists(f"{OUT}/{vp}"): make_visual(f"{OUT}/{vp}", p["visual"])
        from PIL import Image as _I
        vw, vh = _I.open(f"{OUT}/{vp}").size
        vis_html = f'<figure><img src="/{vp}" width="{vw}" height="{vh}" alt="{E(p["visual"]["title"])}" loading="lazy"><figcaption>{E(p["visual"]["title"])}</figcaption></figure>'
    if not p.get("v2"):
        NOINDEX.add(path)
    va = p.get("visual_after", 1)
    toc = "".join(f'<li><a href="#s{i}">{E(s["h"])}</a></li>' for i, s in enumerate(p["sections"]))
    secs = ""
    for i, s in enumerate(p["sections"]):
        secs += f'<h2 id="s{i}">{E(s["h"])}</h2>' + "".join(f"<p>{E(x)}</p>" for x in s.get("p", []))
        if s.get("list"): secs += "<ul>" + "".join(f"<li>{E(x)}</li>" for x in s["list"]) + "</ul>"
        if i == va: secs += vis_html
        if i == len(p["sections"]) // 2: secs += ad("in-article")
    if va >= len(p["sections"]): secs += vis_html
    rel = [q for q in LIVE if q is not p and q["category"] == cat][:3] or [q for q in LIVE if q is not p][:3]
    rel_html = "".join(f'<a href="/blog/{q["slug"]}/">{E(q["title"])}<small>{E(CATS.get(q["category"], ""))}</small></a>' for q in rel)
    faq_html = "".join(f"<h3>{E(q)}</h3><p>{E(a)}</p>" for q, a in p.get("faq", []))
    mins = max(2, round(words(p) / 220))
    upd = p.get("updated", p["date"])
    V2TOP = ""; V2BOT = ""
    if p.get("v2"):
        V2TOP = (f'<div class="keybox"><b>Key takeaways</b><ul>' + "".join(f"<li>{E(x)}</li>" for x in p.get("takeaways", [])) + "</ul></div>"
                 + (f'<p><b>Who this is for:</b> {E(p["who"])}</p>' if p.get("who") else ""))
        V2BOT = ((f'<div class="danbox"><b>What Dan does</b><p>{E(p["dan"])}</p></div>' if p.get("dan") else "")
                 + (f'<h2>Your checklist</h2><ul class="check">' + "".join(f"<li>{E(x)}</li>" for x in p["checklist"]) + "</ul>" if p.get("checklist") else ""))
        V2REF = ""
    secs_extra = ""
    if p.get("v2") and p.get("references"):
        secs_extra = '<h2>Sources</h2><ol class="refs">' + "".join(f'<li><a href="{E(u)}" rel="nofollow noopener" target="_blank">{E(t)}</a></li>' for t, u in p["references"]) + "</ol>"
    author_html = ('<div class="author"><img src="/logo.png" alt="Dan from danfitnz" width="56" height="56"><div><b>About Dan</b><p style="margin:4px 0 0">' + E(CFG.get("author_bio", "")) + '</p></div></div>') if p.get("v2") else ""
    body = f"""<p class="meta"><a href="/blog/">Blog</a> › <a href="/blog/category/{cat}/">{E(catname)}</a></p>
<h1>{E(p['title'])}</h1><p class="meta">By Dan, danfitnz · <time datetime="{p['date']}">{datetime.date.fromisoformat(p['date']).strftime('%-d %B %Y')}</time>{(" · Updated " + datetime.date.fromisoformat(upd).strftime('%-d %B %Y')) if upd != p['date'] else ""} · {mins} min read</p>
<p class="lead">{E(p['intro'])}</p>{V2TOP}{ad("top")}
<nav class="toc"><b>In this guide</b><ol>{toc}</ol></nav>
{secs}
{V2BOT}{f'<div class="card"><b>The takeaway:</b> {E(p["takeaway"])}</div>' if p.get("takeaway") else ""}
<div class="card"><b>Put it into action:</b> <a href="/tools/plan-builder/">Build your free 7-day plan</a> · <a href="/tools/calorie-deficit-calculator/">Calorie calculator</a> · <a href="/tools/protein-calculator/">Protein calculator</a></div>
{aff_box(p.get("affiliates", []))}
{f"<h2>FAQ</h2>{faq_html}" if faq_html else ""}
{secs_extra}{author_html}
{follow_box()}{ad("bottom")}
<h2>Keep reading</h2><div class="grid">{rel_html}</div>
<p class="note">General information only, not medical advice. Talk to your GP about hormones, medications or health conditions.</p>"""
    sch = [{"@type": "BlogPosting", "headline": p["title"], "description": p["desc"], "image": f"{BASE}/{og}",
            "author": {"@type": "Person", "name": "Dan", "url": f"{BASE}/about/"}, "publisher": {"@id": BASE + "/#org"},
            "datePublished": p["date"], "dateModified": upd, "mainEntityOfPage": url, "articleSection": catname,
            "keywords": ", ".join(p.get("keywords", [])), "wordCount": words(p), "inLanguage": "en-NZ"},
           bc([("Home", BASE + "/"), ("Blog", f"{BASE}/blog/"), (catname, f"{BASE}/blog/category/{cat}/"), (p["title"], url)])]
    if p.get("faq"): sch.append({"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in p["faq"]]})
    page(path, f"{p['title']} | danfitnz", p["desc"], body, sch, "article", og_path=og)
    if path not in NOINDEX: EXTRA_URLS.append(path)
    BLOG_LIST.append(dict(path=path, name=p["title"], desc=p["desc"], text=p["intro"] + " " + " ".join(" ".join(s.get("p", [])) for s in p["sections"]), date=p["date"], cat=cat))

def card(b): return f'<a href="/{b["path"]}">{E(b["name"])}<small>{E(CATS.get(b["cat"], ""))} · {datetime.date.fromisoformat(b["date"]).strftime("%-d %b")}</small></a>'
chips = "".join(f'<a class="chip" href="/blog/category/{c}/">{E(n)}</a>' for c, n in CATS.items())
page("blog/", "Fitness, Fat Loss & Hormones Blog | danfitnz", "New guides every day on fat loss, training, motivation, discipline and hormones like cortisol and dopamine, from Auckland, NZ.",
     f"<h1>The danfitnz blog</h1><p class='lead'>A new in-depth guide every day on fat loss, training, motivation, discipline and the hormones behind them.</p><div class='chips2'>{chips}</div>{ad('top')}<div class='grid'>{''.join(card(b) for b in BLOG_LIST)}</div>{follow_box()}",
     [{"@type": "Blog", "name": "danfitnz blog", "url": f"{BASE}/blog/", "blogPost": [{"@type": "BlogPosting", "headline": b["name"], "url": f"{BASE}/{b['path']}", "datePublished": b["date"]} for b in BLOG_LIST[:20]]},
      bc([("Home", BASE + "/"), ("Blog", f"{BASE}/blog/")])])
EXTRA_URLS.append("blog/")
for c, n in CATS.items():
    items = [b for b in BLOG_LIST if b["cat"] == c]
    page(f"blog/category/{c}/", f"{n} Guides | danfitnz", f"danfitnz guides on {n.lower()}: practical, science-based and easy to follow.",
         f"<p class='meta'><a href='/blog/'>Blog</a></p><h1>{E(n)}</h1><p class='lead'>Practical, science-based guides on {E(n.lower())}.</p><div class='chips2'>{chips}</div><div class='grid'>{''.join(card(b) for b in items) or '<p>New posts coming soon.</p>'}</div>{follow_box()}",
         [{"@type": "CollectionPage", "name": n, "url": f"{BASE}/blog/category/{c}/"}, bc([("Home", BASE + "/"), ("Blog", f"{BASE}/blog/"), (n, f"{BASE}/blog/category/{c}/")])])
    EXTRA_URLS.append(f"blog/category/{c}/")

# RSS feed
def rfc(d): return datetime.datetime.combine(datetime.date.fromisoformat(d), datetime.time(6, 0)).strftime("%a, %d %b %Y %H:%M:%S +1300")
open(f"{OUT}/feed.xml", "w").write('<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>danfitnz blog</title>'
    f"<link>{BASE}/blog/</link><description>Fat loss, training, motivation and hormones guides from Auckland, NZ.</description><language>en-nz</language>" +
    "".join(f"<item><title>{E(b['name'])}</title><link>{BASE}/{b['path']}</link><guid>{BASE}/{b['path']}</guid><pubDate>{rfc(b['date'])}</pubDate><description>{E(b['desc'])}</description></item>" for b in BLOG_LIST[:30]) +
    "</channel></rss>")

# affiliate disclosure
page("affiliate-disclosure/", "Affiliate Disclosure | danfitnz", "How danfitnz earns money from affiliate links and ads, and how we choose what to recommend.",
     "<h1>Affiliate disclosure</h1><p class='lead'>danfitnz is free to use. To keep it that way, some pages contain affiliate links and may show ads.</p><p>If you click an affiliate link and buy something, we may earn a small commission at no extra cost to you. We only recommend simple, useful gear and supplements that fit our advice: protein, creatine, a food scale, bands and basic equipment. We never accept payment to say something is good.</p><p class='meta'>Product illustrations use Tabler Icons (MIT licence, tabler.io). Brand names and products belong to their owners.</p><p><strong>As an Amazon Associate, danfitnz earns from qualifying purchases.</strong></p><p>Nothing on this site is medical advice. Talk to your GP before starting supplements, especially if you take medication or have a health condition.</p>",
     [bc([("Home", BASE + "/"), ("Affiliate disclosure", f"{BASE}/affiliate-disclosure/")])])
EXTRA_URLS.append("affiliate-disclosure/")
TODAY_POSTS = [f"{BASE}/{b['path']}" for b in BLOG_LIST if b["date"] == TODAY]

# ---------- Shop (affiliate product showcase) ----------
A = {k: v for k, v in CFG["affiliates"].items() if not k.startswith("_")}
groups = {}
for k, v in A.items(): groups.setdefault(v.get("group", "More"), []).append((k, v))
KITS = [("Fat-loss starter kit", ["scale", "bodyscale", "whey", "mealprep", "measuring"]), ("Home gym on a budget", ["bands", "dumbbells", "mat", "pullupbar", "kettlebell"]), ("Build muscle basics", ["whey", "creatine", "shaker", "bench", "straps"]), ("Desi meal prep kit", ["ricecooker", "mealprep", "airfryer", "lunchbox"]), ("Recovery & sleep", ["foamroller", "massagegun", "sleepmask", "magnesium"])]
GORDER = ["Supplements", "Home gym", "Kitchen & tracking", "Apparel & recovery"]
groups = {g: groups[g] for g in GORDER + [g for g in groups if g not in GORDER] if g in groups}
def pcard(k, v):
    return f'<a class="aff" href="{E(v["url"])}" rel="sponsored nofollow noopener" target="_blank"><img class="affimg" src="/products/{k}.png" alt="{E(v["name"])}" width="640" height="400" loading="lazy"><b>{E(v["name"])}</b><small>{E(v["why"])}</small><span>See it on {E(v["store"])} →</span></a>'
shop_body = (f"<h1>The danfitnz shop</h1><p class='lead'>Simple, useful gear and supplements we actually recommend for fat loss and training. No fads, no detox teas.</p>"
             f"<p class='meta'>danfitnz earns a small commission on some links at no extra cost to you. <a href='/affiliate-disclosure/'>How this works</a></p>{ad('top')}"
             "<h2>Starter kits</h2><div class='affgrid'>" + "".join(f'<div class="card" style="margin:0"><b>{E(n)}</b><ul style="margin:8px 0 0;padding-left:18px">' + "".join(f'<li><a href="{E(A[i]["url"])}" rel="sponsored nofollow noopener" target="_blank">{E(A[i]["name"])}</a></li>' for i in items if i in A) + "</ul></div>" for n, items in KITS) + "</div>" +
             "".join(f"<h2>{E(g)}</h2><div class='affgrid'>" + "".join(pcard(k, v) for k, v in items) + "</div>" for g, items in groups.items()) +
             "<p class='meta'>Saw a product in a video? <a href='/go/'>All gear links from Reels and Shorts →</a></p><p class='note'>Supplements are optional. Food, training and sleep come first. Check with your GP before taking supplements, especially if you take medication.</p>" + follow_box())
page("shop/", "Fitness Gear & Supplements We Recommend | danfitnz Shop", "The simple fitness gear and supplements danfitnz recommends for fat loss and home training: protein, creatine, food scales, bands, dumbbells and more.",
     shop_body, [{"@type": "ItemList", "name": "danfitnz recommended products", "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": v["name"], "url": v["url"], "image": f"{BASE}/products/{k}.png"} for i, (k, v) in enumerate(A.items())]},
                 bc([("Home", BASE + "/"), ("Shop", f"{BASE}/shop/")])])
EXTRA_URLS.append("shop/")

if os.path.isdir(os.path.join(HERE, "products")): shutil.copytree(os.path.join(HERE, "products"), os.path.join(OUT, "products"), dirs_exist_ok=True)
# ---------- /go/ short links: danfitnz.nz/go/creatine?s=ig ----------
import json as _json
PT = {k: v for k, v in CFG.get("platform_tags", {}).items() if not k.startswith("_") and v}
DEF = CFG.get("amazon_default_tag", "danfitnz-20")
for k, v in A.items():
    d = os.path.join(OUT, "go", k); os.makedirs(d, exist_ok=True)
    u = v["url"]
    open(os.path.join(d, "index.html"), "w").write(f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{E(v['name'])} | danfitnz</title>
<noscript><meta http-equiv="refresh" content="0;url={E(u)}"></noscript>
<script>(function(){{var u={_json.dumps(u)},pt={_json.dumps(PT)},s=(new URLSearchParams(location.search).get('s')||'').toLowerCase(),t=pt[s];
if(t&&u.indexOf('tag={DEF}')>-1)u=u.replace('tag={DEF}','tag='+t);location.replace(u);}})();</script></head>
<body style="font-family:sans-serif;background:#0e0f12;color:#eee;padding:40px">Taking you to {E(v['name'])} on {E(v['store'])}… <a style="color:#c6ff3d" href="{E(u)}" rel="sponsored nofollow">Tap here if nothing happens</a>.<br><small>As an Amazon Associate, danfitnz earns from qualifying purchases.</small></body></html>""")
go_rows = "".join(f"<li><a href='/go/{k}/' rel='sponsored nofollow'>danfitnz.nz/go/{k}</a> — {E(v['name'])}</li>" for k, v in A.items())
page("go/", "Quick gear links | danfitnz", "Short links to every product danfitnz recommends in videos.",
     f"<h1>Gear from the videos</h1><p class='lead'>Saw something in a Reel or Short? Find it here.</p><p class='meta'>Affiliate links: danfitnz may earn a small commission at no extra cost to you. As an Amazon Associate, danfitnz earns from qualifying purchases.</p><ul>{go_rows}</ul><p><a class='cta' href='/shop/'>Browse the full shop →</a></p>",
     [bc([("Home", BASE + "/"), ("Gear links", f"{BASE}/go/")])])
