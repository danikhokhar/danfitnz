import re
def ML(x, _E=E, _re=re):  # escape, then [text](/path) links and [^n] citations
    x = _re.sub(r"\[\^(\d+)\]", r"@@CITE\1@@", x)
    return _re.sub(r"@@CITE(\d+)@@", r'<sup><a href="#ref-\1" class="cite">[\1]</a></sup>', _ML0(x, _E, _re))
def _ML0(x, _E=E, _re=re):
    return _re.sub(r"\[([^\]]+)\]\(((?:/|https://)[^)\s]*)\)", lambda m: f'<a href="{m.group(2)}">{m.group(1)}</a>', _E(x))
# Executed inside build.py: renders scheduled blog posts (posts/*.json with date <= TODAY),
# category hubs, RSS feed, affiliate boxes, ad slots and infographics.
import glob
from graphics import visual as make_visual, og_image

CATS = CFG["categories"]
ALL_POSTS = []
for fp in sorted(glob.glob(os.path.join(HERE, "posts", "*.json"))):
    for p in json.load(open(fp)):
        ALL_POSTS.append(p)
LIVE = sorted([p for p in ALL_POSTS if p["date"] <= TODAY], key=lambda p: (p["date"], p.get("slot", 0)), reverse=True)
UPCOMING = [p for p in ALL_POSTS if p["date"] > TODAY]

def aff_box(keys):
    A = CFG["affiliates"]; ks = [k for k in keys if k in A and not k.startswith("_")]
    if not ks: return ""
    rows = "".join(f'<a class="aff" href="{E(A[k]["url"])}" rel="sponsored nofollow noopener" target="_blank"><img class="affimg" src="/products/{k}.png" alt="{E(A[k]["name"])}" width="640" height="400" loading="lazy"><b>{E(A[k]["name"])}</b><small>{E(A[k]["why"])}</small><span>See it on {E(A[k]["store"])} →</span></a>' for k in ks)
    return f'<div class="affwrap"><h2>Gear that helps</h2><div class="affgrid">{rows}</div><p class="meta">Some links are affiliate links: if you buy, danfitnz may earn a small commission at no extra cost to you. <a href="/affiliate-disclosure/">Disclosure</a> · <a href="/shop/">See all recommended gear →</a></p></div>'

def words(p):
    t = p["intro"] + " " + " ".join(p.get("takeaways", [])) + " " + p.get("dan", "") + " " + " ".join(q + " " + a for q, a in p.get("faq", [])) + " " + " ".join(" ".join(s.get("p", [])) + " " + " ".join(s.get("list", [])) for s in p["sections"])
    return len(t.split())

_cnt = {}
for _p in LIVE:
    if _p.get("v2"): _cnt[_p["category"]] = _cnt.get(_p["category"], 0) + 1
ACTIVE_CATS = {c: n for c, n in CATS.items() if _cnt.get(c, 0) >= CFG.get("category_min_posts", 3)}
BLOG_LIST = []
for p in LIVE:
    path = f"blog/{p['slug']}/"; url = f"{BASE}/{path}"
    cat = p["category"]; catname = CATS.get(cat, cat)
    og = f"og/blog-{p['slug']}.png"; og_image(f"{OUT}/{og}", p["title"], catname)
    vis_html = ""
    if p.get("visual"):
        vp = f"img/blog/{p['slug']}.png"
        if not os.path.exists(f"{OUT}/{vp}"): make_visual(f"{OUT}/{vp}", p["visual"])
        from PIL import Image as _I
        vw, vh = _I.open(f"{OUT}/{vp}").size
        vis_html = f'<figure><img src="/{vp}" width="{vw}" height="{vh}" alt="{E(p["visual"]["title"])}" loading="lazy"><figcaption>{E(p["visual"]["title"])}</figcaption></figure>'
    if not p.get("v2"):
        NOINDEX.add(path)
    va = p.get("visual_after", 1)
    TRYIT = {"_": ("Turn this into a plan: your calories, protein, meals and workouts for the next 7 days.", "Build my free 7-day plan", "/tools/plan-builder/"),
             "intermittent-fasting": ("Pick your eating window and get a 16:8 meal plan with your calories and protein.", "Build my 16:8 plan", "/tools/plan-builder/"),
             "fat-loss": ("Find your maintenance calories and a realistic fat-loss target in 20 seconds.", "Calculate my calories", "/tools/calorie-deficit-calculator/"),
             "nutrition": ("See exactly how much protein you need each day and per meal.", "Calculate my protein", "/tools/protein-calculator/"),
             "high-protein-recipes": ("Browse high-protein recipes with calories and protein per serve.", "See the recipes", "/recipes/"),
             "desi-fitness-food": ("Get a 7-day plan with desi meals that fit your calories and protein.", "Build my desi meal plan", "/tools/plan-builder/"),
             "training": ("Pick a workout for your level and equipment, with sets, reps and demos.", "Find my workout", "/workouts/"),
             "gym-programs-strength": ("Follow a full weekly gym plan with every exercise demonstrated.", "See the weekly plans", "/workouts/#plans"),
             "home-workouts": ("Try a no-equipment workout you can do in your living room today.", "Start a home workout", "/workouts/bodyweight-full-body-workout-beginner/"),
             "beginners": ("Start with a simple beginner workout, with demos for every exercise.", "Start here", "/workouts/"),
             "mobility-flexibility": ("Do a 6-move stretching routine right now.", "Start the routine", "/workouts/full-body-stretches/"),
             "transformations": ("Find your own numbers, then build a 7-day plan around them.", "Calculate my calories", "/tools/calorie-deficit-calculator/"),
             "motivation-discipline": ("Start small: get a simple 7-day plan you can actually stick to.", "Build my 7-day plan", "/tools/plan-builder/"),
             "walking-cardio": ("Short on time? Try a 20-minute fat-burning circuit with no equipment.", "Try the HIIT workout", "/workouts/hiit-fat-burning-workout-beginner/")}
    toc = "".join(f'<li><a href="#s{i}">{E(s["h"])}</a></li>' for i, s in enumerate(p["sections"]))
    secs = ""
    for i, s in enumerate(p["sections"]):
        secs += f'<h2 id="s{i}">{E(s["h"])}</h2>' + "".join(f"<p>{ML(x)}</p>" for x in s.get("p", []))
        if s.get("list"): secs += "<ul>" + "".join(f"<li>{ML(x)}</li>" for x in s["list"]) + "</ul>"
        if i == va: secs += vis_html
        if i == len(p["sections"]) // 2: secs += ad("in-article")
        if p.get("v2") and i == min(2, len(p["sections"]) - 2):
            _t = TRYIT.get(cat, TRYIT["_"])
            secs += f'<div class="tryit"><b>Try it now</b><p>{E(_t[0])}</p><a class="btn" href="{_t[2]}">{E(_t[1])} →</a></div>'
    if va >= len(p["sections"]): secs += vis_html
    LV2 = [q for q in LIVE if q.get("v2")]
    rel = [q for q in LV2 if q is not p and q["category"] == cat][:3] or [q for q in LV2 if q is not p][:3]
    rel_html = "".join(f'<a href="/blog/{q["slug"]}/">{E(q["title"])}<small>{E(CATS.get(q["category"], ""))}</small></a>' for q in rel)
    faq_html = "".join(f"<h3>{E(q)}</h3><p>{E(a)}</p>" for q, a in p.get("faq", []))
    mins = max(2, round(words(p) / 220))
    upd = p.get("updated", p["date"])
    V2TOP = ""; V2BOT = ""
    if p.get("v2"):
        V2TOP = (f'<div class="keybox"><b>Key takeaways</b><ul>' + "".join(f"<li>{E(x)}</li>" for x in p.get("takeaways", [])) + "</ul></div>"
                 + (f'<p><b>Who this is for:</b> {E(p["who"])}</p>' if p.get("who") else ""))
        V2BOT = ((f'<div class="danbox"><b>What Dan does</b><p>{ML(p["dan"])}</p></div>' if p.get("dan") else "")
                 + (f'<div class="caution"><b>Who should be careful</b><p>{ML(p["caution"])}</p></div>' if p.get("caution") else "")
                 + (f'<h2>Ask Dan</h2>' + "".join(f'<div class="askdan"><b>Q: {E(q)}</b><p>{ML(a)}</p></div>' for q, a in p["askdan"]) if p.get("askdan") else "")
                 + (f'<h2>Your checklist</h2><ul class="check">' + "".join(f"<li>{E(x)}</li>" for x in p["checklist"]) + "</ul>" if p.get("checklist") else "")
                 + (f'<h2>Test yourself</h2><p>Three quick questions — tap to check your answer.</p><div class="quiz">' + "".join(f'<details><summary>{k + 1}. {E(q)}</summary><p>{ML(a)}</p></details>' for k, (q, a) in enumerate(p["quiz"])) + "</div>" if p.get("quiz") else ""))
        _ser = sorted([q for q in LV2 if q["category"] == cat], key=lambda q: q["date"])
        _k = [q["slug"] for q in _ser].index(p["slug"]) if p in _ser else -1
        _nx = _ser[_k + 1] if 0 <= _k < len(_ser) - 1 else next((q for q in sorted(LV2, key=lambda q: q["date"], reverse=True) if q is not p and q["category"] != cat), None)
        V2BOT += SIGNUP("post-"+p["slug"])
        if _nx: V2BOT += f'<a class="nextup" href="/blog/{_nx["slug"]}/"><small>Read next</small><b>{E(_nx["title"])}</b></a>'
        V2REF = ""
    secs_extra = ""
    if p.get("v2") and p.get("references"):
        secs_extra = '<h2>Sources</h2><ol class="refs">' + "".join(f'<li id="ref-{k + 1}"><a href="{E(u)}" rel="nofollow noopener" target="_blank">{E(t)}</a></li>' for k, (t, u) in enumerate(p["references"])) + "</ol>"
    author_html = ('<div class="author"><img src="/logo.png" alt="Dan from danfitnz" width="56" height="56"><div><b>About Dan</b><p style="margin:4px 0 0">' + E(CFG.get("author_bio", "")) + ' <a href="/editorial-policy/">How we write and fact-check</a></p></div></div>') if p.get("v2") else ""
    body = f"""<p class="meta"><a href="/blog/">Blog</a> › {f'<a href="/blog/category/{cat}/">{E(catname)}</a>' if cat in ACTIVE_CATS else E(catname)}</p>
<h1>{E(p['title'])}</h1><p class="meta">By Dan, danfitnz · <time datetime="{p['date']}">{datetime.date.fromisoformat(p['date']).strftime('%-d %B %Y')}</time>{(" · Updated " + datetime.date.fromisoformat(upd).strftime('%-d %B %Y')) if upd != p['date'] else ""} · {mins} min read</p>
<p class="lead">{E(p['intro'])}</p>{(f'<figure><img src="{p["hero"]["src"]}" width="{p["hero"]["w"]}" height="{p["hero"]["h"]}" alt="{E(p["hero"]["alt"])}" style="max-width:520px;width:100%;height:auto;border-radius:16px"><figcaption>{E(p["hero"]["alt"])}</figcaption></figure>') if p.get("hero") else ""}{V2TOP}{ad("top")}
<nav class="toc"><b>In this guide</b><ol>{toc}</ol></nav>
{secs}
{V2BOT}{f'<div class="card"><b>The takeaway:</b> {E(p["takeaway"])}</div>' if p.get("takeaway") else ""}
<div class="card"><b>Put it into action:</b> <a href="/tools/plan-builder/">Build your free 7-day plan</a> · <a href="/tools/calorie-deficit-calculator/">Calorie calculator</a> · <a href="/tools/protein-calculator/">Protein calculator</a></div>
{aff_box(p.get("affiliates", []))}
{f"<h2>FAQ</h2>{faq_html}" if faq_html else ""}
{secs_extra}{author_html}
{follow_box()}{ad("bottom")}
<h2>Keep reading</h2><div class="grid">{rel_html}</div>
<p class="note">General information only, not medical advice. Talk to your GP about hormones, medications or health conditions.</p>"""
    sch = [{"@type": "BlogPosting", "headline": p["title"], "description": p["desc"], "image": [f"{BASE}/{og}"] + ([BASE + p["hero"]["src"]] if p.get("hero") else []),
            "author": {"@type": "Person", "name": "Dan", "url": f"{BASE}/about/"}, "publisher": {"@id": BASE + "/#org"},
            "datePublished": p["date"], "dateModified": upd, "mainEntityOfPage": url, "articleSection": catname,
            "keywords": ", ".join(p.get("keywords", [])), "wordCount": words(p), "inLanguage": "en-NZ"},
           bc([("Home", BASE + "/"), ("Blog", f"{BASE}/blog/")] + ([(catname, f"{BASE}/blog/category/{cat}/")] if cat in ACTIVE_CATS else []) + [(p["title"], url)])]
    if p.get("faq"): sch.append({"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in p["faq"]]})
    page(path, f"{p['title']} | danfitnz", p["desc"], body, sch, "article", og_path=og)
    if path not in NOINDEX: EXTRA_URLS.append(path)
    if p.get("v2"): BLOG_LIST.append(dict(path=path, name=p["title"], desc=p["desc"], text=p["intro"] + " " + " ".join(" ".join(s.get("p", [])) for s in p["sections"]), date=p["date"], cat=cat))

def card(b): return f'<a href="/{b["path"]}">{E(b["name"])}<small>{E(CATS.get(b["cat"], ""))} · {datetime.date.fromisoformat(b["date"]).strftime("%-d %b")}</small></a>'
chips = "".join(f'<a class="chip" href="/blog/category/{c}/">{E(n)}</a>' for c, n in ACTIVE_CATS.items())
page("blog/", "Fitness, Fat Loss & Hormones Blog | danfitnz", "New guides every day on fat loss, training, motivation, discipline and hormones like cortisol and dopamine, from Auckland, NZ.",
     f"<h1>The danfitnz blog</h1><p class='lead'>A new in-depth guide every day on fat loss, training, motivation, discipline and the hormones behind them.</p><div class='chips2'>{chips}</div>{ad('top')}<div class='grid'>{''.join(card(b) for b in BLOG_LIST)}</div>{follow_box()}",
     [{"@type": "Blog", "name": "danfitnz blog", "url": f"{BASE}/blog/", "blogPost": [{"@type": "BlogPosting", "headline": b["name"], "url": f"{BASE}/{b['path']}", "datePublished": b["date"]} for b in BLOG_LIST[:20]]},
      bc([("Home", BASE + "/"), ("Blog", f"{BASE}/blog/")])])
EXTRA_URLS.append("blog/")
for c, n in ACTIVE_CATS.items():
    items = [b for b in BLOG_LIST if b["cat"] == c]
    page(f"blog/category/{c}/", f"{n} Guides | danfitnz", f"danfitnz guides on {n.lower()}: practical, science-based and easy to follow.",
         f"<p class='meta'><a href='/blog/'>Blog</a></p><h1>{E(n)}</h1><p class='lead'>Practical, science-based guides on {E(n.lower())}.</p><div class='chips2'>{chips}</div><div class='grid'>{''.join(card(b) for b in items) or '<p>New posts coming soon.</p>'}</div>{follow_box()}",
         [{"@type": "CollectionPage", "name": n, "url": f"{BASE}/blog/category/{c}/"}, bc([("Home", BASE + "/"), ("Blog", f"{BASE}/blog/"), (n, f"{BASE}/blog/category/{c}/")])])
    EXTRA_URLS.append(f"blog/category/{c}/")

# RSS feed
def rfc(d): return datetime.datetime.combine(datetime.date.fromisoformat(d), datetime.time(6, 0)).strftime("%a, %d %b %Y %H:%M:%S +1300")
open(f"{OUT}/feed.xml", "w").write('<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>danfitnz blog</title>'
    f"<link>{BASE}/blog/</link><description>Fat loss, training, motivation and hormones guides from Auckland, NZ.</description><language>en-nz</language>" +
    "".join(f"<item><title>{E(b['name'])}</title><link>{BASE}/{b['path']}</link><guid>{BASE}/{b['path']}</guid><pubDate>{rfc(b['date'])}</pubDate><description>{E(b['desc'])}</description></item>" for b in BLOG_LIST[:30]) +
    "</channel></rss>")

# affiliate disclosure
page("affiliate-disclosure/", "Affiliate Disclosure | danfitnz", "How danfitnz earns money from affiliate links and ads, and how we choose what to recommend.",
     "<h1>Affiliate disclosure</h1><p class='lead'>danfitnz is free to use. To keep it that way, some pages contain affiliate links and may show ads.</p><p>If you click an affiliate link and buy something, we may earn a small commission at no extra cost to you. We only recommend simple, useful gear and supplements that fit our advice: protein, creatine, a food scale, bands and basic equipment. We never accept payment to say something is good.</p><p>We use Google Analytics to understand how many people visit, which pages they read and which links they click. It uses cookies and collects anonymous usage data; you can opt out with Google's opt-out browser add-on or by blocking cookies.</p><p class='meta'>Product illustrations use Tabler Icons (MIT licence, tabler.io). Brand names and products belong to their owners.</p><p><strong>As an Amazon Associate, danfitnz earns from qualifying purchases.</strong></p><p>Nothing on this site is medical advice. Talk to your GP before starting supplements, especially if you take medication or have a health condition.</p><h2 id='privacy'>Privacy</h2><p>We use Google Analytics (via Google Tag Manager) to count visits and clicks in aggregate so we can see which pages help people. If you join the email list, your email address is stored with our email provider, Kit, together with a link to your plan and a short summary (calories, protein, workout type). The plan link contains the details you entered (age, height, weight, goal) so it can rebuild your plan; it is never sent to Google Analytics. We use them only to send you your plan and danfitnz emails. Every email has an unsubscribe link, and you can ask us to delete your details at any time by replying to any email. We never sell your data.</p>",
     [bc([("Home", BASE + "/"), ("Affiliate disclosure", f"{BASE}/affiliate-disclosure/")])])
EXTRA_URLS.append("affiliate-disclosure/")
TODAY_POSTS = [f"{BASE}/{b['path']}" for b in BLOG_LIST if b["date"] == TODAY]

# ---------- Shop (affiliate product showcase) ----------
A = {k: v for k, v in CFG["affiliates"].items() if not k.startswith("_")}
groups = {}
for k, v in A.items(): groups.setdefault(v.get("group", "More"), []).append((k, v))
KITS = [("Fat-loss starter kit", ["scale", "bodyscale", "whey", "mealprep", "measuring"]), ("Home gym on a budget", ["bands", "dumbbells", "mat", "pullupbar", "kettlebell"]), ("Build muscle basics", ["whey", "creatine", "shaker", "bench", "straps"]), ("Desi meal prep kit", ["ricecooker", "mealprep", "airfryer", "lunchbox"]), ("Recovery & sleep", ["foamroller", "massagegun", "sleepmask", "magnesium"])]
GORDER = ["Protein & supplements", "Creatine & performance", "Dumbbells & weights", "Bands & bodyweight", "Yoga & mats", "Cardio & running", "Kitchen & meal prep", "Tracking & scales", "Recovery & sleep", "Apparel & bags"]
groups = {g: groups[g] for g in GORDER + [g for g in groups if g not in GORDER] if g in groups}
def pcard(k, v):
    return f'<a class="aff" href="{E(v["url"])}" rel="sponsored nofollow noopener" target="_blank"><img class="affimg" src="/products/{k}.png" alt="{E(v["name"])}" width="640" height="400" loading="lazy"><b>{E(v["name"])}</b><small>{E(v["why"])}</small><span>See it on {E(v["store"])} →</span></a>'
def gslug(g, re=re): return re.sub(r"[^a-z0-9]+", "-", g.lower().replace("&", "and")).strip("-")
GUIDE = {
"Protein & supplements": ("Protein is the supplement that matters most for fat loss and muscle — and food comes first. A protein powder simply makes hitting 1.6–2.2 g per kg of body weight easier on busy days. Whey concentrate is the cheapest; whey isolate has more protein per scoop and less lactose; plant blends suit vegetarians and dairy-sensitive stomachs. Look for around 20–25 g protein per scoop and a short ingredient list. Beyond protein, a multivitamin, vitamin D in winter and fish oil if you don't eat fish are reasonable 'insurance' — but none of them burn fat. Skip fat burners and detox teas.", [["Do I need protein powder to lose fat?","No — it's a convenience. If you hit your protein from food, you don't need it."],["Whey or plant protein?","Both work. Whey is cheaper and absorbs well; plant blends are great if dairy upsets you."]]),
"Creatine & performance": ("Creatine monohydrate is the most researched performance supplement there is: 3–5 g a day, every day, no loading needed. It helps strength and muscle and is safe for healthy adults. Caffeine is the other proven performance aid — a coffee works as well as most pre-workouts. Electrolytes help on hot days, long sessions or when fasting. Most other 'performance' powders are optional extras; buy them only if you enjoy them and your basics are sorted.", [["Is creatine safe?","For healthy adults, creatine monohydrate at 3–5 g/day has a strong safety record. Talk to your GP if you have kidney issues."],["Do I need pre-workout?","No. A coffee 30–60 minutes before training does the same job for most people."]]),
"Dumbbells & weights": ("For a home gym, start with adjustable dumbbells or two or three pairs of fixed dumbbells — they cover squats, presses, rows and lunges. Add a kettlebell for swings and goblet squats, then a bench to unlock presses and step-ups. A rack and barbell only make sense once you're training consistently and have the space. Buy for the weights you'll need in six months, not just today.", [["What weights should a beginner buy?","Adjustable dumbbells are best value. Otherwise a light, medium and heavy pair (e.g. 5, 10, 15 kg)."],["Kettlebell or dumbbells?","Dumbbells are more versatile; a kettlebell is great for swings and conditioning."]]),
"Bands & bodyweight": ("Resistance bands and bodyweight tools are the cheapest way to train anywhere — a lounge, a hotel room or a park. Loop bands are great for warm-ups and glutes; tube bands with handles and a door anchor mimic gym cables; a doorway pull-up bar is the cheapest back trainer you can own. Assist bands help you get your first pull-up.", [["Can you build muscle with bands?","Yes, especially as a beginner, if you push sets close to failure and progress over time."],["Is a doorway pull-up bar safe?","Choose one rated for your weight and check the door frame is solid."]]),
"Yoga & mats": ("A decent mat makes floor work, core training and stretching far more comfortable. Thicker mats (10–15 mm) suit knees and bodyweight work; thinner, grippier mats suit yoga. Blocks and straps make mobility work accessible if you're stiff, and floor tiles protect your floors under weights.", [["How thick should an exercise mat be?","Around 6 mm for yoga, 10–15 mm for floor exercises and comfort."],["Do I need yoga blocks?","They make many stretches easier and safer if you're not flexible yet."]]),
"Cardio & running": ("Walking is the best cardio for fat loss for most people — comfortable shoes and a step tracker go a long way. If you run, get shoes that feel comfortable from the first step. For home cardio, an exercise bike or walking pad lets you train whatever the Auckland weather. A jump rope is the cheapest high-intensity option.", [["Best cardio for fat loss?","Whatever you'll do consistently. Daily walking plus 2–4 strength sessions works for most people."],["Walking pad or treadmill?","A walking pad suits under-desk walking; a treadmill suits running."]]),
"Kitchen & meal prep": ("The kitchen is where fat loss is won. A food scale and measuring spoons stop oil and portions creeping up; an air fryer makes crispy food with a fraction of the oil; a rice cooker or pressure cooker makes desi staples easy; meal prep containers and an insulated lunch bag help you skip takeaways at work.", [["What's the most useful kitchen tool for fat loss?","A digital food scale — weigh oil, rice and meat for a few weeks to learn real portions."],["Is an air fryer worth it?","If you love fried food, yes — it cuts oil dramatically while keeping the crunch."]]),
"Tracking & scales": ("You can't manage what you don't measure. A kitchen scale teaches portions; a bathroom scale tracks your weekly average; a tape measure shows waist changes the scale hides; a fitness tracker keeps steps and sleep honest. You don't need everything — a scale and a tape cover the essentials.", [["How often should I weigh myself?","3–7 mornings a week, and judge the weekly average rather than single days."],["Are smart scales' body fat readings accurate?","Not very — use them for trends, not exact numbers."]]),
"Recovery & sleep": ("Recovery is where progress actually happens. Sleep is the biggest lever: a dark, quiet, cool room helps, so blackout curtains, an eye mask and earplugs are cheap upgrades. Foam rollers, massage balls and massage guns can ease soreness and help you feel ready to train, though they won't replace sleep and sensible training.", [["Do foam rollers help recovery?","They can reduce soreness and feel good; they're a nice extra, not a must."],["Does magnesium help sleep?","Some people find it helpful, but evidence is mixed — check with your GP."]]),
"Apparel & bags": ("Good gear makes training more comfortable, not more effective — so buy what you'll actually wear. A gym bag with a shoe compartment, a water bottle, comfortable shorts or leggings and flat shoes for lifting cover most needs. Straps, a belt and wrist wraps only become useful once your lifts get heavy.", [["Do beginners need a lifting belt?","No. Learn to brace first; consider a belt once your squats and deadlifts are heavy."],["What shoes are best for the gym?","Flat, stable shoes for lifting; cushioned running shoes for running."]])}
DANPICKS = ["r1whey", "isopure", "levrone"]
def grid(keys, _p=pcard, _A=A):
    out = ""
    for k in keys:
        if k in _A: out += _p(k, _A[k])
    return "<div class='affgrid'>" + out + "</div>"
disc = "<p class='meta'>danfitnz earns a small commission on some links at no extra cost to you. As an Amazon Associate, danfitnz earns from qualifying purchases. <a href='/affiliate-disclosure/'>How this works</a></p>"
catnav = "<div class='chips2'>" + "".join(f"<a class='chip' href='/shop/{gslug(g)}/'>{E(g)}</a>" for g in groups) + "</div>"
shop_body = (f"<h1>The danfitnz shop</h1><p class='lead'>{len(A)} simple, useful products we recommend for fat loss, muscle and home training — with honest buying guides. No fads, no detox teas.</p>{disc}{catnav}{ad('top')}"
             "<h2>Protein I've used <small style='font-weight:400'>— Dan's picks</small></h2><p>These are the whey brands Dan used while losing 20 kg on 16:8 intermittent fasting.</p>" + grid(DANPICKS) +
             "<h2>Starter kits</h2><div class='affgrid'>" + "".join(f'<div class="card" style="margin:0"><b>{E(n)}</b><ul style="margin:8px 0 0;padding-left:18px">' + "".join(f'<li><a href="{E(A[i]["url"])}" rel="sponsored nofollow noopener" target="_blank">{E(A[i]["name"])}</a></li>' for i in items if i in A) + "</ul></div>" for n, items in KITS) + "</div>" +
             "".join(f"<h2>{E(g)}</h2>" + grid([k for k, v in items if k not in DANPICKS][:6]) + f"<p><a class='cta' href='/shop/{gslug(g)}/'>See all {len(items)} in {E(g)} + buying guide →</a></p>" for g, items in groups.items()) +
             "<p class='meta'>Saw a product in a video? <a href='/go/'>All gear links from Reels and Shorts →</a> · <a href='/gifts/'>Fitness gift guide →</a></p><p class='note'>Supplements are optional. Food, training and sleep come first. Check with your GP before taking supplements, especially if you take medication.</p>" + follow_box())
page("shop/", "Fitness Gear & Supplements We Recommend | danfitnz Shop", "Fitness gear and supplements danfitnz recommends for fat loss, muscle and home training: protein, creatine, dumbbells, bands, kitchen tools and more.",
     shop_body, [{"@type": "ItemList", "name": "danfitnz recommended products", "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": v["name"], "url": v["url"], "image": f"{BASE}/products/{k}.png"} for i, (k, v) in enumerate(A.items())]},
                 bc([("Home", BASE + "/"), ("Shop", f"{BASE}/shop/")])])
EXTRA_URLS.append("shop/")
for g, items in groups.items():
    gs = gslug(g); guide, gfaq = GUIDE.get(g, ("", []))
    keys = ([k for k in DANPICKS] if g == "Protein & supplements" else []) + [k for k, v in items if k not in DANPICKS]
    body = (f"<p class='meta'><a href='/shop/'>Shop</a></p><h1>{E(g)}</h1>{disc}{catnav}<h2>Buying guide</h2><p>{E(guide)}</p>{ad('top')}"
            + (f"<h2>Protein I've used — Dan's picks</h2>" + grid(DANPICKS) + "<h2>More options</h2>" if g == "Protein & supplements" else "<h2>Our picks</h2>")
            + grid([k for k in keys if k not in DANPICKS]) + ("<h2>FAQ</h2>" + "".join(f"<h3>{E(q)}</h3><p>{E(a)}</p>" for q, a in gfaq) if gfaq else "") + follow_box())
    sch = [{"@type": "ItemList", "name": f"{g} — danfitnz picks", "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": A[k]["name"], "url": A[k]["url"], "image": f"{BASE}/products/{k}.png"} for i, k in enumerate(keys)]},
           bc([("Home", BASE + "/"), ("Shop", f"{BASE}/shop/"), (g, f"{BASE}/shop/{gs}/")])]
    if gfaq: sch.append({"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in gfaq]})
    page(f"shop/{gs}/", f"{g}: Best Picks & Buying Guide | danfitnz", f"How to choose {g.lower()} for fat loss and training, plus {len(keys)} honest picks from danfitnz.", body, sch)
    EXTRA_URLS.append(f"shop/{gs}/")
GIFTS = [("Under $25", ["shaker", "jumprope", "loopbands", "measuring", "sleepmask", "lacrosse", "bottle", "yogastrap", "tape", "gymtowel"]),
         ("Under $50", ["bands", "abwheel", "foamroller", "mat", "pullupbar", "lunchbox", "scale", "journal", "gloves", "yogablocks"]),
         ("Under $100", ["kettlebell", "creatine", "whey", "bodyscale", "airfryer", "runbelt", "massagegun", "gymbag", "vest", "blender"]),
         ("For beginners", ["mat", "bands", "shaker", "scale", "bottle", "gymbag"]),
         ("For the home gym", ["dumbbells", "bench", "kettlebell", "pullupbar", "gymflooring", "tubebands"]),
         ("For runners & walkers", ["runshoes", "gpswatch", "runbelt", "reflective", "earbuds", "compression"])]
gift_body = (f"<h1>Fitness Gift Guide (Black Friday & Christmas)</h1><p class='lead'>Useful gifts for anyone getting fitter — sorted by budget and by type of person. Prices change often, so check the current deal before you buy; budget tiers are a rough guide.</p>{disc}{ad('top')}"
             + "".join(f"<h2>{E(t)}</h2>" + grid(keys) for t, keys in GIFTS) + "<p><a class='cta' href='/shop/'>Browse the full shop →</a></p>" + follow_box())
page("gifts/", "Fitness Gift Guide: Black Friday & Christmas Ideas | danfitnz", "Fitness gift ideas under $25, $50 and $100 for beginners, home gym fans and runners — honest picks for Black Friday and Christmas from danfitnz.",
     gift_body, [bc([("Home", BASE + "/"), ("Gift guide", f"{BASE}/gifts/")])])
EXTRA_URLS.append("gifts/")

if os.path.isdir(os.path.join(HERE, "products")): shutil.copytree(os.path.join(HERE, "products"), os.path.join(OUT, "products"), dirs_exist_ok=True)
# ---------- /go/ short links: danfitnz.nz/go/creatine?s=ig ----------
import json as _json
PT = {k: v for k, v in CFG.get("platform_tags", {}).items() if not k.startswith("_") and v}
DEF = CFG.get("amazon_default_tag", "danfitnz-20")
for k, v in A.items():
    d = os.path.join(OUT, "go", k); os.makedirs(d, exist_ok=True)
    u = v["url"]
    open(os.path.join(d, "index.html"), "w").write(f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{E(v['name'])} | danfitnz</title>
<noscript><meta http-equiv="refresh" content="0;url={E(u)}"></noscript>
<script>(function(){{var u={_json.dumps(u)},pt={_json.dumps(PT)},s=(new URLSearchParams(location.search).get('s')||'').toLowerCase(),t=pt[s];
if(t&&u.indexOf('tag={DEF}')>-1)u=u.replace('tag={DEF}','tag='+t);location.replace(u);}})();</script></head>
<body style="font-family:sans-serif;background:#0e0f12;color:#eee;padding:40px">Taking you to {E(v['name'])} on {E(v['store'])}… <a style="color:#c6ff3d" href="{E(u)}" rel="sponsored nofollow">Tap here if nothing happens</a>.<br><small>As an Amazon Associate, danfitnz earns from qualifying purchases.</small></body></html>""")
go_rows = "".join(f"<li><a href='/go/{k}/' rel='sponsored nofollow'>danfitnz.nz/go/{k}</a> — {E(v['name'])}</li>" for k, v in A.items())
page("go/", "Quick gear links | danfitnz", "Short links to every product danfitnz recommends in videos.",
     f"<h1>Gear from the videos</h1><p class='lead'>Saw something in a Reel or Short? Find it here.</p><p class='meta'>Affiliate links: danfitnz may earn a small commission at no extra cost to you. As an Amazon Associate, danfitnz earns from qualifying purchases.</p><ul>{go_rows}</ul><p><a class='cta' href='/shop/'>Browse the full shop →</a></p>",
     [bc([("Home", BASE + "/"), ("Gear links", f"{BASE}/go/")])])

# ---------- Pinterest: pin images + per-board RSS feeds (auto-publish) ----------
from graphics import pin_image
import datetime as _dt
PIN_BOARDS = {"fat-loss-tips": "Fat Loss Tips", "high-protein-recipes": "High-Protein Recipes", "desi-protein-recipes": "Desi Protein Recipes",
              "home-workouts": "Home Workouts", "motivation-discipline": "Motivation & Discipline", "hormones-health": "Hormones & Health",
              "fitness-gear": "Fitness Gear", "fitness-gift-ideas": "Fitness Gift Ideas"}
CAT2BOARD = {"fat-loss": "fat-loss-tips", "walking-cardio": "fat-loss-tips", "myths-science": "fat-loss-tips", "intermittent-fasting": "fat-loss-tips", "keto-low-carb": "fat-loss-tips", "body-recomposition": "fat-loss-tips", "eating-out-takeaways": "fat-loss-tips",
             "nutrition": "high-protein-recipes", "high-protein-recipes": "high-protein-recipes", "meal-prep-budget": "high-protein-recipes", "supplements": "high-protein-recipes",
             "desi-fitness-food": "desi-protein-recipes", "ramadan-fitness": "desi-protein-recipes",
             "training": "home-workouts", "home-workouts": "home-workouts", "gym-programs-strength": "home-workouts", "beginners": "home-workouts", "lean-muscle-gain": "home-workouts", "calisthenics": "home-workouts", "mobility-flexibility": "home-workouts", "running": "home-workouts",
             "motivation-discipline": "motivation-discipline", "stress-mindset": "motivation-discipline", "busy-professional-fitness": "motivation-discipline", "transformations": "motivation-discipline",
             "hormones": "hormones-health", "sleep-recovery": "hormones-health", "gut-health": "hormones-health", "womens-fitness": "hormones-health", "fitness-over-40": "hormones-health",
             "gear-guides": "fitness-gear"}
PIN_ITEMS = {b: [] for b in PIN_BOARDS}
_today = _dt.date.fromisoformat(TODAY)
for p in LIVE:
    if not p.get("v2"): continue
    b = CAT2BOARD.get(p["category"], "fat-loss-tips")
    for n, (delay, variant) in enumerate([(0, ""), (14, "b"), (30, "c")]):
        rel = _dt.date.fromisoformat(p.get("updated", p["date"])) + _dt.timedelta(days=delay)
        if rel > _today: continue
        ip = f"pins/post-{p['slug']}{('-' + variant) if variant else ''}.png"
        sub = [p["desc"], (p.get("takeaways") or [p["desc"]])[0], (p.get("takeaways") or [p["desc"], p["desc"]])[min(1, len(p.get("takeaways") or [1]) - 1)]][n]
        pin_image(f"{OUT}/{ip}", p["title"], CATS.get(p["category"], ""), sub)
        PIN_ITEMS[b].append((rel, p["title"] + ("" if n == 0 else " — " + ["", "Key tips", "Save this guide"][n]), f"{BASE}/blog/{p['slug']}/", f"{BASE}/{ip}", sub))
_start = _dt.date(2026, 11, 6)
for i, (k, v) in enumerate(A.items()):
    # first 8 products already pinned 6-7 Nov; then slowed to 1 product every 2 days (Pinterest favours non-salesy accounts)
    rel = _start + _dt.timedelta(days=i // 4) if i < 8 else _dt.date(2026, 11, 9) + _dt.timedelta(days=2 * (i - 8))
    if rel > _today: continue
    ip = f"pins/product-{k}.png"
    pin_image(f"{OUT}/{ip}", v["name"], v.get("group", "Fitness gear"), v["why"], os.path.join(HERE, "products", f"{k}.png"))
    link = f"{BASE}/shop/{gslug(v.get('group', ''))}/" if v.get("group") else f"{BASE}/shop/"
    PIN_ITEMS["fitness-gear"].append((rel, f"{v['name']} — danfitnz pick", link, f"{BASE}/{ip}", v["why"] + " (affiliate link)"))
    if any(k in keys for _, keys in GIFTS) and _dt.date(2026, 11, 6) <= rel <= _dt.date(2026, 11, 7):  # no duplicate gift pins after 7 Nov
        PIN_ITEMS["fitness-gift-ideas"].append((rel, f"Gift idea: {v['name']}", f"{BASE}/gifts/", f"{BASE}/{ip}", v["why"] + " (affiliate link)"))
# Recipe pins: 1 a day from 7 Nov (search-friendly titles), re-pinned with a new design 21 days later
_rstart = _dt.date(2026, 11, 7); _rn = 0
for r in REELS:
    if r.get("type") != "meal": continue
    _nm = tcase(" ".join(r["title"])); _sl = slugify(_nm); _kc = re.sub(r"\D", "", r["macros"][0]); _pg = re.sub(r"\D", "", r["macros"][1])
    _desi = any(x in _nm.lower() for x in ("karahi", "keema", "dal", "lassi", "bhurji", "tikka", "roti", "chana"))
    for _d, _v, _kick in [(0, "", "High-protein recipe"), (21, "-b", "Save for meal prep")]:
        rel = _rstart + _dt.timedelta(days=_rn + _d)
        if rel > _today: continue
        ip = f"pins/recipe-{_sl}{_v}.png"
        from graphics import stat_card as _sc
        _card = _sc(os.path.join(__import__("tempfile").gettempdir(), f"dfz-macro-{_sl}.png"), f"{_pg}g", "PROTEIN", _kc, "KCAL")
        pin_image(f"{OUT}/{ip}", _nm, _kick, "Per serve. Easy, fat-loss friendly recipe.", _card)
        PIN_ITEMS["desi-protein-recipes" if _desi else "high-protein-recipes"].append((rel, f"{_nm} ({_pg}g Protein, {_kc} kcal) | Easy High-Protein Recipe", f"{BASE}/recipes/{_sl}/", f"{BASE}/{ip}",
            f"Easy {_nm.lower() if _nm.lower().startswith('high-protein') else 'high-protein ' + _nm.lower()}: about {_kc} kcal and {_pg} g protein per serve. Simple ingredients, step-by-step method. Great for fat loss and meal prep."))
    _rn += 1
# One-off pins on 7 Nov: transformation (real before/after photo) + gift guide + free plan
_d7 = _dt.date(2026, 11, 7)
if _today >= _d7:
    PIN_ITEMS["motivation-discipline"].append((_d7, "How I Lost 20 kg (44 lb) in 5 Months While Working Full-Time", f"{BASE}/blog/how-i-lost-20kg-in-5-months/", f"{BASE}/media/dan-before-after.jpg",
        "My real before and after: 93 kg to about 73 kg in 5 months with 16:8 fasting, around 1,800 kcal, 130 g protein a day and late-night gym sessions. What worked, what stalled, and the plan."))
    pin_image(f"{OUT}/pins/free-7-day-plan.png", "Free 7-Day Fat Loss Kickstart", "Free PDF", "7 days of simple meals, 3 home workouts, a shopping list and a protein cheat sheet.", os.path.join(HERE, "media", "kickstart_preview.png"))
    PIN_ITEMS["fat-loss-tips"].append((_d7, "Free 7-Day Fat Loss Meal Plan + Home Workouts (PDF)", f"{BASE}/free/", f"{BASE}/pins/free-7-day-plan.png",
        "Free 7-day fat loss kickstart: easy meals (everyday + desi), 3 short home workouts with photos, a shopping list and a protein cheat sheet. Beginner friendly."))
    pin_image(f"{OUT}/pins/gift-guide.png", "Fitness Gift Ideas Under $25, $50 & $100", "Gift guide", "Honest picks for beginners, home gym fans and runners. Black Friday & Christmas.", os.path.join(HERE, "media", "gift_collage.png"))
    PIN_ITEMS["fitness-gift-ideas"].append((_d7, "Fitness Gift Ideas Under $25, $50 and $100 (Black Friday & Christmas)", f"{BASE}/gifts/", f"{BASE}/pins/gift-guide.png",
        "Useful fitness gifts sorted by budget and by type of person: beginners, home gym fans, runners. Honest picks (affiliate links)."))
def _rss(b, items):
    items = sorted(items, key=lambda x: x[0], reverse=True)[:50]
    def rfc2(d): return _dt.datetime(d.year, d.month, d.day, 6, 0).strftime("%a, %d %b %Y %H:%M:%S +1300")
    return ('<?xml version="1.0" encoding="UTF-8"?><rss version="2.0" xmlns:media="http://search.yahoo.com/mrss/"><channel>'
            f"<title>danfitnz — {E(PIN_BOARDS[b])}</title><link>{BASE}/</link><description>danfitnz {E(PIN_BOARDS[b])}</description>"
            + "".join(f"<item><title>{E(t)}</title><link>{E(l)}</link><guid isPermaLink=\"false\">{E(img)}</guid><pubDate>{rfc2(d)}</pubDate><description>{E(s)}</description><enclosure url=\"{E(img)}\" type=\"{'image/jpeg' if img.endswith('.jpg') else 'image/png'}\" length=\"0\"/><media:content url=\"{E(img)}\" medium=\"image\"/></item>" for d, t, l, img, s in items)
            + "</channel></rss>")
# ---------- Exercise + workout library (adds workout/exercise pins to PIN_ITEMS) ----------
if EXDATA:
    import sys as _sys; _sys.path.insert(0, HERE)
    import workouts_gen as _wg
    _wg.run(globals())
os.makedirs(f"{OUT}/pins", exist_ok=True)
for b, items in PIN_ITEMS.items():
    open(f"{OUT}/pins/{b}.xml", "w").write(_rss(b, items))

