# Executed inside site_build.py (shares its namespace): interactive tools, plan builder, Ask danfitnz, blog.
EXTRA_URLS = []
TOOL_CSS = """<style>
.tool{background:var(--card);border-radius:18px;padding:20px;margin:18px 0}
.tool label{display:block;font-weight:600;font-size:14px;color:var(--muted);margin:12px 0 4px}
.tool input,.tool select{width:100%;background:#111318;border:1px solid var(--line);color:var(--text);border-radius:12px;padding:12px;font:inherit}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.seg{display:flex;gap:8px;flex-wrap:wrap}.seg button{flex:1;min-width:90px;background:#111318;border:1px solid var(--line);color:var(--text);border-radius:12px;padding:11px;font:inherit;font-weight:700;cursor:pointer}
.seg button.on{background:var(--lime);color:var(--bg);border-color:var(--lime)}
.go{width:100%;margin-top:16px;background:var(--lime);color:var(--bg);border:0;border-radius:999px;padding:14px;font:inherit;font-weight:900;cursor:pointer;font-size:17px}
.res{display:none;margin-top:18px;scroll-margin-top:80px}.res.show{display:block}
.big{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px}.big div{background:#111318;border-radius:14px;padding:14px}.big b{display:block;font-size:28px;font-weight:900;color:var(--lime)}.big span{color:var(--muted);font-size:13px}
.day{background:#111318;border-radius:14px;padding:12px 14px;margin:8px 0}.day b{color:var(--lime)}
.ans{background:#111318;border-radius:14px;padding:14px;margin:10px 0}.ans a{font-weight:800}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.chips button{background:#111318;border:1px solid var(--line);color:var(--text);border-radius:999px;padding:8px 12px;font:inherit;font-size:14px;cursor:pointer}
@media(max-width:520px){.row{grid-template-columns:1fr}}
</style>"""
SHARED_JS = r"""<script>
const PFX='__PFX__';
function segs(){document.querySelectorAll('.seg').forEach(g=>g.querySelectorAll('button').forEach(b=>b.onclick=()=>{g.querySelectorAll('button').forEach(x=>x.classList.remove('on'));b.classList.add('on');}));}
function sv(id){const b=document.querySelector('#'+id+' .on');return b?b.dataset.v:null}
function nv(id){return parseFloat(document.getElementById(id).value)}
function bmr(sex,kg,cm,age){return 10*kg+6.25*cm-5*age+(sex==='m'?5:-161)}
function r10(x){return Math.round(x/10)*10}
segs();
(function(){const YTU='https://www.youtube.com/channel/UCOWbB203EHcPglSFcwW2j3g';let shown=false;
const css=document.createElement('style');css.textContent='.ytm{position:fixed;inset:0;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;z-index:999;padding:16px}.ytm>div{background:#1C1E24;border-radius:20px;max-width:420px;width:100%;padding:24px;text-align:center;position:relative}.ytm h3{margin:6px 0 8px;font-size:22px}.ytm p{color:#A0A3AD;margin:0 0 16px}.ytm a.ytb{display:block;background:#FF0033;color:#fff;border-radius:999px;padding:14px;font-weight:900;text-decoration:none;font-size:17px}.ytm button{background:none;border:0;color:#A0A3AD;margin-top:12px;font:inherit;cursor:pointer}';document.head.appendChild(css);
function pop(){if(shown)return;try{if(sessionStorage.getItem('ytp'))return;sessionStorage.setItem('ytp','1')}catch(e){}shown=true;
const m=document.createElement('div');m.className='ytm';m.innerHTML='<div role="dialog" aria-label="Subscribe on YouTube"><div style="font-size:42px">▶</div><h3>Your result is ready!</h3><p>Get a new fat-loss tip every day. Subscribe to danfitnz on YouTube, it\'s free.</p><a class="ytb" href="'+YTU+'?sub_confirmation=1" target="_blank" rel="noopener">Subscribe on YouTube</a><button type="button">Maybe later</button></div>';
m.addEventListener('click',ev=>{if(ev.target===m||ev.target.tagName==='BUTTON'){try{gtag('event','youtube_popup_dismiss',{page:location.pathname})}catch(x){}m.remove()}});document.body.appendChild(m);try{gtag('event','youtube_popup_view',{page:location.pathname})}catch(x){}}
const out=document.getElementById('out');if(out&&!document.getElementById('q'))new MutationObserver(()=>{if(out.classList.contains('show'))setTimeout(pop,1400)}).observe(out,{attributes:true,childList:true});})();

(function(){var tool=document.querySelector('.tool');if(!tool||!(document.getElementById('kg')||document.getElementById('cm')))return;
var U='metric';try{U=localStorage.getItem('dfz_units')||''}catch(e){}if(!U)U=/en-(US|GB|LR|MM)/.test(navigator.language||'')?'imperial':'metric';
var seg=document.createElement('div');seg.innerHTML='<label>Units</label><div class="seg" id="units"><button type="button" data-v="metric">Metric (kg, cm)</button><button type="button" data-v="imperial">Imperial (lb, ft)</button></div>';tool.insertBefore(seg,tool.firstChild);
var cm=document.getElementById('cm'),ftw=null;
if(cm){ftw=document.createElement('div');ftw.className='row';ftw.style.display='none';ftw.innerHTML='<div><input id="ft" type="number" inputmode="numeric" placeholder="ft" aria-label="Height feet"></div><div><input id="inch" type="number" inputmode="decimal" placeholder="in" aria-label="Height inches"></div>';cm.parentNode.appendChild(ftw);}
var LEN=['neck','waist','hip'];
function lab(id,t){var l=document.querySelector('label[for="'+id+'"]');if(l)l.textContent=l.textContent.replace(/\((cm|kg|in|lb|ft, in)\)/,'('+t+')')}
function r1(x){return Math.round(x*10)/10}
function apply(to,convert){var from=U;U=to;try{localStorage.setItem('dfz_units',to)}catch(e){}
 seg.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.dataset.v===to)});
 var kg=document.getElementById('kg');
 if(convert&&from!==to){
  if(kg&&kg.value)kg.value=to==='imperial'?Math.round(kg.value/0.45359237):r1(kg.value*0.45359237);var gk=document.getElementById('goalkg');if(gk&&gk.value)gk.value=to==='imperial'?Math.round(gk.value/0.45359237):r1(gk.value*0.45359237);
  LEN.forEach(function(id){var el=document.getElementById(id);if(el&&el.value)el.value=to==='imperial'?r1(el.value/2.54):Math.round(el.value*2.54)});
  if(cm){if(to==='imperial'){var tin=(parseFloat(cm.value)||0)/2.54;document.getElementById('ft').value=Math.floor(tin/12);document.getElementById('inch').value=Math.round(tin%12)}else{var f=parseFloat(document.getElementById('ft').value)||0,i=parseFloat(document.getElementById('inch').value)||0;cm.value=Math.round(f*30.48+i*2.54)}}
 }
 if(cm){cm.style.display=to==='imperial'?'none':'';ftw.style.display=to==='imperial'?'':'none';lab('cm',to==='imperial'?'ft, in':'cm')}
 lab('kg',to==='imperial'?'lb':'kg');lab('goalkg',to==='imperial'?'lb':'kg');LEN.forEach(function(id){lab(id,to==='imperial'?'in':'cm')});
}
seg.querySelectorAll('button').forEach(function(b){b.onclick=function(){apply(b.dataset.v,true)}});
var start=U;U='metric';apply(start,true);
var out=document.getElementById('out');if(out){var busy=false;new MutationObserver(function(){if(busy||U!=='imperial')return;busy=true;out.innerHTML=out.innerHTML.replace(/(\d+(?:\.\d+)?)\s?kg(?!\s?\()/g,function(m,n){return m+' ('+(parseFloat(n)*2.2046).toFixed(1)+' lb)'});setTimeout(function(){busy=false},0)}).observe(out,{childList:true,subtree:true})}
window.nv=function(id){var el=document.getElementById(id);var v=parseFloat(el&&el.value);
 if(U==='imperial'){if(id==='cm'){var f=parseFloat(document.getElementById('ft').value)||0,i=parseFloat(document.getElementById('inch').value)||0;return f*30.48+i*2.54}
  if(id==='kg'||id==='goalkg')return v*0.45359237;if(LEN.indexOf(id)>=0)return v*2.54}return v};
})();
</script>"""

EMBEDS = {"calorie-deficit-calculator": 760, "protein-calculator": 620, "bmi-calculator": 600, "body-fat-calculator": 680}
EMBED_JS = SHARED_JS.split("(function(){const YTU")[0] + "</script>"
def embed_box(path, h1):
    nm = path.split("/")[1]; src = f"{BASE}/embed/{nm}/"
    code = (f'<iframe src="{src}" width="100%" height="{EMBEDS[nm]}" style="border:0;border-radius:16px;max-width:560px" loading="lazy" title="{h1}"></iframe>\n'
            f'<p style="font-size:13px">{h1} by <a href="{BASE}/{path}">danfitnz</a></p>')
    return (f"<h2>Add this {E(h1.lower())} to your website</h2><p>Run a fitness, health or food blog? Embed this free calculator on your site — copy the code below. "
            f"It's free, ad-free and mobile friendly. Please keep the credit link.</p><textarea readonly onclick=\"this.select()\" style=\"width:100%;height:110px;background:#111318;color:#F5F5F5;border:1px solid #2A2D35;border-radius:12px;padding:10px;font:13px monospace\">{E(code)}</textarea>")
def write_embed(path, h1, form, js):
    nm = path.split("/")[1]; d = f"{OUT}/embed/{nm}"; os.makedirs(d, exist_ok=True)
    open(f"{d}/index.html", "w").write(f"""<!doctype html><html lang="en-NZ"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{E(h1)} | danfitnz</title>
<meta name="robots" content="noindex,follow"><link rel="canonical" href="{BASE}/{path}"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
<style>:root{{--bg:#0E0F12;--card:#1C1E24;--lime:#C6FF3D;--text:#F5F5F5;--muted:#A0A3AD;--line:#2A2D35}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:Inter,system-ui,sans-serif}}a{{color:var(--lime)}}.tool{{margin:0!important}}.cr{{text-align:center;font-size:13px;color:var(--muted);padding:8px}}</style>
{TOOL_CSS}</head><body><div class="tool"><h2 style="margin:0 0 6px;font-size:20px">{E(h1)}</h2>{form}</div>
<p class="cr">Free {E(h1.lower())} by <a href="{BASE}/{path}" target="_blank" rel="noopener">danfitnz.nz</a></p>
{EMBED_JS.replace("__PFX__", BASE)}<script>{js.replace("${PFX}", BASE)}</script>
<script>document.addEventListener('click',function(e){{var a=e.target.closest('a');if(a&&a.href.indexOf('{BASE}')===0)a.target='_blank'}})</script></body></html>""")

def tool_page(path, h1, title, desc, lead, form, js, explain, faqs):
    faq_html = "".join(f"<h3>{E(q)}</h3><p>{E(a)}</p>" for q, a in faqs)
    if path.split("/")[1] in EMBEDS:
        write_embed(path, h1, form, js); explain = explain + embed_box(path, h1)
    body = f"""<p class="meta"><a href="/tools/">Free fitness tools</a></p><h1>{E(h1)}</h1><p class="lead">{E(lead)}</p>{TOOL_CSS}
<div class="tool">{form}</div>{"" if "plan-builder" in path else SIGNUP("calc-"+path.split("/")[1], "Got your number? Get your free personalised plan")}{explain}<h2>FAQ</h2>{faq_html}
<p class="note">Estimates only, based on standard formulas. Not medical advice. If you have a medical condition, are pregnant, or are under 18, talk to your GP first.</p>{follow_box()}{SHARED_JS}<script>{js}</script>"""
    sch = [{"@type": "WebApplication", "name": h1, "url": f"{BASE}/{path}", "applicationCategory": "HealthApplication", "operatingSystem": "Any",
            "offers": {"@type": "Offer", "price": "0", "priceCurrency": "NZD"}, "description": desc, "publisher": {"@id": BASE + "/#org"}},
           {"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in faqs]},
           bc([("Home", BASE + "/"), ("Free fitness tools", f"{BASE}/tools/"), (h1, f"{BASE}/{path}")])]
    page(path, title, desc, body.replace("__PFX__", PREFIX), sch)
    EXTRA_URLS.append(path)
    return dict(path=path, name=h1, desc=desc)

SEXAGE = """<label>Sex</label><div class="seg" id="sex"><button data-v="m" class="on">Male</button><button data-v="f">Female</button></div>
<div class="row"><div><label for="age">Age</label><input id="age" type="number" inputmode="numeric" value="30" min="15" max="90"></div>
<div><label for="cm">Height (cm)</label><input id="cm" type="number" inputmode="decimal" value="172"></div></div>
<div class="row"><div><label for="kg">Weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="85"></div>
<div><label for="act">Activity</label><select id="act"><option value="1.2">Desk job, little exercise</option><option value="1.375" selected>Light: 1–3 workouts/week</option><option value="1.55">Moderate: 3–5 workouts/week</option><option value="1.725">Very active: 6–7 workouts/week</option><option value="1.9">Physical job + training</option></select></div></div>"""

tools = []
tools.append(tool_page("tools/calorie-deficit-calculator/", "Calorie Deficit Calculator",
    "Calorie Deficit Calculator for Fat Loss | danfitnz",
    "Free calorie deficit calculator: find your maintenance calories (TDEE), a safe fat-loss target and your daily protein in seconds.",
    "Find your maintenance calories, a realistic fat-loss target and how much protein to eat. Takes 20 seconds.",
    SEXAGE + """<label>Goal</label><div class="seg" id="goal"><button data-v="0.10">Slow &amp; easy</button><button data-v="0.20" class="on">Steady fat loss</button><button data-v="0.25">Faster</button></div>
<button class="go" onclick="calc()">Calculate my calories</button><div class="res" id="out"></div>""",
    r"""function calc(){const sex=sv('sex'),age=nv('age'),cm=nv('cm'),kg=nv('kg'),act=parseFloat(document.getElementById('act').value),g=parseFloat(sv('goal'));
if(!(age&&cm&&kg)){return}
const b=bmr(sex,kg,cm,age),t=b*act;let target=t*(1-g);const floor=sex==='m'?1500:1200;if(target<floor)target=floor;
const deficit=t-target,wk=deficit*7/7700,pro=Math.round(kg*1.8),proLo=Math.round(kg*1.6),proHi=Math.round(kg*2.2);
const fat=Math.round(target*0.27/9),carb=Math.max(0,Math.round((target-pro*4-fat*9)/4));
document.getElementById('out').innerHTML=`<div class="big"><div><b>${r10(t)}</b><span>maintenance kcal/day</span></div><div><b>${r10(target)}</b><span>fat-loss target kcal/day</span></div><div><b>${pro}g</b><span>protein/day (${proLo}–${proHi}g)</span></div><div><b>~${wk.toFixed(2)} kg</b><span>expected loss per week</span></div></div>
<p style="margin-top:14px">Rough daily macros: <b>${pro}g protein · ${fat}g fat · ${carb}g carbs</b>.</p><p>Stick to this for 2 weeks, weigh yourself most mornings and use the weekly average. Not dropping? Take off another 100–150 kcal. <a href="${PFX}/tools/plan-builder/">Turn this into a 7-day plan →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    """<h2>How this calculator works</h2><p>It uses the Mifflin-St Jeor equation, one of the most accurate everyday formulas for resting calories, then multiplies by your activity level to estimate maintenance (TDEE). The fat-loss target takes 10–25% off maintenance, never going below 1,200 kcal (women) or 1,500 kcal (men). Protein is set at 1.6–2.2g per kg of bodyweight, the range research supports for keeping muscle while dieting.</p>""",
    [("How big should my calorie deficit be?", "For most people, 15–20% below maintenance (often 300–600 kcal a day) gives steady fat loss of about 0.3–0.7 kg per week without wrecking energy or training."),
     ("Why am I not losing weight on my deficit?", "Daily weight bounces with water, salt and carbs. Track your weekly average for 2–3 weeks. If it's flat, lower calories by 100–150 or add 2,000 more steps a day."),
     ("Do I need to count calories forever?", "No. Count for a few weeks to learn portions, then switch to simple habits like protein first, half a plate of veg and fewer liquid calories.")]))

tools.append(tool_page("tools/protein-calculator/", "Protein Calculator", "Protein Calculator: How Much Protein Do I Need? | danfitnz",
    "Free protein calculator: find how much protein you need per day for fat loss or muscle gain, plus how much per meal.",
    "How much protein you need each day, and how to split it across your meals.",
    """<label for="kg">Weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="80">
<label>Goal</label><div class="seg" id="goal"><button data-v="1.6">General health</button><button data-v="1.8" class="on">Lose fat</button><button data-v="2.0">Build muscle</button></div>
<label for="meals">Meals per day</label><select id="meals"><option>2</option><option selected>3</option><option>4</option><option>5</option></select>
<button class="go" onclick="calc()">Calculate my protein</button><div class="res" id="out"></div>""",
    r"""function calc(){const kg=nv('kg'),f=parseFloat(sv('goal')),m=parseInt(document.getElementById('meals').value);if(!kg)return;
const p=Math.round(kg*f),per=Math.round(p/m);
document.getElementById('out').innerHTML=`<div class="big"><div><b>${p}g</b><span>protein per day</span></div><div><b>${per}g</b><span>per meal (${m} meals)</span></div></div>
<p style="margin-top:14px">Easy ways to hit ~${per}g: 150g cooked chicken breast (~45g), 3 eggs + 2 egg whites (~25g), 200g Greek yogurt (~20g), a bowl of dal with paneer (~25g). <a href="${PFX}/recipes/">See high-protein recipes →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    "<h2>Why protein matters for fat loss</h2><p>Protein is the most filling nutrient and helps you keep muscle while eating less. Most adults trying to lose fat do well on 1.6–2.2g per kg of bodyweight per day, spread over 3–4 meals.</p>",
    [("How much protein do I need to lose fat?", "Around 1.6–2.2g per kg of bodyweight per day. For an 80kg person that's roughly 130–175g."),
     ("Can I get enough protein without shakes?", "Yes. Build each meal around chicken, eggs, fish, Greek yogurt, paneer, lentils or tofu. Shakes are just convenient."),
     ("Is too much protein bad for you?", "For healthy adults, intakes in this range are considered safe. If you have kidney disease, check with your doctor.")]))

tools.append(tool_page("tools/bmi-calculator/", "BMI Calculator", "BMI Calculator (with Asian Cut-offs) | danfitnz",
    "Free BMI calculator with standard and Asian/South Asian cut-offs, plus what BMI can and can't tell you.",
    "Check your Body Mass Index, including the lower cut-offs often used for South Asian people.",
    """<div class="row"><div><label for="cm">Height (cm)</label><input id="cm" type="number" inputmode="decimal" value="172"></div><div><label for="kg">Weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="80"></div></div>
<button class="go" onclick="calc()">Calculate BMI</button><div class="res" id="out"></div>""",
    r"""function calc(){const cm=nv('cm'),kg=nv('kg');if(!(cm&&kg))return;const b=kg/((cm/100)**2);
const std=b<18.5?'Underweight':b<25?'Healthy range':b<30?'Overweight':'Obese';const asn=b<18.5?'Underweight':b<23?'Healthy range':b<27.5?'Increased risk':'High risk';
const lo=(18.5*(cm/100)**2).toFixed(0),hi=(24.9*(cm/100)**2).toFixed(0);
document.getElementById('out').innerHTML=`<div class="big"><div><b>${b.toFixed(1)}</b><span>your BMI</span></div><div><b style="font-size:20px">${std}</b><span>standard (WHO)</span></div><div><b style="font-size:20px">${asn}</b><span>Asian cut-offs</span></div></div><p style="margin-top:14px">Healthy weight range for your height (standard): <b>${lo}–${hi} kg</b>. BMI doesn't separate muscle from fat, so also check your waist. <a href="${PFX}/tools/body-fat-calculator/">Estimate body fat →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    "<h2>About BMI</h2><p>BMI is weight divided by height squared. It's a quick screening tool, not a diagnosis. Because people of South Asian descent tend to carry more body fat at the same BMI, health bodies often use lower cut-offs (23 for overweight, 27.5 for obesity).</p>",
    [("What is a healthy BMI?", "18.5–24.9 is the standard healthy range. For South Asian adults, 18.5–22.9 is often used."),
     ("Is BMI accurate if I lift weights?", "Not very. Muscular people can show as overweight. Waist size and body fat estimates give a better picture.")]))

tools.append(tool_page("tools/body-fat-calculator/", "Body Fat Calculator", "Body Fat Calculator (Tape Measure Method) | danfitnz",
    "Free body fat percentage calculator using the US Navy tape-measure method: just height, neck and waist (and hips for women).",
    "Estimate your body fat percentage with a tape measure. No scale tricks, no fancy gadgets.",
    """<label>Sex</label><div class="seg" id="sex"><button data-v="m" class="on">Male</button><button data-v="f">Female</button></div>
<div class="row"><div><label for="cm">Height (cm)</label><input id="cm" type="number" inputmode="decimal" value="172"></div><div><label for="neck">Neck (cm)</label><input id="neck" type="number" inputmode="decimal" value="38"></div></div>
<div class="row"><div><label for="waist">Waist at navel (cm)</label><input id="waist" type="number" inputmode="decimal" value="92"></div><div><label for="hip">Hips, women only (cm)</label><input id="hip" type="number" inputmode="decimal" value="100"></div></div>
<button class="go" onclick="calc()">Estimate body fat</button><div class="res" id="out"></div>""",
    r"""function calc(){const sex=sv('sex'),h=nv('cm'),n=nv('neck'),w=nv('waist'),hp=nv('hip');let bf;
if(sex==='m'){if(w<=n)return;bf=495/(1.0324-0.19077*Math.log10(w-n)+0.15456*Math.log10(h))-450}else{if(w+hp<=n)return;bf=495/(1.29579-0.35004*Math.log10(w+hp-n)+0.22100*Math.log10(h))-450}
const c=sex==='m'?(bf<14?'Athletic':bf<18?'Fit':bf<25?'Average':'Above average'):(bf<21?'Athletic':bf<25?'Fit':bf<32?'Average':'Above average');
document.getElementById('out').innerHTML=`<div class="big"><div><b>${bf.toFixed(1)}%</b><span>estimated body fat</span></div><div><b style="font-size:20px">${c}</b><span>general category</span></div></div><p style="margin-top:14px">Re-measure every 2–4 weeks at the same time of day. A shrinking waist is one of the best signs you're losing fat. <a href="${PFX}/tools/calorie-deficit-calculator/">Set your calorie target →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    "<h2>How to measure</h2><p>Measure your neck just below the Adam's apple and your waist at the navel (men) or narrowest point (women), with the tape snug but not squeezing. Women also measure hips at the widest point. The US Navy formula is usually within a few percent of lab tests.</p>",
    [("How accurate is the tape measure body fat method?", "Typically within about 3–4% of lab methods, and very good for tracking change over time if you measure the same way."),
     ("What's a healthy body fat percentage?", "Roughly 10–20% for men and 18–30% for women is a common healthy range.")]))

PLAN_FORM = SEXAGE + """<label>Goal</label><div class="seg" id="goal"><button data-v="lose" class="on">Lose fat</button><button data-v="tone">Get fit &amp; toned</button><button data-v="gain">Build muscle</button></div>
<label>Do you want gym or home workouts?</label><div class="seg" id="where"><button data-v="home" class="on">Home workouts</button><button data-v="gym">Gym workouts</button></div>
<label>Training days per week</label><div class="seg" id="days"><button data-v="2">2</button><button data-v="3" class="on">3</button><button data-v="4">4</button><button data-v="5">5</button></div>
<label>Meals per day</label><div class="seg" id="meals"><button data-v="2">2</button><button data-v="3" class="on">3</button><button data-v="4">4</button><button data-v="5">5</button></div>
<label>Eating style</label><div class="seg" id="style"><button data-v="normal" class="on">Normal</button><button data-v="if">16:8 fasting (12pm–8pm)</button></div>
<label>Cuisine</label><div class="seg" id="cuisine"><button data-v="mix" class="on">Mix (global)</button><button data-v="d">Mostly desi</button><button data-v="e">Mostly everyday</button></div>
<label>Food</label><div class="seg" id="food"><button data-v="all" class="on">Everything</button><button data-v="egg">Vegetarian + eggs</button><button data-v="veg">Vegetarian (no eggs)</button></div>
<button class="go" onclick="plan()">Build my 7-day plan</button><div class="res" id="out"></div>"""
PLAN_JS = r"""const W={home:[['20-Minute Home Fat Burner','/workouts/20-min-home-fat-burner/'],['10-Minute Core (No Crunches)','/workouts/core-workout-no-crunches/'],['Beginner Dumbbell Full Body','/workouts/beginner-dumbbell-full-body/']],
gym:[['Push Day: Chest, Shoulders, Triceps','/workouts/push-day-workout/'],['Pull Day: Back & Biceps','/workouts/pull-day-workout/'],['Leg Day for Beginners','/workouts/leg-day-for-beginners/'],['Beginner Dumbbell Full Body','/workouts/beginner-dumbbell-full-body/']]};
// [name, type B/M/S, cuisine d/e, diet meat/fish/egg/veg, kcal, protein, items [qty,unit,food,scalable], link]
const F=[
['Egg bhurji with roti','B','d','egg',380,28,[[2,'','eggs',1],[2,'','egg whites',1],[1,'','wholemeal roti',1],[1,'tsp','oil',0],[1,'','onion & tomato',0]],'/recipes/egg-bhurji-protein-wrap/'],
['Overnight protein oats','B','e','veg',420,30,[[50,'g','rolled oats',1],[200,'g','Greek yoghurt',1],[150,'ml','milk',1],[80,'g','berries',0]],'/recipes/overnight-protein-oats/'],
['Greek yoghurt, fruit & nuts','B','e','veg',380,28,[[250,'g','Greek yoghurt',1],[1,'','banana',0],[15,'g','almonds',1]]],
['Scrambled eggs on toast','B','e','egg',450,28,[[3,'','eggs',1],[2,'slices','wholegrain toast',1],[1,'handful','spinach',0]]],
['Paneer & roti breakfast','B','d','veg',430,26,[[60,'g','paneer',1],[1,'','wholemeal roti',1],[150,'g','plain yoghurt',1],[1,'','cucumber & tomato',0]]],
['Protein smoothie','B','e','veg',420,36,[[30,'g','whey protein',1],[1,'','banana',0],[250,'ml','milk',1],[30,'g','rolled oats',1]]],
['Moong dal chilla + yoghurt','B','d','veg',380,26,[[60,'g','moong dal (dry)',1],[150,'g','plain yoghurt',1],[1,'','onion, chilli & coriander',0]]],
['Chicken tikka rice bowl','M','d','meat',580,50,[[150,'g','chicken breast',1],[0.75,'cup','cooked basmati rice',1],[100,'g','plain yoghurt (raita)',1],[1,'bowl','salad',0]],'/recipes/air-fryer-chicken-tikka/'],
['Chicken karahi with roti','M','d','meat',520,45,[[150,'g','chicken breast',1],[1,'','wholemeal roti',1],[1,'tsp','oil',0],[1,'bowl','kachumber salad',0]],'/recipes/high-protein-chicken-karahi/'],
['Keema with peas & rice','M','d','meat',600,42,[[150,'g','lean beef/chicken mince',1],[0.5,'cup','peas',1],[0.75,'cup','cooked basmati rice',1]],'/recipes/chicken-keema-with-peas/'],
['Masoor dal, rice & yoghurt','M','d','veg',560,30,[[1.5,'cup','cooked masoor dal',1],[0.75,'cup','cooked basmati rice',1],[150,'g','plain yoghurt',1]],'/recipes/protein-packed-masoor-dal/'],
['Chana masala with roti & raita','M','d','veg',560,26,[[1.5,'cup','cooked chickpeas',1],[1,'','wholemeal roti',1],[150,'g','plain yoghurt',1]]],
['Paneer tikka, salad & roti','M','d','veg',560,32,[[120,'g','paneer',1],[1,'','wholemeal roti',1],[1,'bowl','salad',0]]],
['Fish curry with rice','M','d','fish',520,42,[[180,'g','white fish',1],[0.75,'cup','cooked basmati rice',1],[1,'tsp','oil',0]]],
['Salmon, rice & greens','M','e','fish',600,38,[[150,'g','salmon fillet',1],[0.75,'cup','cooked rice',1],[1,'cup','broccoli/beans',0]]],
['Chicken & kūmara bowl','M','e','meat',520,48,[[150,'g','chicken breast',1],[150,'g','kūmara',1],[1,'cup','mixed veg',0]]],
['Beef burrito bowl','M','e','meat',620,45,[[150,'g','lean beef mince',1],[0.5,'cup','cooked rice',1],[0.5,'cup','black beans',1],[1,'','salsa & lettuce',0]]],
['Chicken salad wrap','M','e','meat',520,48,[[150,'g','chicken breast',1],[1,'','large wholemeal wrap',1],[2,'tbsp','yoghurt-mint sauce',0],[1,'bowl','salad',0]]],
['Tuna pasta salad','M','e','fish',520,42,[[1,'tin (185g)','tuna in springwater',1],[70,'g','pasta (dry)',1],[1,'cup','mixed veg',0]]],
['Chicken stir-fry with noodles','M','e','meat',560,45,[[150,'g','chicken breast',1],[60,'g','noodles (dry)',1],[1.5,'cup','stir-fry veg',0]]],
['Tofu & veg stir-fry with rice','M','e','veg',520,30,[[200,'g','firm tofu',1],[0.75,'cup','cooked rice',1],[1.5,'cup','stir-fry veg',0]]],
['Egg fried rice (lighter)','M','e','egg',520,32,[[3,'','eggs',1],[2,'','egg whites',1],[0.75,'cup','cooked rice',1],[1,'cup','mixed veg',0]]],
['Lentil & bean chilli','M','e','veg',520,28,[[1,'cup','cooked lentils',1],[0.5,'cup','kidney beans',1],[1,'','tomato & spices',0]]],
['Whey shake','S','e','veg',120,24,[[30,'g','whey protein',1]]],
['Greek yoghurt & fruit','S','e','veg',220,20,[[200,'g','Greek yoghurt',1],[1,'','piece of fruit',0]]],
['Roasted chana','S','d','veg',160,9,[[40,'g','roasted chana',1]]],
['Boiled eggs & fruit','S','e','egg',220,13,[[2,'','eggs',1],[1,'','piece of fruit',0]]],
['Tuna & crackers','S','e','fish',200,22,[[1,'tin (95g)','tuna',1],[4,'','wholegrain crackers',1]]],
['High-protein lassi','S','d','veg',200,18,[[250,'g','plain yoghurt',1],[0.5,'','mango (or ice)',0]],'/recipes/high-protein-mango-lassi/']];
const L=(x)=>`<a href="${PFX}${x[1]}">${x[0]}</a>`;
function fq(q,u){if(q>=20)return Math.round(q/5)*5;if(u===''||/slice|tin|bowl/.test(u||''))return Math.max(0.5,Math.round(q*2)/2);return Math.round(q*4)/4;}
const us=(u)=>u?((u==='g'||u==='ml')?u:' '+u):'';
function ok(m,food){if(food==='veg')return m[3]==='veg';if(food==='egg')return m[3]==='veg'||m[3]==='egg';return true;}
function plan(){const sex=sv('sex'),age=nv('age'),cm=nv('cm'),kg=nv('kg'),act=parseFloat(document.getElementById('act').value),goal=sv('goal'),where=sv('where'),d=parseInt(sv('days')),food=sv('food'),nm=parseInt(sv('meals')),st=sv('style'),cu=sv('cuisine');
if(!(age&&cm&&kg))return;const t=bmr(sex,kg,cm,age)*act;let cal=goal==='lose'?t*0.8:goal==='tone'?t*0.9:t*1.08;const fl=sex==='m'?1500:1200;if(cal<fl)cal=fl;cal=r10(cal);
const pro=Math.round(kg*(goal==='gain'?2.0:1.8)),steps=goal==='lose'?'8,000–10,000':'7,000–9,000';
const struct={2:['M','M'],3:st==='if'?['M','S','M']:['B','M','M'],4:st==='if'?['M','S','M','S']:['B','M','S','M'],5:st==='if'?['B','S','M','S','M']:['B','S','M','S','M']}[nm];
const times=st==='if'?{2:['12:00pm','7:30pm'],3:['12:00pm','3:30pm','7:30pm'],4:['12:00pm','3:00pm','6:30pm','7:45pm'],5:['12:00pm','2:00pm','4:00pm','6:00pm','7:45pm']}[nm]:{2:['12:30pm','7:00pm'],3:['7:30am','12:30pm','7:00pm'],4:['7:30am','12:30pm','4:00pm','7:00pm'],5:['7:30am','10:30am','1:00pm','4:00pm','7:00pm']}[nm];
const lab={B:'Breakfast',M:'Main meal',S:'Snack'};
const want=(i)=>cu==='d'?(i%5!==4?'d':'e'):cu==='e'?(i%5!==4?'e':'d'):(i%5<3?'e':'d');
const pools={};['B','M','S'].forEach(ty=>pools[ty]=F.filter(m=>m[1]===ty&&ok(m,food)));
const names=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],pat={2:[0,3],3:[0,2,4],4:[0,1,3,4],5:[0,1,2,4,5]}[d];const ws=W[where];
let shop={},html=`<div class="big"><div><b>${cal}</b><span>kcal per day</span></div><div><b>${pro}g</b><span>protein per day</span></div><div><b>${nm}</b><span>meals per day</span></div><div><b>${steps}</b><span>steps per day</span></div></div>`;
html+=`<p class="meta">${st==='if'?'16:8 fasting: eat between 12pm and 8pm; water, black coffee or plain tea outside that window. ':''}Calories and protein are approximate — portions are scaled to your target. Check with your GP first if you have a medical condition, are pregnant or take medication.</p><button class="go" onclick="window.print()" style="margin:8px 0">Print / save as PDF</button><h3>Your 7-day plan</h3>`;
let k=0,used={};
names.forEach((n,di)=>{const tr=pat.includes(di);const w=tr?ws[(k++)%ws.length]:null;let day=[],tk=0,tp=0;
struct.forEach((ty,mi)=>{let pool=pools[ty].filter(m=>m[2]===want(di+mi));if(!pool.length)pool=pools[ty];
pool=pool.slice().sort((a,b)=>(used[a[0]]||0)-(used[b[0]]||0));const m=pool[(di+mi)%Math.min(3,pool.length)]||pool[0];used[m[0]]=(used[m[0]]||0)+1;day.push([ty,m]);tk+=m[4];tp+=m[5];});
const f=Math.max(0.7,Math.min(1.7,cal/tk));let dk=0,dp=0;
let rows=day.map(([ty,m],mi)=>{const kk=Math.round(m[4]*f/10)*10,pp=Math.round(m[5]*f);dk+=kk;dp+=pp;
const its=m[6].map(it=>{const q=it[3]?(/egg/.test(it[2])?Math.max(1,Math.round(it[0]*f)):fq(it[0]*f,it[1])):it[0];if(it[3]){const key=it[2]+'|'+it[1];shop[key]=(shop[key]||0)+q;}else{shop[it[2]+'|'+it[1]]=shop[it[2]+'|'+it[1]]||0;}return `${q}${us(it[1])} ${it[2]}`;}).join(' · ');
const nmL=m[7]?`<a href="${PFX}${m[7]}">${m[0]}</a>`:m[0];
return `<tr><td><b>${times[mi]}</b><br><small>${lab[ty]}</small></td><td><b>${nmL}</b><br><small>${its}</small></td><td class="n">${kk} kcal<br>${pp}g P</td></tr>`;}).join('');
html+=`<div class="day"><b>${n}</b> · ${tr?'Workout: '+L(w):(di===6?'Rest + long walk':'Active rest: 30–45 min walk')}<table>${rows}<tr><td></td><td><b>Day total</b></td><td class="n"><b>${dk} kcal<br>${dp}g P</b></td></tr></table></div>`;});
const sl=Object.keys(shop).sort().map(key=>{const [nmx,u]=key.split('|');const q=shop[key];return `<li>${q?fq(q,u)+us(u)+' ':''}${nmx}</li>`}).join('');
html+=`<h3>Shopping list for the week</h3><ul style="columns:2">${sl}</ul><h3>Daily rules</h3><ul><li>Hit about ${pro}g protein a day — protein first at every meal.</li><li>Measure oil (1 tsp per serve) — it's the biggest hidden calorie source.</li><li>Swap meals freely within the same type; keep portions similar.</li><li>Water before meals; limit sugary drinks and chai sugar.</li><li>Sleep 7–9 hours. Weigh in most mornings and use the weekly average; adjust by 100–150 kcal after 2 weeks if needed.</li></ul><p>Save or print this plan. New tips daily at 6:30pm on <a href="https://www.youtube.com/channel/UCOWbB203EHcPglSFcwW2j3g?sub_confirmation=1">YouTube</a>.</p>`;
window.__plan={cal:cal,pro:pro,where:where,d:d};
if(!window.__gated)html+=`<div class="signup"><b class="sgk">FREE</b><h2>Email me this plan</h2><p>Get a link to this exact plan in your inbox (open it on any device), plus the free 7-Day Kickstart PDF.</p><form onsubmit="return sendPlan(this,'plan-builder')"><input type="email" name="em" required placeholder="Your email address" aria-label="Email address" autocomplete="email"><button type="submit">Email me my plan</button></form><p class="sgfine">Free. No spam, unsubscribe any time. Emails are sent with Kit. <a href="/affiliate-disclosure/#privacy">Privacy</a></p><div class="sgok"></div></div>`;
const o=document.getElementById('out');o.innerHTML=html;o.classList.add('show');o.scrollIntoView({behavior:'smooth'});}
const PK=['sex','goal','where','days','meals','style','cuisine','food'];
function getP(){const o={};PK.forEach(k=>o[k]=sv(k));o.age=nv('age');o.cm=Math.round(nv('cm'));o.kg=Math.round(nv('kg')*10)/10;o.act=document.getElementById('act').value;const u=document.querySelector('#units .on');o.u=u?u.dataset.v:'metric';return new URLSearchParams(o).toString()}
function sendPlan(f,where){const em=(f.em.value||'').trim();if(!em)return false;
let ifr=document.getElementById('kitf');if(!ifr){ifr=document.createElement('iframe');ifr.name='kitf';ifr.id='kitf';ifr.style.display='none';document.body.appendChild(ifr);}
const P=window.__plan||{},link='https://www.danfitnz.nz/tools/plan-builder/#'+getP();
const kf=document.createElement('form');kf.method='post';kf.action='__KIT__';kf.target='kitf';
[['email_address',em],['fields[plan_link]',link],['fields[plan_summary]',(P.cal?P.cal+' kcal/day, '+P.pro+' g protein, '+P.d+' '+P.where+' workouts a week':'')]].forEach(([n,v])=>{const i=document.createElement('input');i.type='hidden';i.name=n;i.value=v;kf.appendChild(i)});
document.body.appendChild(kf);kf.submit();try{gtag('event','email_signup',{form_location:where});gtag('event','plan_download',{plan_where:P.where||''})}catch(e){}
const ok=f.parentNode.querySelector('.sgok');if(ok)ok.innerHTML='<p style="color:var(--lime);font-weight:700;margin:10px 0 0">Done! Check your email and tap <b>Confirm</b> to get your plan link and the free PDF (check spam if it isn\'t there in 2 minutes).</p>';f.style.display='none';return false}
(function(){let q=new URLSearchParams(location.hash.slice(1));if(!q.get('kg'))q=new URLSearchParams(location.search);if(!q.get('kg'))return;const ub=v=>{const b=document.querySelector('#units [data-v="'+v+'"]');if(b)b.click()};ub('metric');
PK.forEach(k=>{const v=q.get(k);if(!v)return;document.querySelectorAll('#'+k+' button').forEach(b=>b.classList.toggle('on',b.dataset.v===v))});
['age','cm','kg'].forEach(k=>{if(q.get(k))document.getElementById(k).value=q.get(k)});if(q.get('act'))document.getElementById('act').value=q.get('act');ub(q.get('u')||'metric');window.__gated=true;plan();window.__gated=false;})();"""
PLAN_JS = PLAN_JS.replace("__KIT__", KIT_FORM)

tools.append(tool_page("tools/plan-builder/", "Personal Fat Loss Plan Builder", "Free 7-Day Fat Loss Plan Builder (Workouts + Meals) | danfitnz",
    "Answer a few quick questions and get a detailed 7-day plan: your calories and protein, 2–5 meals a day (or 16:8 fasting), portions, workouts and a shopping list.",
    "Answer a few quick questions and get a personalised 7-day plan with your calories, protein, workouts and meals.",
    PLAN_FORM, PLAN_JS,
    "<h2>How your plan is built</h2><p>Your calories come from the Mifflin-St Jeor formula and your activity level, adjusted for your goal. Workouts are picked from danfitnz routines that match where you train, and meals come from a mix of high-protein everyday and desi dishes, with portions scaled to hit your calorie target. You choose 2–5 meals a day, normal eating or 16:8 fasting, cuisine and vegetarian options, and get a weekly shopping list. Your plan is built in your browser. Your details are only sent if you choose to email yourself the plan (then your email and a link to your plan are stored with our email provider, Kit).</p>",
    [("Is this plan free?", "Yes, completely free, with no sign-up needed. If you want it emailed, enter your email after your plan appears and we send you a link to your exact plan."),
     ("How long should I follow the plan?", "Give it at least 4 weeks. Adjust calories by 100–150 if your weekly average weight hasn't moved for 2–3 weeks.")]))

FREE_FORM = PLAN_FORM.replace('<button class="go" onclick="plan()">Build my 7-day plan</button>',
    '<label for="fem">Where should we send your plan?</label><form id="freeform" onsubmit="window.__gated=true;plan();window.__gated=false;return sendPlan(this,\'free-page\')"><input id="fem" type="email" name="em" required placeholder="Your email address" autocomplete="email" style="width:100%"><button class="go" type="submit">Send me my free personalised plan</button></form><p class="sgfine" style="font-size:12.5px;color:var(--muted)">Free. Your plan appears straight away and we email you a link to it plus the 7-Day Kickstart PDF. No spam, unsubscribe any time. <a href="/affiliate-disclosure/#privacy">Privacy</a></p><div class="sgok"></div>')
page("free/", "Free 7-Day Fat Loss Plan (Meals + Workouts) | danfitnz", "Answer a few quick questions and get a free 7-day fat loss plan built for you: your calories and protein, meals (everyday, desi or vegetarian) and gym or home workouts, sent to your inbox.",
     f"""<h1>Your free personalised 7-day plan</h1><p class="lead">Tell me a bit about you and I'll build your week: your calories and protein, meals you'll actually eat, and <b>gym or home workouts</b>. Takes 60 seconds.</p>{TOOL_CSS}
<div class="tool">{FREE_FORM}</div>
<h2>What you get</h2><ul class="check"><li>Your daily calories and protein target, worked out from your details</li><li>7 days of meals (2–5 a day, normal or 16:8 fasting) with portions sized for you: everyday, desi or vegetarian</li><li>Gym or home workouts on the days you choose, every exercise demonstrated</li><li>A weekly shopping list</li><li>Bonus: the 7-Day Fat Loss Kickstart PDF</li></ul>
<p class="note">General education, not medical advice. If you're pregnant, have a medical condition, take medication or have a history of disordered eating, check with your doctor first.</p>{SHARED_JS}<script>{PLAN_JS}</script>""",
     [bc([("Home", BASE + "/"), ("Free personalised plan", f"{BASE}/free/")])])
EXTRA_URLS.append("free/")

exec(open(os.path.join(HERE, "blog.py")).read())
blog_items = BLOG_LIST
# ---------- Ask danfitnz (smart answers from site content, runs in browser) ----------
index = [{"t": p["name"], "u": "/" + p["path"], "d": clean(p["desc"])} for p in pages] + \
        [{"t": b["name"], "u": "/" + b["path"], "d": b["desc"] + " " + b["text"]} for b in blog_items] + \
        [{"t": t["name"], "u": "/" + t["path"], "d": t["desc"]} for t in tools]
os.makedirs(f"{OUT}/ask", exist_ok=True)
ASK_JS = r"""const IDX=__IDX__;const STOP=new Set('a an the is it i my me to of in on for and or do does how what why can should much many with you your be are am will this that'.split(' '));
function toks(s){return s.toLowerCase().replace(/[^a-z0-9 ]/g,' ').split(/\s+/).filter(w=>w&&!STOP.has(w)).map(w=>w.replace(/(ing|es|s)$/,''))}
function ask(q){q=q||document.getElementById('q').value;document.getElementById('q').value=q;const qt=toks(q);if(!qt.length)return;
const scored=IDX.map(it=>{const tt=toks(it.t),dt=toks(it.d);let s=0;qt.forEach(w=>{if(tt.includes(w))s+=3;if(dt.includes(w))s+=1;});return [s,it]}).filter(x=>x[0]>0).sort((a,b)=>b[0]-a[0]).slice(0,4);
const o=document.getElementById('out');o.innerHTML=scored.length?scored.map(([s,it])=>{const sent=it.d.split(/(?<=[.!?])\s+/).find(x=>qt.some(w=>x.toLowerCase().includes(w)))||it.d;return `<div class="ans"><a href="${PFX}${it.u}">${it.t}</a><p style="margin:6px 0 0">${sent.slice(0,240)}</p></div>`}).join(''):'<p>No match yet. Try asking about protein, calories, walking, gym, recipes or myths.</p>';o.classList.add('show');}
document.getElementById('q').addEventListener('keydown',e=>{if(e.key==='Enter')ask()});"""
ask_body = f"""<h1>Ask danfitnz</h1><p class="lead">Type any fat-loss, gym or food question and get instant answers from danfitnz guides, recipes and tools.</p>{TOOL_CSS}
<div class="tool"><label for="q">Your question</label><input id="q" placeholder="e.g. how much protein do I need?" autocomplete="off"><button class="go" onclick="ask()">Ask</button>
<div class="chips">{"".join(f'<button onclick="ask(this.innerText)">{q}</button>' for q in ["How much protein do I need?", "Is rice bad for fat loss?", "Why did my weight jump?", "Beginner gym plan", "High protein dinner ideas", "Do supplements work?"])}</div>
<div class="res" id="out"></div></div><p class="note">Answers are matched from danfitnz content in your browser. Nothing you type is stored or sent anywhere.</p>{follow_box()}{SHARED_JS}<script>{ASK_JS.replace("__IDX__", json.dumps(index, ensure_ascii=False))}</script>"""
page("ask/", "Ask danfitnz: Instant Fat Loss & Fitness Answers", "Ask any fat-loss, gym or food question and get instant answers from danfitnz guides, recipes and free tools.",
     ask_body.replace("__PFX__", PREFIX), [{"@type": "WebApplication", "name": "Ask danfitnz", "url": f"{BASE}/ask/", "applicationCategory": "HealthApplication", "operatingSystem": "Any", "offers": {"@type": "Offer", "price": "0", "priceCurrency": "NZD"}}])
EXTRA_URLS.append("ask/")


# ---------- Engagement tools (added 11 Nov 2026) ----------
SHARE_JS = r"""function sharePanel(t,u){const b=document.getElementById('shr');let p=document.getElementById('shp');if(!p){p=document.createElement('div');p.id='shp';p.style.cssText='display:flex;gap:8px;flex-wrap:wrap;margin-top:10px';b.after(p)}
const tx=encodeURIComponent(t+' '+u),uu=encodeURIComponent(u);const a=(h,l)=>`<a href="${h}" target="_blank" rel="noopener" style="flex:1;min-width:120px;text-align:center;background:#111318;border:1px solid var(--line);border-radius:999px;padding:11px;font-weight:800;text-decoration:none">${l}</a>`;
p.innerHTML=a('https://wa.me/?text='+tx,'WhatsApp')+a('https://www.facebook.com/sharer/sharer.php?u='+uu,'Facebook')+a('https://twitter.com/intent/tweet?text='+tx,'X')+`<button type="button" style="flex:1;min-width:120px;background:#111318;border:1px solid var(--line);color:var(--text);border-radius:999px;padding:11px;font:inherit;font-weight:800;cursor:pointer" id="shc">Copy</button>`;
document.getElementById('shc').onclick=function(){const s=this;const ok=()=>{s.textContent='Copied!'};try{navigator.clipboard.writeText(t+' '+u).then(ok,()=>{const x=document.createElement('textarea');x.value=t+' '+u;document.body.appendChild(x);x.select();document.execCommand('copy');x.remove();ok()})}catch(e){}}}
function shareRes(t){const u=location.href.split('#')[0].split('?')[0];try{gtag('event','tool_share',{tool:location.pathname})}catch(e){}
const mob=window.matchMedia&&matchMedia('(pointer:coarse)').matches;
if(mob&&navigator.share){navigator.share({title:'danfitnz',text:t,url:u}).catch(e=>{if(e&&e.name!=='AbortError')sharePanel(t,u)});return}
sharePanel(t,u)}
function shareBtn(t){const a=String(t).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');return `<button type="button" class="go" id="shr" style="background:#1C1E24;color:var(--lime);border:1px solid var(--lime)" data-t="${a}" onclick="shareRes(this.dataset.t)">Share my result</button>`}
const CTA=`<p style="margin-top:14px"><a href="${PFX}/free/">Get your free personalised 7-day plan →</a></p>`;"""

# 1) Chai calculator
tools.append(tool_page("tools/chai-calorie-calculator/", "Chai Calorie Calculator",
    "Chai Calorie Calculator: How Many Calories Are in Your Chai? | danfitnz",
    "How many calories are in your daily chai? Enter cups, sugar and milk to see your chai calories per day and per year, plus easy swaps that save the most.",
    "Your daily doodh patti might be your biggest hidden calorie source. Find out in 10 seconds.",
    """<div class="row"><div><label for="cups">Cups per day</label><input id="cups" type="number" inputmode="numeric" value="3" min="0" max="15"></div>
<div><label for="sug">Teaspoons of sugar per cup</label><input id="sug" type="number" inputmode="decimal" value="2" min="0" max="8" step="0.5"></div></div>
<label>How milky is it?</label><div class="seg" id="milk"><button data-v="100" class="on">Doodh patti (mostly milk)</button><button data-v="55">Half milk</button><button data-v="20">Splash of milk</button></div>
<label>Milk type</label><div class="seg" id="mt"><button data-v="1" class="on">Full cream</button><button data-v="0.62">Low fat / trim</button></div>
<label for="bisc">Rusks or biscuits with each cup</label><input id="bisc" type="number" inputmode="numeric" value="0" min="0" max="6">
<button class="go" onclick="chai()">Show my chai calories</button><div class="res" id="out"></div>""",
    SHARE_JS + r"""
function chai(){const c=nv('cups')||0,s=nv('sug')||0,b=nv('bisc')||0,m=parseFloat(sv('milk'))*parseFloat(sv('mt'));
const per=Math.round(m+s*16+b*55),day=Math.round(per*c),yr=day*365,kg=yr/7700;
const halfSug=Math.round(c*s*8*365),trim=sv('mt')==='1'?Math.round(c*parseFloat(sv('milk'))*0.38*365):0,noB=Math.round(c*b*55*365);
const walk=Math.round(day/4.5);
const t=`My chai habit is about ${day} calories a day (${(yr/1000).toFixed(0)}k a year) 😳 What's yours?`;
document.getElementById('out').innerHTML=`<div class="big"><div><b>${per}</b><span>kcal per cup</span></div><div><b>${day}</b><span>kcal per day</span></div><div><b>${(yr/1000).toFixed(0)}k</b><span>kcal per year</span></div><div><b>${walk} min</b><span>brisk walking to burn one day's chai</span></div></div>
<p style="margin-top:14px">You don't have to give up chai, just make it lighter. Each 7,700 kcal you save is roughly 1 kg (2.2 lb) of fat:</p>
<ul><li>Half the sugar: saves <b>${(halfSug/1000).toFixed(0)}k kcal a year</b> (your taste adjusts in about 2 weeks)</li>${trim?`<li>Switch to trim/low-fat milk: saves <b>${(trim/1000).toFixed(0)}k kcal a year</b></li>`:''}${noB?`<li>Skip the rusk/biscuit: saves <b>${(noB/1000).toFixed(0)}k kcal a year</b></li>`:''}</ul>
${shareBtn(t)}${CTA}`;document.getElementById('out').classList.add('show');}""",
    "<h2>How we calculate it</h2><p>A teaspoon of sugar is about 16 kcal and a rusk or plain biscuit about 55 kcal. A cup of doodh patti made mostly with full-cream milk has roughly 100 kcal from milk; half milk about 55 kcal and a splash about 20 kcal. Low-fat milk has around 40% fewer calories. One kilogram of body fat stores roughly 7,700 kcal, which is why small daily habits add up over a year. These are estimates; cup sizes vary.</p>",
    [("How many calories are in a cup of chai?", "A typical doodh patti with full-cream milk and 2 teaspoons of sugar has about 130 kcal; with a rusk it's closer to 190. A splash-of-milk tea with no sugar is under 25 kcal."),
     ("Can I drink chai and still lose fat?", "Yes. Count it in your daily calories, cut the sugar gradually and pick lower-fat milk. Many people lose fat while keeping 2–3 cups a day.")]))

# 2) Burn it off
BURN_FOODS = [("Chicken biryani (1 plate)", 650), ("Samosa (1)", 260), ("Aloo paratha (1)", 300), ("Butter naan (1)", 320), ("Gulab jamun (2)", 300),
    ("Jalebi (100 g)", 450), ("Doodh patti chai, 2 sugar", 130), ("Mango lassi (glass)", 300), ("Pakoras (6)", 300), ("Nihari with naan", 900),
    ("Pizza (2 slices)", 570), ("Fast-food burger", 550), ("Large fries", 490), ("Soft drink (can)", 140), ("Chocolate bar", 230), ("Donut", 300),
    ("Ice cream (2 scoops)", 270), ("Fried chicken (2 pieces)", 520), ("Kebab roll / wrap", 600), ("Pasta carbonara (plate)", 750),
    ("Large latte", 220), ("Avocado toast", 350), ("Glass of juice", 120), ("Protein bar", 210)]
_opts = "".join(f'<option value="{k}">{E(n)} — ~{k} kcal</option>' for n, k in BURN_FOODS)
tools.append(tool_page("tools/burn-it-off/", "Burn It Off Calculator",
    "Burn It Off: How Long to Walk Off Biryani, Pizza or a Samosa? | danfitnz",
    "Pick a food and see how many minutes of walking, jogging, cycling or skipping it takes to burn it off at your body weight. Biryani, samosa, pizza, chai and more.",
    "How long would you have to walk to burn off a plate of biryani? Pick a food and find out.",
    f"""<label for="food">Food</label><select id="food">{_opts}</select>
<div class="row"><div><label for="qty">How many servings?</label><input id="qty" type="number" inputmode="decimal" value="1" min="0.5" max="10" step="0.5"></div>
<div><label for="kg">Your weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="80"></div></div>
<button class="go" onclick="burn()">How long to burn it off?</button><div class="res" id="out"></div>""",
    SHARE_JS + r"""
function burn(){const sel=document.getElementById('food'),k=parseFloat(sel.value)*(nv('qty')||1),kg=nv('kg');if(!kg)return;
const name=sel.options[sel.selectedIndex].text.split(' — ')[0];
const acts=[['🚶 Brisk walking',4.3],['🏃 Jogging',8],['🚴 Cycling',7],['🪢 Skipping rope',11],['🪜 Climbing stairs',8.8]];
const mins=acts.map(([n,m])=>[n,Math.round(k/(m*3.5*kg/200))]);
const steps=Math.round(mins[0][1]*110);
const t=`${name} = ${mins[0][1]} minutes of brisk walking 🤯 Try yours:`;
document.getElementById('out').innerHTML=`<div class="big"><div><b>${Math.round(k)}</b><span>kcal (approx.)</span></div>${mins.map(([n,v])=>`<div><b>${v} min</b><span>${n}</span></div>`).join('')}<div><b>${steps.toLocaleString()}</b><span>steps (about)</span></div></div>
<p class="meta" style="margin-top:12px">Food isn't something you have to "earn". This is just to show how much energy is in it: it's usually far easier to eat a little less than to burn it off. Portion and recipe sizes vary.</p>${shareBtn(t)}${CTA}`;document.getElementById('out').classList.add('show');}""",
    "<h2>How it works</h2><p>Calories burned are estimated with the standard MET formula (MET × 3.5 × body weight in kg ÷ 200 = kcal per minute), using published MET values: brisk walking 4.3, cycling 7, jogging 8, stair climbing 8.8, skipping 11. Heavier people burn more per minute. Food calories are typical values for a standard serving; homemade and restaurant portions vary a lot.</p>",
    [("How long does it take to walk off a plate of biryani?", "A typical plate of chicken biryani (~650 kcal) takes about 2 hours of brisk walking for an 80 kg person. That's why portions matter more than exercise for fat loss."),
     ("Should I exercise to burn off what I eat?", "Exercise is great for health, muscle and mood, but it's a slow way to cancel out food. A small calorie deficit through portions plus daily walking works best.")]))

# 3) Goal date calculator
tools.append(tool_page("tools/goal-weight-date-calculator/", "Goal Weight Date Calculator",
    "Goal Weight Date Calculator: When Will I Reach My Goal Weight? | danfitnz",
    "Enter your current and goal weight and pick a pace to see the date you'll reach your goal, with milestone dates for every 5 kg (or 10 lb). kg and lb.",
    "See the exact date you could reach your goal weight, with milestones to celebrate on the way.",
    """<div class="row"><div><label for="kg">Current weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="90"></div>
<div><label for="goalkg">Goal weight (kg)</label><input id="goalkg" type="number" inputmode="decimal" value="75"></div></div>
<label>Pace</label><div class="seg" id="pace"><button data-v="0.5">Gentle (0.5%/week)</button><button data-v="0.75" class="on">Steady (0.75%/week)</button><button data-v="1">Fast (1%/week)</button></div>
<button class="go" onclick="goal()">Show my goal date</button><div class="res" id="out"></div>""",
    SHARE_JS + r"""
function goal(){const kg=nv('kg'),g=nv('goalkg'),p=parseFloat(sv('pace'))/100;if(!(kg&&g))return;const o=document.getElementById('out');
const imp=(document.querySelector('#units .on')||{dataset:{}}).dataset.v==='imperial',u=imp?'lb':'kg',f=imp?2.20462:1;
if(g>=kg){o.innerHTML='<p>Your goal weight is above your current weight. For muscle gain, try the <a href="'+PFX+'/tools/plan-builder/">plan builder</a> with "Build muscle".</p>';o.classList.add('show');return}
let w=kg,wk=0;const step=imp?10/2.20462:5,ms=[];let next=kg-step;
while(w>g&&wk<520){w-=w*p;wk++;while(w<=next&&next>g){ms.push([next,wk]);next-=step;}}
const d=n=>{const x=new Date();x.setDate(x.getDate()+n*7);return x.toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'})};
const tot=((kg-g)*f).toFixed(1),first=(kg*p*f).toFixed(1);
const t=`I'm aiming for ${(g*f).toFixed(0)} ${u} by ${d(wk)} 💪 Calculate your goal date:`;
o.innerHTML=`<div class="big"><div><b>${d(wk)}</b><span>your goal date</span></div><div><b>${wk}</b><span>weeks</span></div><div><b>${tot} ${u}</b><span>to lose</span></div><div><b>~${first} ${u}</b><span>per week at first</span></div></div>
<h3 style="margin-top:16px">Milestones</h3><ul>${ms.map(([m,n])=>`<li><b>${(m*f).toFixed(0)} ${u}</b> around ${d(n)}</li>`).join('')}<li><b>${(g*f).toFixed(0)} ${u}</b> around ${d(wk)} 🎉</li></ul>
<p class="meta">Real progress isn't a straight line: water weight, travel and holidays cause ups and downs. Use your weekly average. Faster paces are harder to keep; most people do best at 0.5–1% of body weight per week.</p>${shareBtn(t)}${CTA}`;o.classList.add('show');}""",
    "<h2>How the date is worked out</h2><p>Each week you lose a percentage of your current body weight (0.5–1%), so weekly losses get a little smaller as you get lighter, just like real life. Research and coaching practice suggest 0.5–1% per week is a sustainable range that helps keep muscle. Your result is an estimate; use it to plan, then follow your weekly average.</p>",
    [("How fast can I safely lose weight?", "For most people about 0.5–1% of body weight per week (0.4–0.9 kg / 1–2 lb for an 85 kg person) is sustainable and helps keep muscle. Check with your GP if you have a medical condition."),
     ("What calories do I need to hit this pace?", "Use the free calorie deficit calculator to find your target, or build a full 7-day plan with the plan builder.")]))

# 4) Desi swap calculator
SWAPS = [("Paratha → plain roti", 170, 5), ("2 tsp sugar in chai → 1 tsp", 16, 14), ("Fried samosa → air-fried samosa", 120, 2), ("Full plate biryani → half plate + raita & salad", 300, 1),
         ("2 tbsp ghee in curry → 1 tsp oil (per serve)", 190, 5), ("Mango lassi → salted lassi / chaas", 150, 2), ("Soft drink → zero sugar / lemon soda water", 140, 4),
         ("Naan → roti", 180, 2), ("Mithai after dinner → fruit", 200, 3), ("Fried snack → roasted chana (30 g)", 150, 3), ("Creamy restaurant curry → tikka / grilled", 350, 1),
         ("Puri (3) → roti (2)", 230, 1)]
_sw = "".join(f'<div class="swp"><label style="display:flex;gap:10px;align-items:center;margin:0;color:var(--text)"><input type="checkbox" style="width:auto" data-k="{k}"> {E(n)} <small style="color:var(--muted)">(saves ~{k} kcal)</small></label><input type="number" inputmode="numeric" value="{t}" min="0" max="21" aria-label="times per week"><span>× / week</span></div>' for n, k, t in SWAPS)
tools.append(tool_page("tools/desi-swap-calculator/", "Desi Food Swap Calculator",
    "Desi Food Swap Calculator: Lose Fat Without Giving Up Desi Food | danfitnz",
    "Tick the desi food swaps you'd make (paratha to roti, less ghee, lighter chai) and see how many calories you'd save per week and per year.",
    "Keep eating desi food, just smarter. Tick the swaps you'd actually make and see what they add up to.",
    f"""<style>.swp{{display:grid;grid-template-columns:1fr 70px 70px;gap:8px;align-items:center;padding:8px 0;border-bottom:1px solid var(--line)}}.swp input[type=number]{{padding:8px}}.swp span{{color:var(--muted);font-size:13px}}@media(max-width:520px){{.swp{{grid-template-columns:1fr 60px 50px}}}}</style>
<p class="meta" style="margin:0 0 6px">Tick the swaps you'd really make and set how many times a week.</p>{_sw}
<button class="go" onclick="swp()">Add up my savings</button><div class="res" id="out"></div>""",
    SHARE_JS + r"""
function swp(){let wk=0,n=0;if(!document.querySelector('.swp input[type=checkbox]:checked')){document.querySelector('.swp').scrollIntoView({behavior:'smooth',block:'center'});return}document.querySelectorAll('.swp').forEach(r=>{const c=r.querySelector('input[type=checkbox]'),t=parseFloat(r.querySelector('input[type=number]').value)||0;if(c.checked&&t>0){wk+=parseFloat(c.dataset.k)*t;n++}});
const yr=wk*52,kg=yr/7700;const t=`${n} easy desi swap${n>1?"s":""} would save me ${Math.round(wk).toLocaleString()} calories a week 🔥 Try yours:`;
document.getElementById('out').innerHTML=`<div class="big"><div><b>${n}</b><span>swaps chosen</span></div><div><b>${Math.round(wk).toLocaleString()}</b><span>kcal saved per week</span></div><div><b>${Math.round(wk/7)}</b><span>kcal per day</span></div><div><b>up to ${kg.toFixed(1)} kg</b><span>of fat a year if nothing else changes (${(kg*2.2046).toFixed(1)} lb)</span></div></div>
<p style="margin-top:14px">${wk/7>=300?'That alone is a solid fat-loss deficit for many people.':'Nice start. Combine these with a daily walk for a steady deficit.'} Start with your 2 easiest swaps this week, add more next week.</p>${shareBtn(t)}${CTA}`;document.getElementById('out').classList.add('show');}""",
    "<h2>Why swaps work</h2><p>You don't need a new diet to lose fat. Small swaps you repeat every week create a calorie deficit without giving up the food you love. Savings are typical estimates per serving (a teaspoon of ghee or oil is ~40 kcal, a paratha has about 170 kcal more than a plain roti because of the fat). Your actual numbers depend on recipes and portion sizes.</p>",
    [("Can I lose weight eating Pakistani or Indian food?", "Yes. Keep the dishes, change the method and portions: less ghee and oil, roti instead of paratha or naan, more protein (chicken, daal, yoghurt) and a salad on the side."),
     ("Which desi swap saves the most?", "Usually cooking oil and ghee, then rich restaurant curries, then paratha and naan. One tablespoon of ghee is about 120 kcal.")]))

# 5) Quiz
QUIZ = [("How are your weekends?", [("Same as weekdays, mostly", ""), ("I relax a bit, takeaways or eating out once", "weekend"), ("Basically a cheat weekend", "weekend weekend")]),
        ("What do you drink most days?", [("Water, black coffee or plain tea", ""), ("Chai or coffee with milk and sugar, 2+ cups", "liquid"), ("Juice, soft drinks or energy drinks", "liquid liquid")]),
        ("Is there protein (chicken, eggs, daal, yoghurt, fish, paneer) in most meals?", [("Yes, every meal", ""), ("At dinner mostly", "protein"), ("Not really", "protein protein")]),
        ("How much do you sleep on work nights?", [("7+ hours", ""), ("6–7 hours", "sleep"), ("Under 6 hours", "sleep sleep")]),
        ("How do you decide how much to eat?", [("I roughly know my portions or track", ""), ("I eat until I'm full", "portions"), ("Second helpings are normal for me", "portions portions")]),
        ("How many steps do you get on a normal day?", [("8,000+", ""), ("4,000–8,000", "move"), ("Under 4,000 / no idea", "move move")]),
        ("How have past diets gone?", [("I made a plan and mostly stuck to it", ""), ("Strict for 1–2 weeks, then gave up", "allnothing allnothing"), ("I start every Monday", "allnothing")]),
        ("Late-night eating?", [("Rarely", ""), ("A snack most nights", "night"), ("Most of my eating is after 9pm", "night night")])]
_q = "".join(f'<div class="qz"><b>{i + 1}. {E(q)}</b><div class="seg" id="q{i}" style="flex-direction:column">' + "".join(f'<button data-v="{v}">{E(t)}</button>' for j, (t, v) in enumerate(opts)) + '</div></div>' for i, (q, opts) in enumerate(QUIZ))
tools.append(tool_page("tools/fat-loss-blocker-quiz/", "What's Slowing Your Fat Loss? Quiz",
    "Quiz: What's Slowing Your Fat Loss? (8 Questions) | danfitnz",
    "Take the free 8-question quiz to find the habit that's quietly slowing your fat loss (weekends, drinks, protein, sleep, portions, steps or all-or-nothing dieting) and how to fix it.",
    "8 quick questions. Find the one habit that's quietly slowing your fat loss, and exactly how to fix it.",
    f"""<style>.qz{{margin:14px 0}}.qz b{{display:block;margin-bottom:8px}}.qz .seg button{{text-align:left;font-weight:600}}</style>{_q}
<button class="go" onclick="quiz()">Show my result</button><div class="res" id="out"></div>""",
    SHARE_JS + r"""
const R={weekend:['The Weekend Undoer','Your weekdays are fine, but weekends wipe out the deficit. Two big days can cancel five good ones.','Keep one planned treat meal, not a whole weekend. Eat protein first at takeaways, and walk on Saturday and Sunday.','/blog/'],
liquid:['The Liquid Calories Trap','Drinks are adding calories you don\'t notice or feel full from.','Halve the sugar in chai, swap soft drinks for zero-sugar, and drink water before meals. Try the chai calculator to see your number.','/tools/chai-calorie-calculator/'],
protein:['The Protein Gap','Low protein means more hunger, more snacking and losing muscle while dieting.','Add a palm-sized protein to every meal: eggs, chicken, daal, yoghurt, paneer or fish.','/tools/protein-calculator/'],
sleep:['The Tired Eater','Short sleep raises hunger and cravings and makes training harder.','Aim for 7+ hours: same bedtime, screens off 30 minutes before, caffeine before 2pm.','/blog/'],
portions:['The Portion Drifter','You eat good food, just a bit too much of it.','Use the plate rule: half veg, a quarter protein, a quarter carbs. Serve once, no second helpings for 2 weeks.','/tools/calorie-deficit-calculator/'],
move:['The Desk Sitter','Low daily movement means a smaller calorie burn than you think.','Add 2,000 steps a week until you reach 8,000 a day: a 10-minute walk after each meal does it.','/tools/burn-it-off/'],
allnothing:['The All-or-Nothing Dieter','You go too strict, burn out and restart. The restarting is what slows you down.','Pick a plan you could follow on your worst day. Miss a day? Never miss two in a row.','/blog/how-to-build-discipline/'],
night:['The Night Grazer','Late-night snacking adds up, often because of a long gap or tiredness.','Eat a proper protein dinner, brush your teeth after it, and keep snacks out of sight.','/blog/']};
function quiz(){for(let i=0;i<8;i++){if(!sv('q'+i)&&sv('q'+i)!==''){const el=document.getElementById('q'+i);el.scrollIntoView({behavior:'smooth',block:'center'});el.style.outline='2px solid var(--lime)';return}}const s={};for(let i=0;i<8;i++){(sv('q'+i)||'').split(' ').filter(Boolean).forEach(k=>s[k]=(s[k]||0)+1)}
const top=Object.entries(s).sort((a,b)=>b[1]-a[1]);const o=document.getElementById('out');
if(!top.length){o.innerHTML='<h3>You\'re doing most things right 👏</h3><p>If you\'re not losing, it\'s likely portions you can\'t see: track for 2 weeks with the <a href="'+PFX+'/tools/calorie-deficit-calculator/">calorie calculator</a>.</p>'+CTA;o.classList.add('show');return}
const [k1]=top[0],r=R[k1],k2=top[1]&&top[1][1]>1?top[1][0]:null;
const t=`My fat-loss blocker is "${r[0]}" 😅 What's yours?`;
o.innerHTML=`<div class="ans"><small style="color:var(--muted)">Your #1 blocker</small><h2 style="margin:4px 0;color:var(--lime)">${r[0]}</h2><p>${r[1]}</p><p><b>Fix it:</b> ${r[2]} <a href="${PFX}${r[3]}">Learn more →</a></p></div>${k2?`<div class="ans"><small style="color:var(--muted)">Also watch</small><h3 style="margin:4px 0">${R[k2][0]}</h3><p><b>Fix:</b> ${R[k2][2]}</p></div>`:''}${shareBtn(t)}${CTA}`;o.classList.add('show');o.scrollIntoView({behavior:'smooth'});}""",
    "<h2>About this quiz</h2><p>The quiz looks at the 8 habits that most often slow fat loss for busy people: weekends, liquid calories, protein, sleep, portions, daily steps, all-or-nothing dieting and late-night eating. It's a self-check, not a diagnosis. If you have a medical condition or a history of disordered eating, talk to your GP or a registered dietitian.</p>",
    [("Why am I not losing weight even though I eat healthy?", "Healthy food still has calories. The most common hidden causes are portion sizes, cooking oil, sugary drinks and weekends. The quiz shows which is most likely for you."),
     ("Is it normal for weight loss to stall?", "Yes. Water and salt can hide fat loss for 1–2 weeks. Use your weekly average weight; if it's flat for 3 weeks, adjust your habits.")]))

# tools hub
page("tools/", "Free Fitness Calculators & Tools | danfitnz", "Free fitness tools: calorie deficit calculator, protein calculator, BMI, body fat calculator and a personalised 7-day fat-loss plan builder.",
     "<h1>Free fitness tools</h1><p class='lead'>Quick calculators and a personal plan builder. Free, no sign-up, and nothing you enter leaves your device.</p><div class='grid'>" +
     "".join(f'<a href="/{t["path"]}">{E(t["name"])}<small>{E(t["desc"][:95])}…</small></a>' for t in tools) +
     '<a href="/ask/">Ask danfitnz<small>Type any question and get instant answers from our guides.</small></a></div>' + follow_box(),
     [{"@type": "CollectionPage", "name": "Free fitness tools", "url": f"{BASE}/tools/"}, bc([("Home", BASE + "/"), ("Tools", f"{BASE}/tools/")])])
EXTRA_URLS.append("tools/")
TOOLS_LIST = tools
