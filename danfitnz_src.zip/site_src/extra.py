# Executed inside site_build.py (shares its namespace): interactive tools, plan builder, Ask danfitnz, blog.
EXTRA_URLS = []
TOOL_CSS = """<style>
.tool{background:var(--card);border-radius:18px;padding:20px;margin:18px 0}
.tool label{display:block;font-weight:600;font-size:14px;color:var(--muted);margin:12px 0 4px}
.tool input,.tool select{width:100%;background:#111318;border:1px solid var(--line);color:var(--text);border-radius:12px;padding:12px;font:inherit}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.seg{display:flex;gap:8px;flex-wrap:wrap}.seg button{flex:1;min-width:90px;background:#111318;border:1px solid var(--line);color:var(--text);border-radius:12px;padding:11px;font:inherit;font-weight:700;cursor:pointer}
.seg button.on{background:var(--lime);color:var(--bg);border-color:var(--lime)}
.go{width:100%;margin-top:16px;background:var(--lime);color:var(--bg);border:0;border-radius:999px;padding:14px;font:inherit;font-weight:900;cursor:pointer;font-size:17px}
.res{display:none;margin-top:18px}.res.show{display:block}
.big{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px}.big div{background:#111318;border-radius:14px;padding:14px}.big b{display:block;font-size:28px;font-weight:900;color:var(--lime)}.big span{color:var(--muted);font-size:13px}
.day{background:#111318;border-radius:14px;padding:12px 14px;margin:8px 0}.day b{color:var(--lime)}
.ans{background:#111318;border-radius:14px;padding:14px;margin:10px 0}.ans a{font-weight:800}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.chips button{background:#111318;border:1px solid var(--line);color:var(--text);border-radius:999px;padding:8px 12px;font:inherit;font-size:14px;cursor:pointer}
@media(max-width:520px){.row{grid-template-columns:1fr}}
</style>"""
SHARED_JS = r"""<script>
const PFX='__PFX__';
function segs(){document.querySelectorAll('.seg').forEach(g=>g.querySelectorAll('button').forEach(b=>b.onclick=()=>{g.querySelectorAll('button').forEach(x=>x.classList.remove('on'));b.classList.add('on');}));}
function sv(id){const b=document.querySelector('#'+id+' .on');return b?b.dataset.v:null}
function nv(id){return parseFloat(document.getElementById(id).value)}
function bmr(sex,kg,cm,age){return 10*kg+6.25*cm-5*age+(sex==='m'?5:-161)}
function r10(x){return Math.round(x/10)*10}
segs();
(function(){const YTU='https://www.youtube.com/channel/UCOWbB203EHcPglSFcwW2j3g';let shown=false;
const css=document.createElement('style');css.textContent='.ytm{position:fixed;inset:0;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;z-index:999;padding:16px}.ytm>div{background:#1C1E24;border-radius:20px;max-width:420px;width:100%;padding:24px;text-align:center;position:relative}.ytm h3{margin:6px 0 8px;font-size:22px}.ytm p{color:#A0A3AD;margin:0 0 16px}.ytm a.ytb{display:block;background:#FF0033;color:#fff;border-radius:999px;padding:14px;font-weight:900;text-decoration:none;font-size:17px}.ytm button{background:none;border:0;color:#A0A3AD;margin-top:12px;font:inherit;cursor:pointer}';document.head.appendChild(css);
function pop(){if(shown)return;try{if(sessionStorage.getItem('ytp'))return;sessionStorage.setItem('ytp','1')}catch(e){}shown=true;
const m=document.createElement('div');m.className='ytm';m.innerHTML='<div role="dialog" aria-label="Subscribe on YouTube"><div style="font-size:42px">▶</div><h3>Your result is ready!</h3><p>Get a new fat-loss tip every day. Subscribe to danfitnz on YouTube, it\'s free.</p><a class="ytb" href="'+YTU+'?sub_confirmation=1" target="_blank" rel="noopener">Subscribe on YouTube</a><button type="button">Maybe later</button></div>';
m.addEventListener('click',ev=>{if(ev.target===m||ev.target.tagName==='BUTTON')m.remove()});document.body.appendChild(m);}
const out=document.getElementById('out');if(out&&!document.getElementById('q'))new MutationObserver(()=>{if(out.classList.contains('show'))setTimeout(pop,1400)}).observe(out,{attributes:true,childList:true});})();

(function(){var tool=document.querySelector('.tool');if(!tool||!(document.getElementById('kg')||document.getElementById('cm')))return;
var U='metric';try{U=localStorage.getItem('dfz_units')||''}catch(e){}if(!U)U=/en-(US|GB|LR|MM)/.test(navigator.language||'')?'imperial':'metric';
var seg=document.createElement('div');seg.innerHTML='<label>Units</label><div class="seg" id="units"><button type="button" data-v="metric">Metric (kg, cm)</button><button type="button" data-v="imperial">Imperial (lb, ft)</button></div>';tool.insertBefore(seg,tool.firstChild);
var cm=document.getElementById('cm'),ftw=null;
if(cm){ftw=document.createElement('div');ftw.className='row';ftw.style.display='none';ftw.innerHTML='<div><input id="ft" type="number" inputmode="numeric" placeholder="ft" aria-label="Height feet"></div><div><input id="inch" type="number" inputmode="decimal" placeholder="in" aria-label="Height inches"></div>';cm.parentNode.appendChild(ftw);}
var LEN=['neck','waist','hip'];
function lab(id,t){var l=document.querySelector('label[for="'+id+'"]');if(l)l.textContent=l.textContent.replace(/\((cm|kg|in|lb|ft, in)\)/,'('+t+')')}
function r1(x){return Math.round(x*10)/10}
function apply(to,convert){var from=U;U=to;try{localStorage.setItem('dfz_units',to)}catch(e){}
 seg.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.dataset.v===to)});
 var kg=document.getElementById('kg');
 if(convert&&from!==to){
  if(kg&&kg.value)kg.value=to==='imperial'?Math.round(kg.value/0.45359237):r1(kg.value*0.45359237);
  LEN.forEach(function(id){var el=document.getElementById(id);if(el&&el.value)el.value=to==='imperial'?r1(el.value/2.54):Math.round(el.value*2.54)});
  if(cm){if(to==='imperial'){var tin=(parseFloat(cm.value)||0)/2.54;document.getElementById('ft').value=Math.floor(tin/12);document.getElementById('inch').value=Math.round(tin%12)}else{var f=parseFloat(document.getElementById('ft').value)||0,i=parseFloat(document.getElementById('inch').value)||0;cm.value=Math.round(f*30.48+i*2.54)}}
 }
 if(cm){cm.style.display=to==='imperial'?'none':'';ftw.style.display=to==='imperial'?'':'none';lab('cm',to==='imperial'?'ft, in':'cm')}
 lab('kg',to==='imperial'?'lb':'kg');LEN.forEach(function(id){lab(id,to==='imperial'?'in':'cm')});
}
seg.querySelectorAll('button').forEach(function(b){b.onclick=function(){apply(b.dataset.v,true)}});
var start=U;U='metric';apply(start,true);
var out=document.getElementById('out');if(out){var busy=false;new MutationObserver(function(){if(busy||U!=='imperial')return;busy=true;out.innerHTML=out.innerHTML.replace(/(\d+(?:\.\d+)?)\s?kg(?!\s?\()/g,function(m,n){return m+' ('+(parseFloat(n)*2.2046).toFixed(1)+' lb)'});setTimeout(function(){busy=false},0)}).observe(out,{childList:true,subtree:true})}
window.nv=function(id){var el=document.getElementById(id);var v=parseFloat(el&&el.value);
 if(U==='imperial'){if(id==='cm'){var f=parseFloat(document.getElementById('ft').value)||0,i=parseFloat(document.getElementById('inch').value)||0;return f*30.48+i*2.54}
  if(id==='kg')return v*0.45359237;if(LEN.indexOf(id)>=0)return v*2.54}return v};
})();
</script>"""

EMBEDS = {"calorie-deficit-calculator": 760, "protein-calculator": 620, "bmi-calculator": 600, "body-fat-calculator": 680}
EMBED_JS = SHARED_JS.split("(function(){const YTU")[0] + "</script>"
def embed_box(path, h1):
    nm = path.split("/")[1]; src = f"{BASE}/embed/{nm}/"
    code = (f'<iframe src="{src}" width="100%" height="{EMBEDS[nm]}" style="border:0;border-radius:16px;max-width:560px" loading="lazy" title="{h1}"></iframe>\n'
            f'<p style="font-size:13px">{h1} by <a href="{BASE}/{path}">danfitnz</a></p>')
    return (f"<h2>Add this {E(h1.lower())} to your website</h2><p>Run a fitness, health or food blog? Embed this free calculator on your site — copy the code below. "
            f"It's free, ad-free and mobile friendly. Please keep the credit link.</p><textarea readonly onclick=\"this.select()\" style=\"width:100%;height:110px;background:#111318;color:#F5F5F5;border:1px solid #2A2D35;border-radius:12px;padding:10px;font:13px monospace\">{E(code)}</textarea>")
def write_embed(path, h1, form, js):
    nm = path.split("/")[1]; d = f"{OUT}/embed/{nm}"; os.makedirs(d, exist_ok=True)
    open(f"{d}/index.html", "w").write(f"""<!doctype html><html lang="en-NZ"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{E(h1)} | danfitnz</title>
<meta name="robots" content="noindex,follow"><link rel="canonical" href="{BASE}/{path}"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
<style>:root{{--bg:#0E0F12;--card:#1C1E24;--lime:#C6FF3D;--text:#F5F5F5;--muted:#A0A3AD;--line:#2A2D35}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:Inter,system-ui,sans-serif}}a{{color:var(--lime)}}.tool{{margin:0!important}}.cr{{text-align:center;font-size:13px;color:var(--muted);padding:8px}}</style>
{TOOL_CSS}</head><body><div class="tool"><h2 style="margin:0 0 6px;font-size:20px">{E(h1)}</h2>{form}</div>
<p class="cr">Free {E(h1.lower())} by <a href="{BASE}/{path}" target="_blank" rel="noopener">danfitnz.nz</a></p>
{EMBED_JS.replace("__PFX__", BASE)}<script>{js.replace("${PFX}", BASE)}</script>
<script>document.addEventListener('click',function(e){{var a=e.target.closest('a');if(a&&a.href.indexOf('{BASE}')===0)a.target='_blank'}})</script></body></html>""")

def tool_page(path, h1, title, desc, lead, form, js, explain, faqs):
    faq_html = "".join(f"<h3>{E(q)}</h3><p>{E(a)}</p>" for q, a in faqs)
    if path.split("/")[1] in EMBEDS:
        write_embed(path, h1, form, js); explain = explain + embed_box(path, h1)
    body = f"""<p class="meta"><a href="/tools/">Free fitness tools</a></p><h1>{E(h1)}</h1><p class="lead">{E(lead)}</p>{TOOL_CSS}
<div class="tool">{form}</div>{explain}<h2>FAQ</h2>{faq_html}
<p class="note">Estimates only, based on standard formulas. Not medical advice. If you have a medical condition, are pregnant, or are under 18, talk to your GP first.</p>{follow_box()}{SHARED_JS}<script>{js}</script>"""
    sch = [{"@type": "WebApplication", "name": h1, "url": f"{BASE}/{path}", "applicationCategory": "HealthApplication", "operatingSystem": "Any",
            "offers": {"@type": "Offer", "price": "0", "priceCurrency": "NZD"}, "description": desc, "publisher": {"@id": BASE + "/#org"}},
           {"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in faqs]},
           bc([("Home", BASE + "/"), ("Free fitness tools", f"{BASE}/tools/"), (h1, f"{BASE}/{path}")])]
    page(path, title, desc, body.replace("__PFX__", PREFIX), sch)
    EXTRA_URLS.append(path)
    return dict(path=path, name=h1, desc=desc)

SEXAGE = """<label>Sex</label><div class="seg" id="sex"><button data-v="m" class="on">Male</button><button data-v="f">Female</button></div>
<div class="row"><div><label for="age">Age</label><input id="age" type="number" inputmode="numeric" value="30" min="15" max="90"></div>
<div><label for="cm">Height (cm)</label><input id="cm" type="number" inputmode="decimal" value="172"></div></div>
<div class="row"><div><label for="kg">Weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="85"></div>
<div><label for="act">Activity</label><select id="act"><option value="1.2">Desk job, little exercise</option><option value="1.375" selected>Light: 1–3 workouts/week</option><option value="1.55">Moderate: 3–5 workouts/week</option><option value="1.725">Very active: 6–7 workouts/week</option><option value="1.9">Physical job + training</option></select></div></div>"""

tools = []
tools.append(tool_page("tools/calorie-deficit-calculator/", "Calorie Deficit Calculator",
    "Calorie Deficit Calculator for Fat Loss | danfitnz",
    "Free calorie deficit calculator: find your maintenance calories (TDEE), a safe fat-loss target and your daily protein in seconds.",
    "Find your maintenance calories, a realistic fat-loss target and how much protein to eat. Takes 20 seconds.",
    SEXAGE + """<label>Goal</label><div class="seg" id="goal"><button data-v="0.10">Slow &amp; easy</button><button data-v="0.20" class="on">Steady fat loss</button><button data-v="0.25">Faster</button></div>
<button class="go" onclick="calc()">Calculate my calories</button><div class="res" id="out"></div>""",
    r"""function calc(){const sex=sv('sex'),age=nv('age'),cm=nv('cm'),kg=nv('kg'),act=parseFloat(document.getElementById('act').value),g=parseFloat(sv('goal'));
if(!(age&&cm&&kg)){return}
const b=bmr(sex,kg,cm,age),t=b*act;let target=t*(1-g);const floor=sex==='m'?1500:1200;if(target<floor)target=floor;
const deficit=t-target,wk=deficit*7/7700,pro=Math.round(kg*1.8),proLo=Math.round(kg*1.6),proHi=Math.round(kg*2.2);
const fat=Math.round(target*0.27/9),carb=Math.max(0,Math.round((target-pro*4-fat*9)/4));
document.getElementById('out').innerHTML=`<div class="big"><div><b>${r10(t)}</b><span>maintenance kcal/day</span></div><div><b>${r10(target)}</b><span>fat-loss target kcal/day</span></div><div><b>${pro}g</b><span>protein/day (${proLo}–${proHi}g)</span></div><div><b>~${wk.toFixed(2)} kg</b><span>expected loss per week</span></div></div>
<p style="margin-top:14px">Rough daily macros: <b>${pro}g protein · ${fat}g fat · ${carb}g carbs</b>.</p><p>Stick to this for 2 weeks, weigh yourself most mornings and use the weekly average. Not dropping? Take off another 100–150 kcal. <a href="${PFX}/tools/plan-builder/">Turn this into a 7-day plan →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    """<h2>How this calculator works</h2><p>It uses the Mifflin-St Jeor equation, one of the most accurate everyday formulas for resting calories, then multiplies by your activity level to estimate maintenance (TDEE). The fat-loss target takes 10–25% off maintenance, never going below 1,200 kcal (women) or 1,500 kcal (men). Protein is set at 1.6–2.2g per kg of bodyweight, the range research supports for keeping muscle while dieting.</p>""",
    [("How big should my calorie deficit be?", "For most people, 15–20% below maintenance (often 300–600 kcal a day) gives steady fat loss of about 0.3–0.7 kg per week without wrecking energy or training."),
     ("Why am I not losing weight on my deficit?", "Daily weight bounces with water, salt and carbs. Track your weekly average for 2–3 weeks. If it's flat, lower calories by 100–150 or add 2,000 more steps a day."),
     ("Do I need to count calories forever?", "No. Count for a few weeks to learn portions, then switch to simple habits like protein first, half a plate of veg and fewer liquid calories.")]))

tools.append(tool_page("tools/protein-calculator/", "Protein Calculator", "Protein Calculator: How Much Protein Do I Need? | danfitnz",
    "Free protein calculator: find how much protein you need per day for fat loss or muscle gain, plus how much per meal.",
    "How much protein you need each day, and how to split it across your meals.",
    """<label for="kg">Weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="80">
<label>Goal</label><div class="seg" id="goal"><button data-v="1.6">General health</button><button data-v="1.8" class="on">Lose fat</button><button data-v="2.0">Build muscle</button></div>
<label for="meals">Meals per day</label><select id="meals"><option>2</option><option selected>3</option><option>4</option><option>5</option></select>
<button class="go" onclick="calc()">Calculate my protein</button><div class="res" id="out"></div>""",
    r"""function calc(){const kg=nv('kg'),f=parseFloat(sv('goal')),m=parseInt(document.getElementById('meals').value);if(!kg)return;
const p=Math.round(kg*f),per=Math.round(p/m);
document.getElementById('out').innerHTML=`<div class="big"><div><b>${p}g</b><span>protein per day</span></div><div><b>${per}g</b><span>per meal (${m} meals)</span></div></div>
<p style="margin-top:14px">Easy ways to hit ~${per}g: 150g cooked chicken breast (~45g), 3 eggs + 2 egg whites (~25g), 200g Greek yogurt (~20g), a bowl of dal with paneer (~25g). <a href="${PFX}/recipes/">See high-protein recipes →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    "<h2>Why protein matters for fat loss</h2><p>Protein is the most filling nutrient and helps you keep muscle while eating less. Most adults trying to lose fat do well on 1.6–2.2g per kg of bodyweight per day, spread over 3–4 meals.</p>",
    [("How much protein do I need to lose fat?", "Around 1.6–2.2g per kg of bodyweight per day. For an 80kg person that's roughly 130–175g."),
     ("Can I get enough protein without shakes?", "Yes. Build each meal around chicken, eggs, fish, Greek yogurt, paneer, lentils or tofu. Shakes are just convenient."),
     ("Is too much protein bad for you?", "For healthy adults, intakes in this range are considered safe. If you have kidney disease, check with your doctor.")]))

tools.append(tool_page("tools/bmi-calculator/", "BMI Calculator", "BMI Calculator (with Asian Cut-offs) | danfitnz",
    "Free BMI calculator with standard and Asian/South Asian cut-offs, plus what BMI can and can't tell you.",
    "Check your Body Mass Index, including the lower cut-offs often used for South Asian people.",
    """<div class="row"><div><label for="cm">Height (cm)</label><input id="cm" type="number" inputmode="decimal" value="172"></div><div><label for="kg">Weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="80"></div></div>
<button class="go" onclick="calc()">Calculate BMI</button><div class="res" id="out"></div>""",
    r"""function calc(){const cm=nv('cm'),kg=nv('kg');if(!(cm&&kg))return;const b=kg/((cm/100)**2);
const std=b<18.5?'Underweight':b<25?'Healthy range':b<30?'Overweight':'Obese';const asn=b<18.5?'Underweight':b<23?'Healthy range':b<27.5?'Increased risk':'High risk';
const lo=(18.5*(cm/100)**2).toFixed(0),hi=(24.9*(cm/100)**2).toFixed(0);
document.getElementById('out').innerHTML=`<div class="big"><div><b>${b.toFixed(1)}</b><span>your BMI</span></div><div><b style="font-size:20px">${std}</b><span>standard (WHO)</span></div><div><b style="font-size:20px">${asn}</b><span>Asian cut-offs</span></div></div><p style="margin-top:14px">Healthy weight range for your height (standard): <b>${lo}–${hi} kg</b>. BMI doesn't separate muscle from fat, so also check your waist. <a href="${PFX}/tools/body-fat-calculator/">Estimate body fat →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    "<h2>About BMI</h2><p>BMI is weight divided by height squared. It's a quick screening tool, not a diagnosis. Because people of South Asian descent tend to carry more body fat at the same BMI, health bodies often use lower cut-offs (23 for overweight, 27.5 for obesity).</p>",
    [("What is a healthy BMI?", "18.5–24.9 is the standard healthy range. For South Asian adults, 18.5–22.9 is often used."),
     ("Is BMI accurate if I lift weights?", "Not very. Muscular people can show as overweight. Waist size and body fat estimates give a better picture.")]))

tools.append(tool_page("tools/body-fat-calculator/", "Body Fat Calculator", "Body Fat Calculator (Tape Measure Method) | danfitnz",
    "Free body fat percentage calculator using the US Navy tape-measure method: just height, neck and waist (and hips for women).",
    "Estimate your body fat percentage with a tape measure. No scale tricks, no fancy gadgets.",
    """<label>Sex</label><div class="seg" id="sex"><button data-v="m" class="on">Male</button><button data-v="f">Female</button></div>
<div class="row"><div><label for="cm">Height (cm)</label><input id="cm" type="number" inputmode="decimal" value="172"></div><div><label for="neck">Neck (cm)</label><input id="neck" type="number" inputmode="decimal" value="38"></div></div>
<div class="row"><div><label for="waist">Waist at navel (cm)</label><input id="waist" type="number" inputmode="decimal" value="92"></div><div><label for="hip">Hips, women only (cm)</label><input id="hip" type="number" inputmode="decimal" value="100"></div></div>
<button class="go" onclick="calc()">Estimate body fat</button><div class="res" id="out"></div>""",
    r"""function calc(){const sex=sv('sex'),h=nv('cm'),n=nv('neck'),w=nv('waist'),hp=nv('hip');let bf;
if(sex==='m'){if(w<=n)return;bf=495/(1.0324-0.19077*Math.log10(w-n)+0.15456*Math.log10(h))-450}else{if(w+hp<=n)return;bf=495/(1.29579-0.35004*Math.log10(w+hp-n)+0.22100*Math.log10(h))-450}
const c=sex==='m'?(bf<14?'Athletic':bf<18?'Fit':bf<25?'Average':'Above average'):(bf<21?'Athletic':bf<25?'Fit':bf<32?'Average':'Above average');
document.getElementById('out').innerHTML=`<div class="big"><div><b>${bf.toFixed(1)}%</b><span>estimated body fat</span></div><div><b style="font-size:20px">${c}</b><span>general category</span></div></div><p style="margin-top:14px">Re-measure every 2–4 weeks at the same time of day. A shrinking waist is one of the best signs you're losing fat. <a href="${PFX}/tools/calorie-deficit-calculator/">Set your calorie target →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    "<h2>How to measure</h2><p>Measure your neck just below the Adam's apple and your waist at the navel (men) or narrowest point (women), with the tape snug but not squeezing. Women also measure hips at the widest point. The US Navy formula is usually within a few percent of lab tests.</p>",
    [("How accurate is the tape measure body fat method?", "Typically within about 3–4% of lab methods, and very good for tracking change over time if you measure the same way."),
     ("What's a healthy body fat percentage?", "Roughly 10–20% for men and 18–30% for women is a common healthy range.")]))

PLAN_FORM = SEXAGE + """<label>Goal</label><div class="seg" id="goal"><button data-v="lose" class="on">Lose fat</button><button data-v="tone">Get fit &amp; toned</button><button data-v="gain">Build muscle</button></div>
<label>Where do you train?</label><div class="seg" id="where"><button data-v="home" class="on">Home</button><button data-v="gym">Gym</button></div>
<label>Training days per week</label><div class="seg" id="days"><button data-v="2">2</button><button data-v="3" class="on">3</button><button data-v="4">4</button><button data-v="5">5</button></div>
<label>Meals per day</label><div class="seg" id="meals"><button data-v="2">2</button><button data-v="3" class="on">3</button><button data-v="4">4</button><button data-v="5">5</button></div>
<label>Eating style</label><div class="seg" id="style"><button data-v="normal" class="on">Normal</button><button data-v="if">16:8 fasting (12pm–8pm)</button></div>
<label>Cuisine</label><div class="seg" id="cuisine"><button data-v="mix" class="on">Mix (global)</button><button data-v="d">Mostly desi</button><button data-v="e">Mostly everyday</button></div>
<label>Food</label><div class="seg" id="food"><button data-v="all" class="on">Everything</button><button data-v="egg">Vegetarian + eggs</button><button data-v="veg">Vegetarian (no eggs)</button></div>
<button class="go" onclick="plan()">Build my 7-day plan</button><div class="res" id="out"></div>"""
PLAN_JS = r"""const W={home:[['20-Minute Home Fat Burner','/workouts/20-min-home-fat-burner/'],['10-Minute Core (No Crunches)','/workouts/core-workout-no-crunches/'],['Beginner Dumbbell Full Body','/workouts/beginner-dumbbell-full-body/']],
gym:[['Push Day: Chest, Shoulders, Triceps','/workouts/push-day-workout/'],['Pull Day: Back & Biceps','/workouts/pull-day-workout/'],['Leg Day for Beginners','/workouts/leg-day-for-beginners/'],['Beginner Dumbbell Full Body','/workouts/beginner-dumbbell-full-body/']]};
// [name, type B/M/S, cuisine d/e, diet meat/fish/egg/veg, kcal, protein, items [qty,unit,food,scalable], link]
const F=[
['Egg bhurji with roti','B','d','egg',380,28,[[2,'','eggs',1],[2,'','egg whites',1],[1,'','wholemeal roti',1],[1,'tsp','oil',0],[1,'','onion & tomato',0]],'/recipes/egg-bhurji-protein-wrap/'],
['Overnight protein oats','B','e','veg',420,30,[[50,'g','rolled oats',1],[200,'g','Greek yoghurt',1],[150,'ml','milk',1],[80,'g','berries',0]],'/recipes/overnight-protein-oats/'],
['Greek yoghurt, fruit & nuts','B','e','veg',380,28,[[250,'g','Greek yoghurt',1],[1,'','banana',0],[15,'g','almonds',1]]],
['Scrambled eggs on toast','B','e','egg',450,28,[[3,'','eggs',1],[2,'slices','wholegrain toast',1],[1,'handful','spinach',0]]],
['Paneer & roti breakfast','B','d','veg',430,26,[[60,'g','paneer',1],[1,'','wholemeal roti',1],[150,'g','plain yoghurt',1],[1,'','cucumber & tomato',0]]],
['Protein smoothie','B','e','veg',420,36,[[30,'g','whey protein',1],[1,'','banana',0],[250,'ml','milk',1],[30,'g','rolled oats',1]]],
['Moong dal chilla + yoghurt','B','d','veg',380,26,[[60,'g','moong dal (dry)',1],[150,'g','plain yoghurt',1],[1,'','onion, chilli & coriander',0]]],
['Chicken tikka rice bowl','M','d','meat',580,50,[[150,'g','chicken breast',1],[0.75,'cup','cooked basmati rice',1],[100,'g','plain yoghurt (raita)',1],[1,'bowl','salad',0]],'/recipes/air-fryer-chicken-tikka/'],
['Chicken karahi with roti','M','d','meat',520,45,[[150,'g','chicken breast',1],[1,'','wholemeal roti',1],[1,'tsp','oil',0],[1,'bowl','kachumber salad',0]],'/recipes/high-protein-chicken-karahi/'],
['Keema with peas & rice','M','d','meat',600,42,[[150,'g','lean beef/chicken mince',1],[0.5,'cup','peas',1],[0.75,'cup','cooked basmati rice',1]],'/recipes/chicken-keema-with-peas/'],
['Masoor dal, rice & yoghurt','M','d','veg',560,30,[[1.5,'cup','cooked masoor dal',1],[0.75,'cup','cooked basmati rice',1],[150,'g','plain yoghurt',1]],'/recipes/protein-packed-masoor-dal/'],
['Chana masala with roti & raita','M','d','veg',560,26,[[1.5,'cup','cooked chickpeas',1],[1,'','wholemeal roti',1],[150,'g','plain yoghurt',1]]],
['Paneer tikka, salad & roti','M','d','veg',560,32,[[120,'g','paneer',1],[1,'','wholemeal roti',1],[1,'bowl','salad',0]]],
['Fish curry with rice','M','d','fish',520,42,[[180,'g','white fish',1],[0.75,'cup','cooked basmati rice',1],[1,'tsp','oil',0]]],
['Salmon, rice & greens','M','e','fish',600,38,[[150,'g','salmon fillet',1],[0.75,'cup','cooked rice',1],[1,'cup','broccoli/beans',0]]],
['Chicken & kūmara bowl','M','e','meat',520,48,[[150,'g','chicken breast',1],[150,'g','kūmara',1],[1,'cup','mixed veg',0]]],
['Beef burrito bowl','M','e','meat',620,45,[[150,'g','lean beef mince',1],[0.5,'cup','cooked rice',1],[0.5,'cup','black beans',1],[1,'','salsa & lettuce',0]]],
['Chicken salad wrap','M','e','meat',520,48,[[150,'g','chicken breast',1],[1,'','large wholemeal wrap',1],[2,'tbsp','yoghurt-mint sauce',0],[1,'bowl','salad',0]]],
['Tuna pasta salad','M','e','fish',520,42,[[1,'tin (185g)','tuna in springwater',1],[70,'g','pasta (dry)',1],[1,'cup','mixed veg',0]]],
['Chicken stir-fry with noodles','M','e','meat',560,45,[[150,'g','chicken breast',1],[60,'g','noodles (dry)',1],[1.5,'cup','stir-fry veg',0]]],
['Tofu & veg stir-fry with rice','M','e','veg',520,30,[[200,'g','firm tofu',1],[0.75,'cup','cooked rice',1],[1.5,'cup','stir-fry veg',0]]],
['Egg fried rice (lighter)','M','e','egg',520,32,[[3,'','eggs',1],[2,'','egg whites',1],[0.75,'cup','cooked rice',1],[1,'cup','mixed veg',0]]],
['Lentil & bean chilli','M','e','veg',520,28,[[1,'cup','cooked lentils',1],[0.5,'cup','kidney beans',1],[1,'','tomato & spices',0]]],
['Whey shake','S','e','veg',120,24,[[30,'g','whey protein',1]]],
['Greek yoghurt & fruit','S','e','veg',220,20,[[200,'g','Greek yoghurt',1],[1,'','piece of fruit',0]]],
['Roasted chana','S','d','veg',160,9,[[40,'g','roasted chana',1]]],
['Boiled eggs & fruit','S','e','egg',220,13,[[2,'','eggs',1],[1,'','piece of fruit',0]]],
['Tuna & crackers','S','e','fish',200,22,[[1,'tin (95g)','tuna',1],[4,'','wholegrain crackers',1]]],
['High-protein lassi','S','d','veg',200,18,[[250,'g','plain yoghurt',1],[0.5,'','mango (or ice)',0]],'/recipes/high-protein-mango-lassi/']];
const L=(x)=>`<a href="${PFX}${x[1]}">${x[0]}</a>`;
function fq(q,u){if(q>=20)return Math.round(q/5)*5;if(u===''||/slice|tin|bowl/.test(u||''))return Math.max(0.5,Math.round(q*2)/2);return Math.round(q*4)/4;}
const us=(u)=>u?((u==='g'||u==='ml')?u:' '+u):'';
function ok(m,food){if(food==='veg')return m[3]==='veg';if(food==='egg')return m[3]==='veg'||m[3]==='egg';return true;}
function plan(){const sex=sv('sex'),age=nv('age'),cm=nv('cm'),kg=nv('kg'),act=parseFloat(document.getElementById('act').value),goal=sv('goal'),where=sv('where'),d=parseInt(sv('days')),food=sv('food'),nm=parseInt(sv('meals')),st=sv('style'),cu=sv('cuisine');
if(!(age&&cm&&kg))return;const t=bmr(sex,kg,cm,age)*act;let cal=goal==='lose'?t*0.8:goal==='tone'?t*0.9:t*1.08;const fl=sex==='m'?1500:1200;if(cal<fl)cal=fl;cal=r10(cal);
const pro=Math.round(kg*(goal==='gain'?2.0:1.8)),steps=goal==='lose'?'8,000–10,000':'7,000–9,000';
const struct={2:['M','M'],3:st==='if'?['M','S','M']:['B','M','M'],4:st==='if'?['M','S','M','S']:['B','M','S','M'],5:st==='if'?['B','S','M','S','M']:['B','S','M','S','M']}[nm];
const times=st==='if'?{2:['12:00pm','7:30pm'],3:['12:00pm','3:30pm','7:30pm'],4:['12:00pm','3:00pm','6:30pm','7:45pm'],5:['12:00pm','2:00pm','4:00pm','6:00pm','7:45pm']}[nm]:{2:['12:30pm','7:00pm'],3:['7:30am','12:30pm','7:00pm'],4:['7:30am','12:30pm','4:00pm','7:00pm'],5:['7:30am','10:30am','1:00pm','4:00pm','7:00pm']}[nm];
const lab={B:'Breakfast',M:'Main meal',S:'Snack'};
const want=(i)=>cu==='d'?(i%5!==4?'d':'e'):cu==='e'?(i%5!==4?'e':'d'):(i%5<3?'e':'d');
const pools={};['B','M','S'].forEach(ty=>pools[ty]=F.filter(m=>m[1]===ty&&ok(m,food)));
const names=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],pat={2:[0,3],3:[0,2,4],4:[0,1,3,4],5:[0,1,2,4,5]}[d];const ws=W[where];
let shop={},html=`<div class="big"><div><b>${cal}</b><span>kcal per day</span></div><div><b>${pro}g</b><span>protein per day</span></div><div><b>${nm}</b><span>meals per day</span></div><div><b>${steps}</b><span>steps per day</span></div></div>`;
html+=`<p class="meta">${st==='if'?'16:8 fasting: eat between 12pm and 8pm; water, black coffee or plain tea outside that window. ':''}Calories and protein are approximate — portions are scaled to your target. Check with your GP first if you have a medical condition, are pregnant or take medication.</p><button class="go" onclick="window.print()" style="margin:8px 0">Print / save as PDF</button><h3>Your 7-day plan</h3>`;
let k=0,used={};
names.forEach((n,di)=>{const tr=pat.includes(di);const w=tr?ws[(k++)%ws.length]:null;let day=[],tk=0,tp=0;
struct.forEach((ty,mi)=>{let pool=pools[ty].filter(m=>m[2]===want(di+mi));if(!pool.length)pool=pools[ty];
pool=pool.slice().sort((a,b)=>(used[a[0]]||0)-(used[b[0]]||0));const m=pool[(di+mi)%Math.min(3,pool.length)]||pool[0];used[m[0]]=(used[m[0]]||0)+1;day.push([ty,m]);tk+=m[4];tp+=m[5];});
const f=Math.max(0.7,Math.min(1.7,cal/tk));let dk=0,dp=0;
let rows=day.map(([ty,m],mi)=>{const kk=Math.round(m[4]*f/10)*10,pp=Math.round(m[5]*f);dk+=kk;dp+=pp;
const its=m[6].map(it=>{const q=it[3]?(/egg/.test(it[2])?Math.max(1,Math.round(it[0]*f)):fq(it[0]*f,it[1])):it[0];if(it[3]){const key=it[2]+'|'+it[1];shop[key]=(shop[key]||0)+q;}else{shop[it[2]+'|'+it[1]]=shop[it[2]+'|'+it[1]]||0;}return `${q}${us(it[1])} ${it[2]}`;}).join(' · ');
const nmL=m[7]?`<a href="${PFX}${m[7]}">${m[0]}</a>`:m[0];
return `<tr><td><b>${times[mi]}</b><br><small>${lab[ty]}</small></td><td><b>${nmL}</b><br><small>${its}</small></td><td class="n">${kk} kcal<br>${pp}g P</td></tr>`;}).join('');
html+=`<div class="day"><b>${n}</b> · ${tr?'Workout: '+L(w):(di===6?'Rest + long walk':'Active rest: 30–45 min walk')}<table>${rows}<tr><td></td><td><b>Day total</b></td><td class="n"><b>${dk} kcal<br>${dp}g P</b></td></tr></table></div>`;});
const sl=Object.keys(shop).sort().map(key=>{const [nmx,u]=key.split('|');const q=shop[key];return `<li>${q?fq(q,u)+us(u)+' ':''}${nmx}</li>`}).join('');
html+=`<h3>Shopping list for the week</h3><ul style="columns:2">${sl}</ul><h3>Daily rules</h3><ul><li>Hit about ${pro}g protein a day — protein first at every meal.</li><li>Measure oil (1 tsp per serve) — it's the biggest hidden calorie source.</li><li>Swap meals freely within the same type; keep portions similar.</li><li>Water before meals; limit sugary drinks and chai sugar.</li><li>Sleep 7–9 hours. Weigh in most mornings and use the weekly average; adjust by 100–150 kcal after 2 weeks if needed.</li></ul><p>Save or print this plan. New tips daily at 6:30pm on <a href="https://www.youtube.com/channel/UCOWbB203EHcPglSFcwW2j3g?sub_confirmation=1">YouTube</a>.</p>`;
const o=document.getElementById('out');o.innerHTML=html;o.classList.add('show');o.scrollIntoView({behavior:'smooth'});}"""

tools.append(tool_page("tools/plan-builder/", "Personal Fat Loss Plan Builder", "Free 7-Day Fat Loss Plan Builder (Workouts + Meals) | danfitnz",
    "Answer a few quick questions and get a detailed 7-day plan: your calories and protein, 2–5 meals a day (or 16:8 fasting), portions, workouts and a shopping list.",
    "Answer a few quick questions and get a personalised 7-day plan with your calories, protein, workouts and meals.",
    PLAN_FORM, PLAN_JS,
    "<h2>How your plan is built</h2><p>Your calories come from the Mifflin-St Jeor formula and your activity level, adjusted for your goal. Workouts are picked from danfitnz routines that match where you train, and meals come from a mix of high-protein everyday and desi dishes, with portions scaled to hit your calorie target. You choose 2–5 meals a day, normal eating or 16:8 fasting, cuisine and vegetarian options, and get a weekly shopping list. Everything runs in your browser and nothing you enter is stored or sent anywhere.</p>",
    [("Is this plan free?", "Yes, completely free, with no sign-up. Your answers stay on your device."),
     ("How long should I follow the plan?", "Give it at least 4 weeks. Adjust calories by 100–150 if your weekly average weight hasn't moved for 2–3 weeks.")]))

exec(open(os.path.join(HERE, "blog.py")).read())
blog_items = BLOG_LIST
# ---------- Ask danfitnz (smart answers from site content, runs in browser) ----------
index = [{"t": p["name"], "u": "/" + p["path"], "d": clean(p["desc"])} for p in pages] + \
        [{"t": b["name"], "u": "/" + b["path"], "d": b["desc"] + " " + b["text"]} for b in blog_items] + \
        [{"t": t["name"], "u": "/" + t["path"], "d": t["desc"]} for t in tools]
os.makedirs(f"{OUT}/ask", exist_ok=True)
ASK_JS = r"""const IDX=__IDX__;const STOP=new Set('a an the is it i my me to of in on for and or do does how what why can should much many with you your be are am will this that'.split(' '));
function toks(s){return s.toLowerCase().replace(/[^a-z0-9 ]/g,' ').split(/\s+/).filter(w=>w&&!STOP.has(w)).map(w=>w.replace(/(ing|es|s)$/,''))}
function ask(q){q=q||document.getElementById('q').value;document.getElementById('q').value=q;const qt=toks(q);if(!qt.length)return;
const scored=IDX.map(it=>{const tt=toks(it.t),dt=toks(it.d);let s=0;qt.forEach(w=>{if(tt.includes(w))s+=3;if(dt.includes(w))s+=1;});return [s,it]}).filter(x=>x[0]>0).sort((a,b)=>b[0]-a[0]).slice(0,4);
const o=document.getElementById('out');o.innerHTML=scored.length?scored.map(([s,it])=>{const sent=it.d.split(/(?<=[.!?])\s+/).find(x=>qt.some(w=>x.toLowerCase().includes(w)))||it.d;return `<div class="ans"><a href="${PFX}${it.u}">${it.t}</a><p style="margin:6px 0 0">${sent.slice(0,240)}</p></div>`}).join(''):'<p>No match yet. Try asking about protein, calories, walking, gym, recipes or myths.</p>';o.classList.add('show');}
document.getElementById('q').addEventListener('keydown',e=>{if(e.key==='Enter')ask()});"""
ask_body = f"""<h1>Ask danfitnz</h1><p class="lead">Type any fat-loss, gym or food question and get instant answers from danfitnz guides, recipes and tools.</p>{TOOL_CSS}
<div class="tool"><label for="q">Your question</label><input id="q" placeholder="e.g. how much protein do I need?" autocomplete="off"><button class="go" onclick="ask()">Ask</button>
<div class="chips">{"".join(f'<button onclick="ask(this.innerText)">{q}</button>' for q in ["How much protein do I need?", "Is rice bad for fat loss?", "Why did my weight jump?", "Beginner gym plan", "High protein dinner ideas", "Do supplements work?"])}</div>
<div class="res" id="out"></div></div><p class="note">Answers are matched from danfitnz content in your browser. Nothing you type is stored or sent anywhere.</p>{follow_box()}{SHARED_JS}<script>{ASK_JS.replace("__IDX__", json.dumps(index, ensure_ascii=False))}</script>"""
page("ask/", "Ask danfitnz: Instant Fat Loss & Fitness Answers", "Ask any fat-loss, gym or food question and get instant answers from danfitnz guides, recipes and free tools.",
     ask_body.replace("__PFX__", PREFIX), [{"@type": "WebApplication", "name": "Ask danfitnz", "url": f"{BASE}/ask/", "applicationCategory": "HealthApplication", "operatingSystem": "Any", "offers": {"@type": "Offer", "price": "0", "priceCurrency": "NZD"}}])
EXTRA_URLS.append("ask/")

# tools hub
page("tools/", "Free Fitness Calculators & Tools | danfitnz", "Free fitness tools: calorie deficit calculator, protein calculator, BMI, body fat calculator and a personalised 7-day fat-loss plan builder.",
     "<h1>Free fitness tools</h1><p class='lead'>Quick calculators and a personal plan builder. Free, no sign-up, and nothing you enter leaves your device.</p><div class='grid'>" +
     "".join(f'<a href="/{t["path"]}">{E(t["name"])}<small>{E(t["desc"][:95])}…</small></a>' for t in tools) +
     '<a href="/ask/">Ask danfitnz<small>Type any question and get instant answers from our guides.</small></a></div>' + follow_box(),
     [{"@type": "CollectionPage", "name": "Free fitness tools", "url": f"{BASE}/tools/"}, bc([("Home", BASE + "/"), ("Tools", f"{BASE}/tools/")])])
EXTRA_URLS.append("tools/")
TOOLS_LIST = tools
