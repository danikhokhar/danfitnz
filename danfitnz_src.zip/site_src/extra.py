# Executed inside site_build.py (shares its namespace): interactive tools, plan builder, Ask danfitnz, blog.
EXTRA_URLS = []
TOOL_CSS = """<style>
.tool{background:var(--card);border-radius:18px;padding:20px;margin:18px 0}
.tool label{display:block;font-weight:600;font-size:14px;color:var(--muted);margin:12px 0 4px}
.tool input,.tool select{width:100%;background:#111318;border:1px solid var(--line);color:var(--text);border-radius:12px;padding:12px;font:inherit}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.seg{display:flex;gap:8px;flex-wrap:wrap}.seg button{flex:1;min-width:90px;background:#111318;border:1px solid var(--line);color:var(--text);border-radius:12px;padding:11px;font:inherit;font-weight:700;cursor:pointer}
.seg button.on{background:var(--lime);color:var(--bg);border-color:var(--lime)}
.go{width:100%;margin-top:16px;background:var(--lime);color:var(--bg);border:0;border-radius:999px;padding:14px;font:inherit;font-weight:900;cursor:pointer;font-size:17px}
.res{display:none;margin-top:18px}.res.show{display:block}
.big{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px}.big div{background:#111318;border-radius:14px;padding:14px}.big b{display:block;font-size:28px;font-weight:900;color:var(--lime)}.big span{color:var(--muted);font-size:13px}
.day{background:#111318;border-radius:14px;padding:12px 14px;margin:8px 0}.day b{color:var(--lime)}
.ans{background:#111318;border-radius:14px;padding:14px;margin:10px 0}.ans a{font-weight:800}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.chips button{background:#111318;border:1px solid var(--line);color:var(--text);border-radius:999px;padding:8px 12px;font:inherit;font-size:14px;cursor:pointer}
@media(max-width:520px){.row{grid-template-columns:1fr}}
</style>"""
SHARED_JS = r"""<script>
const PFX='__PFX__';
function segs(){document.querySelectorAll('.seg').forEach(g=>g.querySelectorAll('button').forEach(b=>b.onclick=()=>{g.querySelectorAll('button').forEach(x=>x.classList.remove('on'));b.classList.add('on');}));}
function sv(id){const b=document.querySelector('#'+id+' .on');return b?b.dataset.v:null}
function nv(id){return parseFloat(document.getElementById(id).value)}
function bmr(sex,kg,cm,age){return 10*kg+6.25*cm-5*age+(sex==='m'?5:-161)}
function r10(x){return Math.round(x/10)*10}
segs();
(function(){const YTU='https://www.youtube.com/channel/UCOWbB203EHcPglSFcwW2j3g';let shown=false;
const css=document.createElement('style');css.textContent='.ytm{position:fixed;inset:0;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;z-index:999;padding:16px}.ytm>div{background:#1C1E24;border-radius:20px;max-width:420px;width:100%;padding:24px;text-align:center;position:relative}.ytm h3{margin:6px 0 8px;font-size:22px}.ytm p{color:#A0A3AD;margin:0 0 16px}.ytm a.ytb{display:block;background:#FF0033;color:#fff;border-radius:999px;padding:14px;font-weight:900;text-decoration:none;font-size:17px}.ytm button{background:none;border:0;color:#A0A3AD;margin-top:12px;font:inherit;cursor:pointer}';document.head.appendChild(css);
function pop(){if(shown)return;try{if(sessionStorage.getItem('ytp'))return;sessionStorage.setItem('ytp','1')}catch(e){}shown=true;
const m=document.createElement('div');m.className='ytm';m.innerHTML='<div role="dialog" aria-label="Subscribe on YouTube"><div style="font-size:42px">▶</div><h3>Your result is ready!</h3><p>Get a new fat-loss tip every day. Subscribe to danfitnz on YouTube, it\'s free.</p><a class="ytb" href="'+YTU+'?sub_confirmation=1" target="_blank" rel="noopener">Subscribe on YouTube</a><button type="button">Maybe later</button></div>';
m.addEventListener('click',ev=>{if(ev.target===m||ev.target.tagName==='BUTTON')m.remove()});document.body.appendChild(m);}
const out=document.getElementById('out');if(out&&!document.getElementById('q'))new MutationObserver(()=>{if(out.classList.contains('show'))setTimeout(pop,1400)}).observe(out,{attributes:true,childList:true});})();
</script>"""

def tool_page(path, h1, title, desc, lead, form, js, explain, faqs):
    faq_html = "".join(f"<h3>{E(q)}</h3><p>{E(a)}</p>" for q, a in faqs)
    body = f"""<p class="meta"><a href="/tools/">Free fitness tools</a></p><h1>{E(h1)}</h1><p class="lead">{E(lead)}</p>{TOOL_CSS}
<div class="tool">{form}</div>{explain}<h2>FAQ</h2>{faq_html}
<p class="note">Estimates only, based on standard formulas. Not medical advice. If you have a medical condition, are pregnant, or are under 18, talk to your GP first.</p>{follow_box()}{SHARED_JS}<script>{js}</script>"""
    sch = [{"@type": "WebApplication", "name": h1, "url": f"{BASE}/{path}", "applicationCategory": "HealthApplication", "operatingSystem": "Any",
            "offers": {"@type": "Offer", "price": "0", "priceCurrency": "NZD"}, "description": desc, "publisher": {"@id": BASE + "/#org"}},
           {"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in faqs]},
           bc([("Home", BASE + "/"), ("Free fitness tools", f"{BASE}/tools/"), (h1, f"{BASE}/{path}")])]
    page(path, title, desc, body.replace("__PFX__", PREFIX), sch)
    EXTRA_URLS.append(path)
    return dict(path=path, name=h1, desc=desc)

SEXAGE = """<label>Sex</label><div class="seg" id="sex"><button data-v="m" class="on">Male</button><button data-v="f">Female</button></div>
<div class="row"><div><label for="age">Age</label><input id="age" type="number" inputmode="numeric" value="30" min="15" max="90"></div>
<div><label for="cm">Height (cm)</label><input id="cm" type="number" inputmode="decimal" value="172"></div></div>
<div class="row"><div><label for="kg">Weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="85"></div>
<div><label for="act">Activity</label><select id="act"><option value="1.2">Desk job, little exercise</option><option value="1.375" selected>Light: 1–3 workouts/week</option><option value="1.55">Moderate: 3–5 workouts/week</option><option value="1.725">Very active: 6–7 workouts/week</option><option value="1.9">Physical job + training</option></select></div></div>"""

tools = []
tools.append(tool_page("tools/calorie-deficit-calculator/", "Calorie Deficit Calculator",
    "Calorie Deficit Calculator for Fat Loss (NZ) | danfitnz",
    "Free calorie deficit calculator: find your maintenance calories (TDEE), a safe fat-loss target and your daily protein in seconds.",
    "Find your maintenance calories, a realistic fat-loss target and how much protein to eat. Takes 20 seconds.",
    SEXAGE + """<label>Goal</label><div class="seg" id="goal"><button data-v="0.10">Slow &amp; easy</button><button data-v="0.20" class="on">Steady fat loss</button><button data-v="0.25">Faster</button></div>
<button class="go" onclick="calc()">Calculate my calories</button><div class="res" id="out"></div>""",
    r"""function calc(){const sex=sv('sex'),age=nv('age'),cm=nv('cm'),kg=nv('kg'),act=parseFloat(document.getElementById('act').value),g=parseFloat(sv('goal'));
if(!(age&&cm&&kg)){return}
const b=bmr(sex,kg,cm,age),t=b*act;let target=t*(1-g);const floor=sex==='m'?1500:1200;if(target<floor)target=floor;
const deficit=t-target,wk=deficit*7/7700,pro=Math.round(kg*1.8),proLo=Math.round(kg*1.6),proHi=Math.round(kg*2.2);
const fat=Math.round(target*0.27/9),carb=Math.max(0,Math.round((target-pro*4-fat*9)/4));
document.getElementById('out').innerHTML=`<div class="big"><div><b>${r10(t)}</b><span>maintenance kcal/day</span></div><div><b>${r10(target)}</b><span>fat-loss target kcal/day</span></div><div><b>${pro}g</b><span>protein/day (${proLo}–${proHi}g)</span></div><div><b>~${wk.toFixed(2)} kg</b><span>expected loss per week</span></div></div>
<p style="margin-top:14px">Rough daily macros: <b>${pro}g protein · ${fat}g fat · ${carb}g carbs</b>.</p><p>Stick to this for 2 weeks, weigh yourself most mornings and use the weekly average. Not dropping? Take off another 100–150 kcal. <a href="${PFX}/tools/plan-builder/">Turn this into a 7-day plan →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    """<h2>How this calculator works</h2><p>It uses the Mifflin-St Jeor equation, one of the most accurate everyday formulas for resting calories, then multiplies by your activity level to estimate maintenance (TDEE). The fat-loss target takes 10–25% off maintenance, never going below 1,200 kcal (women) or 1,500 kcal (men). Protein is set at 1.6–2.2g per kg of bodyweight, the range research supports for keeping muscle while dieting.</p>""",
    [("How big should my calorie deficit be?", "For most people, 15–20% below maintenance (often 300–600 kcal a day) gives steady fat loss of about 0.3–0.7 kg per week without wrecking energy or training."),
     ("Why am I not losing weight on my deficit?", "Daily weight bounces with water, salt and carbs. Track your weekly average for 2–3 weeks. If it's flat, lower calories by 100–150 or add 2,000 more steps a day."),
     ("Do I need to count calories forever?", "No. Count for a few weeks to learn portions, then switch to simple habits like protein first, half a plate of veg and fewer liquid calories.")]))

tools.append(tool_page("tools/protein-calculator/", "Protein Calculator", "Protein Calculator: How Much Protein Do I Need? | danfitnz",
    "Free protein calculator: find how much protein you need per day for fat loss or muscle gain, plus how much per meal.",
    "How much protein you need each day, and how to split it across your meals.",
    """<label for="kg">Weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="80">
<label>Goal</label><div class="seg" id="goal"><button data-v="1.6">General health</button><button data-v="1.8" class="on">Lose fat</button><button data-v="2.0">Build muscle</button></div>
<label for="meals">Meals per day</label><select id="meals"><option>2</option><option selected>3</option><option>4</option><option>5</option></select>
<button class="go" onclick="calc()">Calculate my protein</button><div class="res" id="out"></div>""",
    r"""function calc(){const kg=nv('kg'),f=parseFloat(sv('goal')),m=parseInt(document.getElementById('meals').value);if(!kg)return;
const p=Math.round(kg*f),per=Math.round(p/m);
document.getElementById('out').innerHTML=`<div class="big"><div><b>${p}g</b><span>protein per day</span></div><div><b>${per}g</b><span>per meal (${m} meals)</span></div></div>
<p style="margin-top:14px">Easy ways to hit ~${per}g: 150g cooked chicken breast (~45g), 3 eggs + 2 egg whites (~25g), 200g Greek yogurt (~20g), a bowl of dal with paneer (~25g). <a href="${PFX}/recipes/">See high-protein desi recipes →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    "<h2>Why protein matters for fat loss</h2><p>Protein is the most filling nutrient and helps you keep muscle while eating less. Most adults trying to lose fat do well on 1.6–2.2g per kg of bodyweight per day, spread over 3–4 meals.</p>",
    [("How much protein do I need to lose fat?", "Around 1.6–2.2g per kg of bodyweight per day. For an 80kg person that's roughly 130–175g."),
     ("Can I get enough protein without shakes?", "Yes. Build each meal around chicken, eggs, fish, Greek yogurt, paneer, lentils or tofu. Shakes are just convenient."),
     ("Is too much protein bad for you?", "For healthy adults, intakes in this range are considered safe. If you have kidney disease, check with your doctor.")]))

tools.append(tool_page("tools/bmi-calculator/", "BMI Calculator", "BMI Calculator (with Asian Cut-offs) | danfitnz",
    "Free BMI calculator with standard and Asian/South Asian cut-offs, plus what BMI can and can't tell you.",
    "Check your Body Mass Index, including the lower cut-offs often used for South Asian people.",
    """<div class="row"><div><label for="cm">Height (cm)</label><input id="cm" type="number" inputmode="decimal" value="172"></div><div><label for="kg">Weight (kg)</label><input id="kg" type="number" inputmode="decimal" value="80"></div></div>
<button class="go" onclick="calc()">Calculate BMI</button><div class="res" id="out"></div>""",
    r"""function calc(){const cm=nv('cm'),kg=nv('kg');if(!(cm&&kg))return;const b=kg/((cm/100)**2);
const std=b<18.5?'Underweight':b<25?'Healthy range':b<30?'Overweight':'Obese';const asn=b<18.5?'Underweight':b<23?'Healthy range':b<27.5?'Increased risk':'High risk';
const lo=(18.5*(cm/100)**2).toFixed(0),hi=(24.9*(cm/100)**2).toFixed(0);
document.getElementById('out').innerHTML=`<div class="big"><div><b>${b.toFixed(1)}</b><span>your BMI</span></div><div><b style="font-size:20px">${std}</b><span>standard (WHO)</span></div><div><b style="font-size:20px">${asn}</b><span>Asian cut-offs</span></div></div><p style="margin-top:14px">Healthy weight range for your height (standard): <b>${lo}–${hi} kg</b>. BMI doesn't separate muscle from fat, so also check your waist. <a href="${PFX}/tools/body-fat-calculator/">Estimate body fat →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    "<h2>About BMI</h2><p>BMI is weight divided by height squared. It's a quick screening tool, not a diagnosis. Because people of South Asian descent tend to carry more body fat at the same BMI, health bodies often use lower cut-offs (23 for overweight, 27.5 for obesity).</p>",
    [("What is a healthy BMI?", "18.5–24.9 is the standard healthy range. For South Asian adults, 18.5–22.9 is often used."),
     ("Is BMI accurate if I lift weights?", "Not very. Muscular people can show as overweight. Waist size and body fat estimates give a better picture.")]))

tools.append(tool_page("tools/body-fat-calculator/", "Body Fat Calculator", "Body Fat Calculator (Tape Measure Method) | danfitnz",
    "Free body fat percentage calculator using the US Navy tape-measure method: just height, neck and waist (and hips for women).",
    "Estimate your body fat percentage with a tape measure. No scale tricks, no fancy gadgets.",
    """<label>Sex</label><div class="seg" id="sex"><button data-v="m" class="on">Male</button><button data-v="f">Female</button></div>
<div class="row"><div><label for="cm">Height (cm)</label><input id="cm" type="number" inputmode="decimal" value="172"></div><div><label for="neck">Neck (cm)</label><input id="neck" type="number" inputmode="decimal" value="38"></div></div>
<div class="row"><div><label for="waist">Waist at navel (cm)</label><input id="waist" type="number" inputmode="decimal" value="92"></div><div><label for="hip">Hips, women only (cm)</label><input id="hip" type="number" inputmode="decimal" value="100"></div></div>
<button class="go" onclick="calc()">Estimate body fat</button><div class="res" id="out"></div>""",
    r"""function calc(){const sex=sv('sex'),h=nv('cm'),n=nv('neck'),w=nv('waist'),hp=nv('hip');let bf;
if(sex==='m'){if(w<=n)return;bf=495/(1.0324-0.19077*Math.log10(w-n)+0.15456*Math.log10(h))-450}else{if(w+hp<=n)return;bf=495/(1.29579-0.35004*Math.log10(w+hp-n)+0.22100*Math.log10(h))-450}
const c=sex==='m'?(bf<14?'Athletic':bf<18?'Fit':bf<25?'Average':'Above average'):(bf<21?'Athletic':bf<25?'Fit':bf<32?'Average':'Above average');
document.getElementById('out').innerHTML=`<div class="big"><div><b>${bf.toFixed(1)}%</b><span>estimated body fat</span></div><div><b style="font-size:20px">${c}</b><span>general category</span></div></div><p style="margin-top:14px">Re-measure every 2–4 weeks at the same time of day. A shrinking waist is one of the best signs you're losing fat. <a href="${PFX}/tools/calorie-deficit-calculator/">Set your calorie target →</a></p>`;
document.getElementById('out').classList.add('show');}""",
    "<h2>How to measure</h2><p>Measure your neck just below the Adam's apple and your waist at the navel (men) or narrowest point (women), with the tape snug but not squeezing. Women also measure hips at the widest point. The US Navy formula is usually within a few percent of lab tests.</p>",
    [("How accurate is the tape measure body fat method?", "Typically within about 3–4% of lab methods, and very good for tracking change over time if you measure the same way."),
     ("What's a healthy body fat percentage?", "Roughly 10–20% for men and 18–30% for women is a common healthy range.")]))

PLAN_FORM = SEXAGE + """<label>Goal</label><div class="seg" id="goal"><button data-v="lose" class="on">Lose fat</button><button data-v="tone">Get fit &amp; toned</button><button data-v="gain">Build muscle</button></div>
<label>Where do you train?</label><div class="seg" id="where"><button data-v="home" class="on">Home</button><button data-v="gym">Gym</button></div>
<label>Training days per week</label><div class="seg" id="days"><button data-v="2">2</button><button data-v="3" class="on">3</button><button data-v="4">4</button><button data-v="5">5</button></div>
<label>Food</label><div class="seg" id="food"><button data-v="all" class="on">Everything</button><button data-v="veg">Vegetarian (eggs ok)</button></div>
<button class="go" onclick="plan()">Build my 7-day plan</button><div class="res" id="out"></div>"""
PLAN_JS = r"""const W={home:[['20-Minute Home Fat Burner','/workouts/20-min-home-fat-burner/'],['10-Minute Core (No Crunches)','/workouts/core-workout-no-crunches/'],['Beginner Dumbbell Full Body','/workouts/beginner-dumbbell-full-body/']],
gym:[['Push Day: Chest, Shoulders, Triceps','/workouts/push-day-workout/'],['Pull Day: Back & Biceps','/workouts/pull-day-workout/'],['Leg Day for Beginners','/workouts/leg-day-for-beginners/'],['Beginner Dumbbell Full Body','/workouts/beginner-dumbbell-full-body/']]};
const M={all:[['Chicken Karahi','/recipes/high-protein-chicken-karahi/'],['Air Fryer Chicken Tikka','/recipes/air-fryer-chicken-tikka/'],['Chicken Keema with Peas','/recipes/chicken-keema-with-peas/'],['Egg Bhurji Wrap','/recipes/egg-bhurji-protein-wrap/'],['Masoor Dal','/recipes/protein-packed-masoor-dal/']],
veg:[['Masoor Dal','/recipes/protein-packed-masoor-dal/'],['Egg Bhurji Wrap','/recipes/egg-bhurji-protein-wrap/']]};
const B=[['Overnight Protein Oats','/recipes/overnight-protein-oats/'],['High-Protein Mango Lassi','/recipes/high-protein-mango-lassi/'],['Egg Bhurji Wrap','/recipes/egg-bhurji-protein-wrap/']];
const L=(x)=>`<a href="${PFX}${x[1]}">${x[0]}</a>`;
function plan(){const sex=sv('sex'),age=nv('age'),cm=nv('cm'),kg=nv('kg'),act=parseFloat(document.getElementById('act').value),goal=sv('goal'),where=sv('where'),d=parseInt(sv('days')),food=sv('food');
if(!(age&&cm&&kg))return;const t=bmr(sex,kg,cm,age)*act;let cal=goal==='lose'?t*0.8:goal==='tone'?t*0.9:t*1.08;const fl=sex==='m'?1500:1200;if(cal<fl)cal=fl;
const pro=Math.round(kg*(goal==='gain'?2.0:1.8)),steps=goal==='lose'?'8,000–10,000':'7,000–9,000';
const names=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],pat={2:[0,3],3:[0,2,4],4:[0,1,3,4],5:[0,1,2,4,5]}[d];
const ws=W[where],ms=M[food];let html=`<div class="big"><div><b>${r10(cal)}</b><span>kcal per day</span></div><div><b>${pro}g</b><span>protein per day</span></div><div><b>${steps}</b><span>steps per day</span></div><div><b>${d}x</b><span>workouts per week</span></div></div><h3>Your week</h3>`;
let k=0;names.forEach((n,i)=>{const tr=pat.includes(i);const w=tr?ws[(k++)%ws.length]:null;
html+=`<div class="day"><b>${n}</b> · ${tr?'Workout: '+L(w):(i===6?'Rest + long walk':'Active rest: 30–45 min walk')}<br>Breakfast: ${L(B[i%B.length])} · Dinner: ${L(ms[i%ms.length])}</div>`});
html+=`<h3>Daily rules</h3><ul><li>Eat ~${Math.round(pro/3)}g protein at each main meal, protein first.</li><li>Half your plate veg or salad; rice/roti portion about one fist.</li><li>Water before meals, limit sugary drinks.</li><li>Sleep 7–9 hours. Weigh in most mornings and watch the weekly average.</li></ul><p>Save or screenshot this plan. New tips daily at 6:30pm on <a href="https://www.youtube.com/channel/UCOWbB203EHcPglSFcwW2j3g?sub_confirmation=1">YouTube</a>.</p>`;
const o=document.getElementById('out');o.innerHTML=html;o.classList.add('show');o.scrollIntoView({behavior:'smooth'});}"""
tools.append(tool_page("tools/plan-builder/", "Personal Fat Loss Plan Builder", "Free 7-Day Fat Loss Plan Builder (Workouts + Meals) | danfitnz",
    "Answer 8 quick questions and get a personalised 7-day plan: calories, protein, workouts for home or gym, and high-protein meals.",
    "Answer a few quick questions and get a personalised 7-day plan with your calories, protein, workouts and meals.",
    PLAN_FORM, PLAN_JS,
    "<h2>How your plan is built</h2><p>Your calories come from the Mifflin-St Jeor formula and your activity level, adjusted for your goal. Workouts are picked from danfitnz routines that match where you train, and meals come from our high-protein desi recipes. Everything runs in your browser and nothing you enter is stored or sent anywhere.</p>",
    [("Is this plan free?", "Yes, completely free, with no sign-up. Your answers stay on your device."),
     ("How long should I follow the plan?", "Give it at least 4 weeks. Adjust calories by 100–150 if your weekly average weight hasn't moved for 2–3 weeks.")]))

exec(open(os.path.join(HERE, "blog.py")).read())
blog_items = BLOG_LIST
# ---------- Ask danfitnz (smart answers from site content, runs in browser) ----------
index = [{"t": p["name"], "u": "/" + p["path"], "d": clean(p["desc"])} for p in pages] + \
        [{"t": b["name"], "u": "/" + b["path"], "d": b["desc"] + " " + b["text"]} for b in blog_items] + \
        [{"t": t["name"], "u": "/" + t["path"], "d": t["desc"]} for t in tools]
os.makedirs(f"{OUT}/ask", exist_ok=True)
ASK_JS = r"""const IDX=__IDX__;const STOP=new Set('a an the is it i my me to of in on for and or do does how what why can should much many with you your be are am will this that'.split(' '));
function toks(s){return s.toLowerCase().replace(/[^a-z0-9 ]/g,' ').split(/\s+/).filter(w=>w&&!STOP.has(w)).map(w=>w.replace(/(ing|es|s)$/,''))}
function ask(q){q=q||document.getElementById('q').value;document.getElementById('q').value=q;const qt=toks(q);if(!qt.length)return;
const scored=IDX.map(it=>{const tt=toks(it.t),dt=toks(it.d);let s=0;qt.forEach(w=>{if(tt.includes(w))s+=3;if(dt.includes(w))s+=1;});return [s,it]}).filter(x=>x[0]>0).sort((a,b)=>b[0]-a[0]).slice(0,4);
const o=document.getElementById('out');o.innerHTML=scored.length?scored.map(([s,it])=>{const sent=it.d.split(/(?<=[.!?])\s+/).find(x=>qt.some(w=>x.toLowerCase().includes(w)))||it.d;return `<div class="ans"><a href="${PFX}${it.u}">${it.t}</a><p style="margin:6px 0 0">${sent.slice(0,240)}</p></div>`}).join(''):'<p>No match yet. Try asking about protein, calories, walking, gym, recipes or myths.</p>';o.classList.add('show');}
document.getElementById('q').addEventListener('keydown',e=>{if(e.key==='Enter')ask()});"""
ask_body = f"""<h1>Ask danfitnz</h1><p class="lead">Type any fat-loss, gym or food question and get instant answers from danfitnz guides, recipes and tools.</p>{TOOL_CSS}
<div class="tool"><label for="q">Your question</label><input id="q" placeholder="e.g. how much protein do I need?" autocomplete="off"><button class="go" onclick="ask()">Ask</button>
<div class="chips">{"".join(f'<button onclick="ask(this.innerText)">{q}</button>' for q in ["How much protein do I need?", "Is rice bad for fat loss?", "Why did my weight jump?", "Beginner gym plan", "High protein desi dinner", "Do supplements work?"])}</div>
<div class="res" id="out"></div></div><p class="note">Answers are matched from danfitnz content in your browser. Nothing you type is stored or sent anywhere.</p>{follow_box()}{SHARED_JS}<script>{ASK_JS.replace("__IDX__", json.dumps(index, ensure_ascii=False))}</script>"""
page("ask/", "Ask danfitnz: Instant Fat Loss & Fitness Answers", "Ask any fat-loss, gym or food question and get instant answers from danfitnz guides, recipes and free tools.",
     ask_body.replace("__PFX__", PREFIX), [{"@type": "WebApplication", "name": "Ask danfitnz", "url": f"{BASE}/ask/", "applicationCategory": "HealthApplication", "operatingSystem": "Any", "offers": {"@type": "Offer", "price": "0", "priceCurrency": "NZD"}}])
EXTRA_URLS.append("ask/")

# tools hub
page("tools/", "Free Fitness Calculators & Tools | danfitnz", "Free fitness tools: calorie deficit calculator, protein calculator, BMI, body fat calculator and a personalised 7-day fat-loss plan builder.",
     "<h1>Free fitness tools</h1><p class='lead'>Quick calculators and a personal plan builder. Free, no sign-up, and nothing you enter leaves your device.</p><div class='grid'>" +
     "".join(f'<a href="/{t["path"]}">{E(t["name"])}<small>{E(t["desc"][:95])}…</small></a>' for t in tools) +
     '<a href="/ask/">Ask danfitnz<small>Type any question and get instant answers from our guides.</small></a></div>' + follow_box(),
     [{"@type": "CollectionPage", "name": "Free fitness tools", "url": f"{BASE}/tools/"}, bc([("Home", BASE + "/"), ("Tools", f"{BASE}/tools/")])])
EXTRA_URLS.append("tools/")
TOOLS_LIST = tools
