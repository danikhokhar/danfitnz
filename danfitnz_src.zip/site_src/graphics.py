"""Branded images for the danfitnz site: Open Graph cards and blog infographics (PIL only)."""
import os
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
BG, CARD, LIME, WHITE, GREY, RED = (14, 15, 18), (28, 30, 36), (198, 255, 61), (245, 245, 245), (160, 163, 173), (255, 107, 107)
_f = {}
def F(w, s):
    k = (w, s)
    if k not in _f: _f[k] = ImageFont.truetype(os.path.join(HERE, "fonts", f"Inter-{w}.otf"), s)
    return _f[k]
ICON = Image.open(os.path.join(HERE, "icon.png")).convert("RGBA")

def wrap(d, text, font, maxw):
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if d.textlength(t, font=font) <= maxw or not cur: cur = t
        else: lines.append(cur); cur = w
    if cur: lines.append(cur)
    return lines

def header(img, d, x, y, h=56):
    ic = ICON.resize((int(ICON.width * h / ICON.height), h), Image.LANCZOS)
    img.alpha_composite(ic, (x, y))
    d.text((x + ic.width + 16, y + h // 2), "danfitnz", font=F("Black", int(h * 0.7)), fill=WHITE, anchor="lm")

def og_image(path, title, kicker=""):
    if os.path.exists(path): return
    img = Image.new("RGBA", (1200, 630), BG + (255,)); d = ImageDraw.Draw(img)
    header(img, d, 70, 60)
    size = 76
    while True:
        lines = wrap(d, title, F("Black", size), 1060)
        if len(lines) <= 4 or size <= 44: break
        size -= 6
    y = 630 - 90 - len(lines) * int(size * 1.12)
    if kicker:
        d.text((70, y - 60), kicker.upper(), font=F("Bold", 30), fill=LIME);
    for ln in lines:
        d.text((70, y), ln, font=F("Black", size), fill=WHITE); y += int(size * 1.12)
    d.rectangle([70, 580, 1130, 586], fill=LIME)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.convert("RGB").save(path, "PNG", optimize=True)

def visual(path, spec):
    """spec: {type: bars|steps|compare|stats, title, items, note?}"""
    W = 1200; t = spec["type"]; items = spec["items"]
    tmp = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    rows = []
    if t == "bars": H = 230 + len(items) * 110
    elif t == "steps":
        for it in items: rows.append(wrap(tmp, it, F("SemiBold", 40), W - 300))
        H = 230 + sum(max(1, len(r)) * 52 + 58 for r in rows)
    elif t == "compare":
        n = max(len(items[0][1]), len(items[1][1])); H = 300 + n * 120
    else: H = 230 + ((len(items) + 1) // 2) * 250
    H += 60 if spec.get("note") else 0
    H += 60 * (min(2, len(wrap(tmp, spec["title"], F("Black", 52), W - 120))) - 1)
    img = Image.new("RGBA", (W, H), BG + (255,)); d = ImageDraw.Draw(img)
    header(img, d, 60, 40, 44)
    tl = wrap(d, spec["title"], F("Black", 52), W - 120)[:2]
    y = 120
    for ln in tl: d.text((60, y), ln, font=F("Black", 52), fill=WHITE); y += 60
    y += 30
    if t == "bars":
        mx = max(v for _, v, _ in items)
        for lab, v, unit in items:
            d.text((60, y), lab, font=F("SemiBold", 34), fill=WHITE)
            bw = int((W - 120) * v / mx)
            d.rounded_rectangle([60, y + 48, 60 + max(bw, 24), y + 88], 20, fill=LIME)
            vt = f"{v:g}{unit}"
            tx = 60 + bw - 16 if bw > 200 else 60 + bw + 16
            d.text((tx, y + 68), vt, font=F("Black", 30), fill=BG if bw > 200 else LIME, anchor="rm" if bw > 200 else "lm")
            y += 110
    elif t == "steps":
        for i, r in enumerate(rows):
            h = max(1, len(r)) * 52 + 34
            d.rounded_rectangle([60, y, W - 60, y + h], 26, fill=CARD)
            d.ellipse([90, y + h // 2 - 36, 162, y + h // 2 + 36], fill=LIME)
            d.text((126, y + h // 2), str(i + 1), font=F("Black", 40), fill=BG, anchor="mm")
            yy = y + 17
            for ln in r: d.text((200, yy), ln, font=F("SemiBold", 40), fill=WHITE); yy += 52
            y += h + 24
    elif t == "compare":
        colw = (W - 150) // 2
        for c, (head, lst) in enumerate(items):
            neutral = spec.get("neutral"); x = 60 + c * (colw + 30); col = LIME if c == 0 else ((120, 200, 255) if neutral else RED)
            d.rounded_rectangle([x, y, x + colw, H - 50 - (60 if spec.get("note") else 0)], 26, fill=CARD)
            d.text((x + 30, y + 30), head.upper(), font=F("Black", 38), fill=col)
            yy = y + 100
            for it in lst:
                for k, ln in enumerate(wrap(d, it, F("Medium", 32), colw - 90)[:2]):
                    if k == 0:
                        cy = yy + 20
                        if c == 0 or neutral: d.line([(x + 32, cy), (x + 42, cy + 10), (x + 60, cy - 10)], fill=col, width=6, joint="curve")
                        else: d.line([(x + 34, cy - 10), (x + 54, cy + 10)], fill=col, width=6); d.line([(x + 34, cy + 10), (x + 54, cy - 10)], fill=col, width=6)
                    d.text((x + 76, yy), ln, font=F("Medium", 32), fill=WHITE); yy += 40
                yy += 40
    else:  # stats
        cw = (W - 150) // 2
        for i, (big, lab) in enumerate(items):
            x = 60 + (i % 2) * (cw + 30); yy = y + (i // 2) * 250
            d.rounded_rectangle([x, yy, x + cw, yy + 220], 26, fill=CARD)
            d.text((x + 34, yy + 30), big, font=F("Black", 84), fill=LIME)
            for k, ln in enumerate(wrap(d, lab, F("Medium", 32), cw - 68)[:2]): d.text((x + 34, yy + 138 + k * 38), ln, font=F("Medium", 32), fill=GREY)
    if spec.get("note"): d.text((60, H - 70), spec["note"], font=F("Medium", 28), fill=GREY)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.convert("RGB").save(path, "PNG", optimize=True)
    return W, H

def pin_image(path, title, kicker="", sub="", product_png=None):
    """1000x1500 Pinterest pin."""
    if os.path.exists(path): return
    W, H = 1000, 1500
    img = Image.new("RGBA", (W, H), BG + (255,)); d = ImageDraw.Draw(img)
    header(img, d, 60, 60, 60)
    y = 190
    if product_png and os.path.exists(product_png):
        pr = Image.open(product_png).convert("RGBA"); pr = pr.resize((880, int(880 * pr.height / pr.width)))
        img.alpha_composite(pr, (60, y)); y += pr.height + 40
    if kicker:
        d.text((60, y), kicker.upper(), font=F("Bold", 34), fill=LIME); y += 60
    size = 92 if not product_png else 70
    while True:
        lines = wrap(d, title, F("Black", size), W - 120)
        if len(lines) <= (6 if not product_png else 3) or size <= 48: break
        size -= 6
    for ln in lines:
        d.text((60, y), ln, font=F("Black", size), fill=WHITE); y += int(size * 1.15)
    if sub:
        y += 20
        for ln in wrap(d, sub, F("Medium", 38), W - 120)[:4]:
            d.text((60, y), ln, font=F("Medium", 38), fill=GREY); y += 50
    d.rounded_rectangle([60, H - 170, W - 60, H - 70], 50, fill=LIME)
    d.text((W // 2, H - 120), "Read more at danfitnz.nz", font=F("Black", 42), fill=BG, anchor="mm")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.convert("RGB").save(path, "PNG", optimize=True)


def stat_card(path, big1, lab1, big2, lab2):
    """880x620 macro card for recipe pins."""
    if os.path.exists(path): return path
    img = Image.new("RGBA", (880, 620), BG + (255,)); d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, 425, 600], 40, fill=LIME)
    d.rounded_rectangle([455, 0, 880, 600], 40, fill=(28, 30, 36))
    d.text((212, 270), big1, font=F("Black", 170), fill=BG, anchor="mm"); d.text((212, 440), lab1, font=F("Black", 54), fill=BG, anchor="mm")
    d.text((667, 270), big2, font=F("Black", 150), fill=WHITE, anchor="mm"); d.text((667, 440), lab2, font=F("Black", 54), fill=LIME, anchor="mm")
    os.makedirs(os.path.dirname(path), exist_ok=True); img.convert("RGB").save(path); return path


def quote_pin(path, quote, tag="Daily motivation", sign="Dan · lost 20 kg (44 lb) in 5 months", photo=None):
    """1000x1500 motivation pin: big quote, optional real photo strip."""
    if os.path.exists(path): return
    W, H = 1000, 1500
    img = Image.new("RGBA", (W, H), BG + (255,)); d = ImageDraw.Draw(img)
    header(img, d, 60, 60, 60)
    y = 200
    if photo and os.path.exists(photo):
        ph = Image.open(photo).convert("RGBA"); ph = ph.resize((880, int(880 * ph.height / ph.width)))
        ph = ph.crop((0, 0, 880, min(ph.height, 520))); img.alpha_composite(ph, (60, y)); y += ph.height + 50
    size = 96 if not photo else 64
    while True:
        lines = wrap(d, quote, F("Black", size), W - 120)
        if y + 180 + len(lines) * size * 1.2 < H - 330 or size <= 44: break
        size -= 4
    if not photo:  # centre the block vertically
        blk = 180 + len(lines) * size * 1.2 + 110
        y = int(max(y, (200 + H - 220 - blk) / 2))
    d.text((60, y), tag.upper(), font=F("Bold", 34), fill=LIME); y += 50
    d.text((48, y - 20), "“", font=F("Black", 200), fill=LIME); y += 130
    for ln in lines:
        d.text((60, y), ln, font=F("Black", size), fill=WHITE); y += int(size * 1.2)
    y += 30; d.text((60, y), "— " + sign, font=F("Medium", 36), fill=GREY)
    d.rounded_rectangle([60, H - 170, W - 60, H - 70], 50, fill=LIME)
    d.text((W // 2, H - 120), "Free plan at danfitnz.nz", font=F("Black", 42), fill=BG, anchor="mm")
    os.makedirs(os.path.dirname(path), exist_ok=True); img.convert("RGB").save(path, "PNG", optimize=True)
