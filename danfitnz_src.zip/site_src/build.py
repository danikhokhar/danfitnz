"""Build the danfitnz static website (SEO + AI-engine friendly) from the Reel content."""
import os, re, json, sys, html, shutil, datetime
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
CFG = json.load(open(os.path.join(HERE, "config.json")))
from content import REELS

BASE = os.environ.get("SITE_BASE", "https://danfitnz.github.io").rstrip("/")
OUT = os.environ.get("SITE_OUT", os.path.join(HERE, "..", "build", "site"))
PREFIX = os.environ.get("SITE_PREFIX", "").rstrip("/")
from zoneinfo import ZoneInfo
TODAY = os.environ.get("SITE_TODAY") or datetime.datetime.now(ZoneInfo("Pacific/Auckland")).date().isoformat()
YT = "https://www.youtube.com/channel/UCOWbB203EHcPglSFcwW2j3g"
SOCIAL = CFG["social"]
from graphics import og_image
E = html.escape
EMOJI = re.compile("[\U0001F000-\U0001FAFF☀-➿️‍]+")

def clean(s): return EMOJI.sub("", s).replace("  ", " ").strip()
SMALL = {"a", "an", "and", "the", "to", "of", "in", "on", "for", "with", "you", "your", "this", "that", "these", "at", "or"}
def tcase(s):
    out = []
    for i, w in enumerate(s.lower().split()):
        if i and w in SMALL: out.append(w); continue
        out.append("-".join(p[:1].upper() + p[1:] for p in w.split("-")))
    t = " ".join(out)
    return re.sub(r"(\d)G\b", r"\1g", t).replace("(no", "(No")
def slugify(s): return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")

CSS = """:root{--bg:#0E0F12;--card:#1C1E24;--lime:#C6FF3D;--text:#F5F5F5;--muted:#A0A3AD;--line:#2A2D35}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--text);font:17px/1.65 Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
a{color:var(--lime)}img{max-width:100%}
.wrap{max-width:760px;margin:0 auto;padding:0 18px}
header.site{border-bottom:1px solid var(--line)}header.site .wrap{display:flex;align-items:center;gap:14px;justify-content:space-between;padding:14px 18px;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:10px;color:var(--text);text-decoration:none;font-weight:900;font-size:22px}
.brand svg{width:30px;height:32px}
nav a{color:var(--text);text-decoration:none;margin-left:16px;font-weight:600;font-size:15px}nav a:hover{color:var(--lime)}
h1{font-size:clamp(30px,6vw,44px);line-height:1.1;font-weight:900;margin:34px 0 10px}
h2{font-size:24px;line-height:1.25;margin:34px 0 8px}h3{font-size:19px;margin:22px 0 4px}
.lead{color:var(--muted);font-size:19px;margin:0 0 20px}
.meta{color:var(--muted);font-size:14px}
.card{background:var(--card);border-radius:16px;padding:18px 20px;margin:16px 0}
.macros{display:flex;gap:12px;flex-wrap:wrap}.macro{background:var(--card);border-radius:14px;padding:14px 18px;min-width:140px}
.macro b{display:block;font-size:30px;font-weight:900}.macro.lime b{color:var(--lime)}.macro span{color:var(--muted);font-size:13px;letter-spacing:.06em}
table{width:100%;border-collapse:collapse;margin:12px 0}td,th{border-bottom:1px solid var(--line);padding:10px 6px;text-align:left}th{color:var(--muted);font-weight:600;font-size:14px}
td.n{color:var(--lime);font-weight:800;white-space:nowrap}
.myth{color:#FF6B6B;font-weight:800;letter-spacing:.04em;font-size:13px}.fact{color:var(--lime);font-weight:800;letter-spacing:.04em;font-size:13px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;margin:18px 0}
.grid a{display:block;background:var(--card);border-radius:14px;padding:16px;text-decoration:none;color:var(--text);font-weight:700}
.grid a small{display:block;color:var(--muted);font-weight:500;margin-top:6px}
.cta{background:var(--lime);color:var(--bg);border-radius:999px;padding:12px 20px;font-weight:800;text-decoration:none;display:inline-block;margin:6px 8px 6px 0}
.tag{display:inline-block;background:var(--card);border-radius:999px;padding:3px 10px;font-size:13px;color:var(--muted);margin-right:6px}
.note{color:var(--muted);font-size:14px;border-left:3px solid var(--line);padding-left:12px}
footer{border-top:1px solid var(--line);margin-top:50px;padding:24px 0;color:var(--muted);font-size:14px}
.ad-slot{display:none}.ads-on .ad-slot{display:block;min-height:120px;margin:22px 0;background:#15171c;border-radius:12px;text-align:center}.ads-on .ad-slot:before{content:"Advertisement";display:block;color:#5c5f68;font-size:11px;letter-spacing:.1em;padding-top:6px}
figure{margin:22px 0}figure img{width:100%;height:auto;border-radius:16px;display:block}figcaption{color:var(--muted);font-size:14px;margin-top:6px}
.toc{background:var(--card);border-radius:16px;padding:14px 20px;margin:18px 0}.toc ol{margin:6px 0 0;padding-left:20px}.toc a{color:var(--text);text-decoration:none}.toc a:hover{color:var(--lime)}
.chips2{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 18px}.chip{background:var(--card);border-radius:999px;padding:7px 13px;color:var(--text);text-decoration:none;font-size:14px;font-weight:600}.chip:hover{color:var(--lime)}.chip.on{background:var(--lime);color:#0E0F12}
.affgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}.exgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin:12px 0}.excard{display:block;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:10px;text-decoration:none;color:var(--text)}.excard b{display:block;margin-top:8px}.excard small{display:block;color:#a0a3ad}.exfig{position:relative;aspect-ratio:3/2;overflow:hidden;border-radius:10px;background:#fff}.exfig img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain}.exfig img.f2{animation:exf 3s infinite}@keyframes exf{0%,40%{opacity:0}50%,90%{opacity:1}100%{opacity:0}}.keybox{background:#1c1e24;border-left:4px solid var(--lime,#c6ff3d);border-radius:12px;padding:14px 18px;margin:18px 0}.keybox ul{margin:6px 0 0;padding-left:20px}.author{display:flex;gap:14px;align-items:flex-start;background:#1c1e24;border-radius:14px;padding:16px;margin:24px 0}.author img{width:56px;height:56px;border-radius:50%}.refs{font-size:.9em}.refs li{margin:4px 0}.check li{list-style:none}.check li:before{content:"☐ ";color:#c6ff3d}.tryit{background:#1c1e24;border:1px solid #c6ff3d66;border-radius:14px;padding:16px 18px;margin:22px 0}.tryit p{margin:6px 0 12px}.tryit .btn,.nextup{display:inline-block}.tryit .btn{background:var(--lime);color:#0E0F12;font-weight:800;border-radius:999px;padding:10px 18px;text-decoration:none}.quiz details{background:#1c1e24;border-radius:12px;padding:12px 16px;margin:8px 0}.quiz summary{cursor:pointer;font-weight:700}.quiz details p{margin:10px 0 0;color:#cfd2da}.nextup{display:block;background:#1c1e24;border-left:4px solid #c6ff3d;border-radius:12px;padding:14px 18px;margin:22px 0;text-decoration:none;color:var(--text)}.nextup small{display:block;color:#a0a3ad}.caution{background:#2a1d1d;border-left:4px solid #ff7a6b;border-radius:12px;padding:12px 16px;margin:18px 0}.askdan{background:#1c1e24;border-radius:12px;padding:12px 16px;margin:10px 0}.askdan p{margin:6px 0 0}sup .cite{font-size:.75em;text-decoration:none}.signup{background:linear-gradient(135deg,#1c2410,#1C1E24 60%);border:1px solid #3d4f12;border-radius:20px;padding:22px;margin:28px 0}.signup h2{margin:6px 0 6px;font-size:22px}.signup p{margin:0 0 12px;color:var(--muted)}.sgk{display:inline-block;background:var(--lime);color:#0E0F12;border-radius:99px;padding:2px 10px;font-size:12px}.signup form{display:flex;gap:8px;flex-wrap:wrap}.signup input{flex:1 1 220px;padding:13px 14px;border-radius:12px;border:1px solid var(--line);background:#111318;color:var(--text);font:inherit}.signup button{padding:13px 18px;border:0;border-radius:12px;background:var(--lime);color:#0E0F12;font-weight:800;font:inherit;font-weight:800;cursor:pointer}.signup .sgfine{font-size:12.5px;margin:10px 0 0}.sgbtn{display:inline-block;padding:13px 20px;border-radius:12px;background:var(--lime);color:#0E0F12!important;font-weight:800;text-decoration:none}.printbtn{background:#1c1e24;border:1px solid #c6ff3d;color:#c6ff3d;border-radius:999px;padding:9px 16px;font:inherit;font-weight:700;cursor:pointer}@media print{header.site,nav,.social,.card,.ad-slot,.affgrid,.printbtn,footer,.nextup,.tryit{display:none!important}body{background:#fff!important;color:#000!important}a{color:#000!important}.exfig img{filter:none}}.danbox{border:1px solid #c6ff3d55;border-radius:12px;padding:12px 16px;margin:18px 0}.affimg{display:block;width:100%;height:auto;aspect-ratio:16/10;border-radius:10px;margin:-2px 0 10px;background:#1c1e24}.aff{display:block;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;text-decoration:none;color:var(--text)}.aff small{display:block;color:var(--muted);margin:4px 0 8px}.aff span{color:var(--lime);font-weight:700;font-size:14px}
.social{display:flex;gap:8px;flex-wrap:wrap}.social a{background:#111318;border:1px solid var(--line);border-radius:999px;padding:9px 14px;color:var(--text);text-decoration:none;font-weight:700;font-size:14px}.social a.yt{background:#FF0033;border-color:#FF0033;color:#fff}
header.site{position:sticky;top:0;z-index:50;background:rgba(14,15,18,.96);backdrop-filter:blur(8px)}.menubtn,.hsearch{display:none}header.site .wrap{max-width:1180px;flex-wrap:nowrap}header.site nav{display:flex;gap:16px;flex-wrap:nowrap;white-space:nowrap}header.site nav a{margin:0}.navsearch{display:none}.hsform{order:3;flex:0 1 240px}.hsform input{width:100%;padding:9px 14px;border-radius:999px;border:1px solid var(--line);background:#16181d;color:var(--text);font:inherit;font-size:14px}.hsform input:focus{outline:2px solid var(--lime);border-color:transparent}@media(max-width:1060px){.hsform{flex-basis:170px}header.site nav{gap:12px;font-size:14px}}.totop{position:fixed;right:16px;bottom:16px;width:44px;height:44px;border-radius:50%;background:var(--lime);color:#0E0F12;display:flex;align-items:center;justify-content:center;font-weight:900;text-decoration:none;box-shadow:0 4px 14px rgba(0,0,0,.4);z-index:40}.fcols{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:18px;margin-bottom:18px}.fcols b{display:block;margin-bottom:6px;color:var(--text)}.fcols a{display:block;padding:4px 0}.hero{display:grid;grid-template-columns:1.3fr 1fr;gap:28px;align-items:center;margin:10px 0 8px}.hero img{width:100%;height:auto;border-radius:18px}.hero .ctas{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}.cta.ghost{background:transparent;border:2px solid var(--lime);color:var(--lime)}.goals{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}.goals a{display:block;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px;text-decoration:none;color:var(--text);font-weight:800;font-size:18px}.goals a span{display:block;font-size:30px;margin-bottom:6px}.goals a small{display:block;font-weight:500;color:var(--muted);font-size:14px;margin-top:4px}.goals a:hover{border-color:var(--lime)}.trust{display:flex;gap:18px;flex-wrap:wrap;color:var(--muted);font-size:14px;margin:12px 0}.trust b{color:var(--lime)}@media(max-width:760px){.hero{grid-template-columns:1fr}.hero img{max-width:420px}}@media(max-width:720px){.menubtn{display:block;background:none;border:1px solid var(--line);color:var(--text);border-radius:10px;font-size:22px;padding:4px 12px;cursor:pointer}.hsearch{display:block;margin-left:auto;text-decoration:none;font-size:20px}header.site .wrap{flex-wrap:wrap}.hsform{display:none}.navsearch{display:block!important}#mainnav{display:none;width:100%;flex-direction:column;gap:0}#mainnav.open{display:flex}#mainnav a{padding:12px 4px;border-top:1px solid var(--line);margin:0;font-size:17px}}"""

LOGO = '<svg viewBox="0 0 540 580" aria-hidden="true"><path d="M0 0H230C420 0 540 120 540 290C540 460 420 580 230 580H0Z" fill="#C6FF3D"/><path d="M95 440L235 300L310 375L445 240" fill="none" stroke="#0E0F12" stroke-width="58" stroke-linecap="round" stroke-linejoin="round"/><path d="M370 225H460V315" fill="none" stroke="#0E0F12" stroke-width="58" stroke-linecap="round" stroke-linejoin="round"/></svg>'
ORG = {"@type": "Organization", "@id": BASE + "/#org", "name": "danfitnz", "url": BASE + "/",
       "logo": BASE + "/favicon-512.png", "sameAs": list(SOCIAL.values()),
       "description": "Fitness brand by Dan, based in Auckland, New Zealand: simple fat-loss tips, free workouts and high-protein recipes for busy people everywhere.",
       "areaServed": "Worldwide"}

NOINDEX = set()
_EXD = os.path.join(os.path.dirname(os.path.abspath(__file__)), "exercises")
EXDATA = json.load(open(os.path.join(_EXD, "exercises.json"))) if os.path.exists(os.path.join(_EXD, "exercises.json")) else {}
EXMAP = json.load(open(os.path.join(_EXD, "workout_map.json"))) if os.path.exists(os.path.join(_EXD, "workout_map.json")) else {}
def exslug(i): return re.sub(r"[^a-z0-9]+", "-", i.lower()).strip("-")
def excard(label, reps, i):
    x = EXDATA.get(i)
    if not x or not x["images"]: return ""
    im = f'<img src="/exercises/{i}_s.webp" alt="{E(x["name"])} animated demonstration" width="360" height="240" loading="lazy">'
    return (f'<a class="excard" href="/exercises/{exslug(i)}/"><div class="exfig">{im}</div><b>{E(label)}</b><span class="n">{E(reps)}</span>'
            f'<small>{E(", ".join(x.get("primaryMuscles") or []).title())}</small></a>')
GTM_HEAD = "<!-- Google Tag Manager --><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-M8GZF559');</script><!-- End Google Tag Manager -->"
GTM_BODY = '<!-- Google Tag Manager (noscript) --><noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M8GZF559" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><!-- End Google Tag Manager (noscript) -->'
GA_HEAD = '<script async src="https://www.googletagmanager.com/gtag/js?id=G-HJ2G3PT8JT"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag(\'js\',new Date());gtag(\'config\',\'G-HJ2G3PT8JT\');document.addEventListener(\'click\',function(e){var a=e.target.closest&&e.target.closest(\'a,button\');if(!a)return;var h=a.getAttribute(\'href\')||\'\';if(/\\/go\\//.test(h)||/sponsored/.test(a.getAttribute(\'rel\')||\'\')){gtag(\'event\',\'affiliate_click\',{link_url:h,product:(h.match(/\\/go\\/([^/?]+)/)||[])[1]||\'\',page:location.pathname});}else if(/sub_confirmation/.test(h)||(a.classList&&a.classList.contains(\'ytb\'))){gtag(\'event\',\'youtube_subscribe_click\',{source:a.classList.contains(\'ytb\')?\'popup\':\'link\',page:location.pathname});}else if(/(youtube|instagram|facebook|tiktok|pinterest)\\.com/.test(h)){gtag(\'event\',\'social_follow\',{platform:(h.match(/(youtube|instagram|facebook|tiktok|pinterest)/)||[])[1],page:location.pathname});}else if(/print\\(/.test(a.getAttribute(\'onclick\')||\'\')){gtag(\'event\',\'print_plan\',{page:location.pathname});}else if(a.tagName===\'BUTTON\'&&location.pathname.indexOf(\'/ask/\')===0&&(a.classList.contains(\'go\')||a.closest(\'.chips\'))){gtag(\'event\',\'ask_dan_question\',{suggested:a.closest(\'.chips\')?\'yes\':\'no\'});}else if(a.tagName===\'BUTTON\'&&a.classList.contains(\'go\')&&location.pathname.indexOf(\'/tools/\')===0){gtag(\'event\',\'calculator_use\',{calculator:location.pathname});}else if(a.classList&&a.classList.contains(\'sgbtn\')){}},true);</script>'
KIT_FORM = "https://app.kit.com/forms/10155103/subscriptions"
def SIGNUP(where, h="Get your free personalised 7-day plan", p="Your calories and protein, meals you'll actually eat (everyday, desi or vegetarian) and gym or home workouts, built from your details in 60 seconds. Free, sent to your inbox."):
    return (f'<div class="signup" id="get-plan"><div class="sgtxt"><b class="sgk">FREE PLAN</b><h2>{h}</h2><p>{p}</p></div>'
            f'<a class="sgbtn" href="/free/" onclick="try{{gtag(\'event\',\'free_plan_cta\',{{cta_location:\'{where}\'}})}}catch(e){{}}">Build my free plan →</a></div>')

def page(path, title, desc, body, schema=None, kind="website", og_path=None):
    # SEO length guards (8 Nov 2026): titles <=65, descriptions <=160 in search results
    if len(title) > 65 and title.endswith(" | danfitnz"): title = title[:-11]
    if len(desc) > 160:
        cut = desc[:158]; dot = cut.rfind(". ")
        desc = cut[:dot + 1] if dot >= 100 else cut.rsplit(" ", 1)[0].rstrip(",;:—-") + "…"
    url = f"{BASE}/{path}" if path else BASE + "/"
    if not og_path:
        og_path = f"og/{slugify(path) or 'home'}.png"; og_image(f"{OUT}/{og_path}", title.split(" | ")[0])
    graph = [ORG] + (schema or [])
    head = f"""<!doctype html><html lang="en-NZ"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
{GTM_HEAD}<title>{E(title)}</title><meta name="description" content="{E(desc)}"><link rel="canonical" href="{url}">
<meta name="robots" content="{"noindex,follow" if path in NOINDEX else "index,follow,max-image-preview:large"}"><meta name="msvalidate.01" content="564D4B6D7D64D5B6BE5348D73C00EC7C"><meta name="commission-factory-verification" content="0e0814f36fc445bc8e71dd266ebdb917"><meta name="p:domain_verify" content="47eea5363fdf8231be06285ef9956f62"/>{GA_HEAD}
<meta property="og:type" content="{kind}"><meta property="og:title" content="{E(title)}"><meta property="og:description" content="{E(desc)}"><meta property="og:url" content="{url}"><meta property="og:image" content="{BASE}/{og_path}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:locale" content="en_NZ"><meta property="og:site_name" content="danfitnz"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:image" content="{BASE}/{og_path}"><link rel="alternate" type="application/rss+xml" title="danfitnz blog" href="{BASE}/feed.xml"><link rel="alternate" hreflang="en-nz" href="{url}">{ADS_HEAD}
<link rel="icon" href="/favicon.ico" sizes="48x48"><link rel="icon" href="/favicon-192.png" type="image/png" sizes="192x192"><link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="apple-touch-icon" href="/apple-touch-icon.png"><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>{CSS}</style>
<script type="application/ld+json">{json.dumps({"@context": "https://schema.org", "@graph": graph}, ensure_ascii=False)}</script></head><body class="{'ads-on' if CFG['ads']['enabled'] else ''}">{GTM_BODY}
<header class="site"><div class="wrap"><a class="brand" href="/">{LOGO}danfitnz</a><form class="hsform" action="/search/" role="search"><input name="q" type="search" placeholder="Search workouts, recipes…" aria-label="Search danfitnz"></form><a class="hsearch" href="/search/" aria-label="Search">&#128269;</a><button class="menubtn" aria-label="Open menu" aria-expanded="false" onclick="var n=document.getElementById('mainnav');var o=n.classList.toggle('open');this.setAttribute('aria-expanded',o)">&#9776;</button><nav id="mainnav"><a href="/workouts/">Workouts</a><a href="/exercises/">Exercises</a><a href="/recipes/">Recipes</a><a href="/tools/">Free tools</a><a href="/blog/">Guides</a><a href="/fat-loss-tips/">Tips</a><a href="/shop/">Shop</a><a href="/ask/">Ask Dan</a><a class="navsearch" href="/search/">Search</a></nav></div></header>
<main class="wrap">{body}{ad("page-end")}</main>
<a class="totop" id="totop" style="display:none" href="#" aria-label="Back to top" onclick="window.scrollTo(0,0);return false">&#8593;</a><script>addEventListener("scroll",function(){{var t=document.getElementById("totop");if(t)t.style.display=scrollY>700?"flex":"none"}},{{passive:true}})</script><footer><div class="wrap"><div class="fcols"><div><b>Train</b><a href="/workouts/">Workout library</a><a href="/exercises/">Exercise library</a><a href="/workouts/#plans">Weekly plans</a></div><div><b>Eat</b><a href="/free/">Free personalised plan</a><a href="/recipes/">Recipes</a><a href="/tools/plan-builder/">7-day plan builder</a><a href="/tools/calorie-deficit-calculator/">Calorie calculator</a></div><div><b>Learn</b><a href="/blog/">Guides</a><a href="/fat-loss-tips/">Tips &amp; myths</a><a href="/ask/">Ask Dan</a></div><div><b>danfitnz</b><a href="/about/">About Dan</a><a href="/editorial-policy/">Editorial policy</a><a href="/affiliate-disclosure/">Affiliate disclosure</a><a href="/search/">Search</a></div></div>© 2026 danfitnz · Made in Auckland, New Zealand · <a href="/feed.xml">RSS</a><br><span class="social" style="margin:10px 0;display:flex">{" ".join(f'<a href="{u}" rel="me" class="{"yt" if k=="YouTube" else ""}">{k}</a>' for k, u in SOCIAL.items())}</span>As an Amazon Associate, danfitnz earns from qualifying purchases. General fitness and nutrition information only, not medical advice. Check with your GP before starting a new diet or exercise plan, especially if you have a health condition.</div></footer>
</body></html>"""
    d = os.path.join(OUT, path)
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "index.html"), "w").write(head)
    return url

ADC = CFG["ads"].get("adsense_client", "")
ADS_HEAD = f'<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ADC}" crossorigin="anonymous"></script>' if CFG["ads"]["enabled"] and ADC else ""
def ad(slot):
    inner = f'<ins class="adsbygoogle" style="display:block" data-ad-client="{ADC}" data-ad-format="auto" data-full-width-responsive="true"></ins><script>(adsbygoogle=window.adsbygoogle||[]).push({{}});</script>' if CFG["ads"]["enabled"] and ADC else ""
    return f'<div class="ad-slot" data-slot="{slot}">{inner}</div>'
def follow_box():
    links = " ".join(f'<a href="{u}{"?sub_confirmation=1" if k=="YouTube" else ""}" rel="me" class="{"yt" if k=="YouTube" else ""}">{"Subscribe on YouTube" if k=="YouTube" else "Follow on " + k}</a>' for k, u in SOCIAL.items())
    return f'<div class="card"><b>New fat-loss tips every day. Follow danfitnz everywhere:</b><div class="social" style="margin-top:10px">{links}</div></div>'

def bc(items):
    return {"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": n, "item": u} for i, (n, u) in enumerate(items)]}

HUB = {"meal": ("recipes", "High-Protein Recipes"), "workout": ("workouts", "Workouts"),
       "tips": ("fat-loss-tips", "Fat Loss Tips"), "myth": ("fat-loss-tips", "Fat Loss Tips")}
SEO = {
 "3-fat-loss-myths": "3 Fat Loss Myths That Keep You Stuck (and What Actually Works)",
 "3-gym-myths-beginners-believe": "3 Gym Myths Beginners Believe (Busted)",
 "3-cardio-myths": "3 Cardio Myths: You Don't Need Hours on the Treadmill",
 "3-food-myths": "3 Food Myths That Make Dieting Harder",
 "3-supplement-myths": "3 Supplement Myths That Waste Your Money",
 "3-progress-myths": "3 Progress Myths That Make People Quit",
 "5-easy-ways-to-eat-more-protein": "5 Easy Ways to Eat More Protein (Without Shakes)",
 "why-your-weight-jumped-overnight": "Why Your Weight Jumped Overnight (It's Not Fat)",
 "how-to-find-your-calorie-deficit": "How to Find Your Calorie Deficit: The Simple Way",
 "4-ways-to-walk-more-without-trying": "4 Easy Ways to Walk More Steps Every Day",
 "stop-doing-this-in-the-gym": "Gym Mistakes That Kill Your Progress",
 "what-25-30g-protein-looks-like": "What 25–30g of Protein Looks Like in Real Food",
 "fat-loss-stalled-check-these-4": "Fat Loss Stalled? Check These 4 Things First",
 "sleep-better-lose-fat-easier": "Sleep Better, Lose Fat Easier: The Skipped Fat-Loss Habit",
 "smarter-takeaway-picks": "Smarter Takeaway Picks for Fat Loss",
 "if-i-started-from-zero-again": "Starting Your Fitness Journey? What I'd Do From Zero",
 "20-min-home-fat-burner": "20-Minute Home Fat Burner Workout (No Equipment)",
 "beginner-dumbbell-full-body": "Beginner Dumbbell Full Body Workout (30 Minutes)",
 "10-min-desk-worker-reset": "10-Minute Desk Worker Reset Workout",
 "leg-day-for-beginners": "Leg Day for Beginners: 40-Minute Gym Workout",
 "push-day-workout": "Push Day Workout: Chest, Shoulders and Triceps",
 "pull-day-workout": "Pull Day Workout: Back and Biceps",
 "core-workout-no-crunches": "10-Minute Core Workout With No Crunches",
}
pages = []

for i, r in enumerate(REELS):
    t = r["type"]
    if t not in HUB: continue
    raw = " ".join(r["title"])
    hub, hubname = HUB[t]
    hook = clean(r["hook"])
    if hook and hook[-1] not in ".!?": hook += "."
    if t == "meal":
        kcal, prot = r["macros"]; kc = re.sub(r"\D", "", kcal); pg = re.sub(r"\D", "", prot)
        name = tcase(raw)
        title = f"{name} Recipe ({prot} Protein, {kcal} kcal) | danfitnz"
        desc = f"{hook} Easy {name.lower()} recipe for fat loss: about {kc} kcal and {pg}g protein {r['serves'].split('·')[0].strip()}. Simple ingredients, step-by-step method."
        slug = slugify(name)
        ing = "".join(f"<li>{E(x)}</li>" for x in r["ingredients"])
        steps = "".join(f'<li id="step-{k+1}">{E(x)}</li>' for k, x in enumerate(r["steps"]))
        _nl = name.lower(); _no_cook = any(w in _nl for w in ("lassi", "overnight", "smoothie", "shake"))
        prep_m = r.get("prep_min", 5 if _no_cook else 10); cook_m = r.get("cook_min", 0 if _no_cook else 20)
        rurl = f"{BASE}/{hub}/{slug}/"; rimg = f"{BASE}/og/{slugify(hub + '/' + slug + '/')}.png"
        body = f"""<p class="meta"><a href="/{hub}/">{hubname}</a></p><h1>{E(name)}</h1><p class="lead">{E(hook)} A high-protein, lower-calorie recipe that fits a fat-loss diet.</p>
<div class="macros"><div class="macro"><b>{E(kcal)}</b><span>CALORIES</span></div><div class="macro lime"><b>{E(prot)}</b><span>PROTEIN</span></div></div><p class="meta">{E(r['serves'])} · Prep about {prep_m} min{(" · Cook about " + str(cook_m) + " min") if cook_m else ""} · nutrition and times are approximate</p>
<h2>Ingredients</h2><ul>{ing}</ul><h2>Method</h2><ol>{steps}</ol>
<h2>Why it works for fat loss</h2><p>Protein keeps you full for longer and helps you hold on to muscle while you're in a calorie deficit. This recipe gets you about {pg}g of protein for roughly {kc} calories, so you can enjoy great flavour while losing fat. Serve it with salad or a small portion of rice or roti to fit your daily calories.</p>
{follow_box()}"""
        sch = [{"@type": "Recipe", "name": name, "description": desc, "author": {"@id": BASE + "/#org"}, "datePublished": TODAY,
                "image": [rimg], "url": rurl, "prepTime": f"PT{prep_m}M", "cookTime": f"PT{cook_m}M", "totalTime": f"PT{prep_m + cook_m}M", "recipeCuisine": r.get("cuisine_label", "Pakistani / Indian"), "recipeCategory": "Main course",
                "keywords": f"high protein, fat loss, {r.get('cuisine', 'desi')}, {name.lower()}", "recipeYield": r["serves"].split("serves")[-1].strip() + " servings" if "serves" in r["serves"] else "1 serving",
                "nutrition": {"@type": "NutritionInformation", "calories": f"{kc} calories", "proteinContent": f"{pg} g"},
                "recipeIngredient": r["ingredients"], "recipeInstructions": [{"@type": "HowToStep", "name": f"Step {k+1}", "text": x, "url": f"{rurl}#step-{k+1}", "image": rimg} for k, x in enumerate(r["steps"])]}]
    elif t == "workout":
        name = tcase(raw); sub = clean(r["sub"]); slug = slugify(name); name = SEO.get(slug, name)
        title = f"{name} | danfitnz"
        desc = f"{hook} {name} ({sub}): exercises, sets and reps, plus how to progress. Beginner friendly."
        rows = "".join(f"<tr><td>{E(a)}</td><td class='n'>{E(b)}</td></tr>" for a, b in r["items"])
        body = f"""<p class="meta"><a href="/{hub}/">{hubname}</a></p><h1>{E(name)}</h1><p class="lead">{E(hook)} <span class="tag">{E(sub)}</span></p>
<h2>The workout</h2><table><tr><th>Exercise</th><th>Sets / reps</th></tr>{rows}</table><p><b>{E(clean(r['footer']))}</b></p>
{('<h2>See each exercise</h2><div class="exgrid">' + "".join(excard(a, b, EXMAP.get(a, "")) for a, b in r["items"]) + '</div><p class="meta">Tap an exercise for step-by-step instructions. Animations from real photos: free-exercise-db (public domain).</p>') if any(EXMAP.get(a) for a, b in r["items"]) else ""}
<h2>How to do it</h2><ol><li>Warm up for 5 minutes: brisk walk, arm circles and a few bodyweight squats.</li><li>Do the exercises in order with good form. Slow down rather than rushing reps.</li><li>Rest as listed, then repeat for the number of rounds or sets shown.</li><li>Progress each week by adding one rep, a little weight, or one extra round.</li></ol>
<p class="note">Stop if anything hurts (not the same as feeling the burn). Pair this workout with a small calorie deficit and enough protein for fat loss.</p>
{follow_box()}"""
        sch = [{"@type": "HowTo", "name": name, "description": desc, "totalTime": None,
                "step": [{"@type": "HowToStep", "name": a, "text": f"{a}: {b}"} for a, b in r["items"]]}]
        sch[0].pop("totalTime")
    elif t == "myth":
        name = tcase(raw); sub = clean(r.get("sub", "")); slug = slugify(name); name = SEO.get(slug, name)
        title = f"{name} | danfitnz"
        desc = f"{hook} {name}, and what actually works for fat loss instead."
        secs = "".join(f"<h2>Myth {k + 1}: {E(m)}</h2><p><span class='fact'>THE FACT</span><br>{E(f)}</p>" for k, (m, f) in enumerate(r["items"]))
        body = f"""<p class="meta"><a href="/{hub}/">{hubname}</a></p><h1>{E(name)}</h1><p class="lead">{E(hook)}</p>{secs}
<h2>The bottom line</h2><p>Fat loss comes down to a consistent calorie deficit, enough protein, strength training and good sleep. Ignore the shortcuts and stick to the basics for 8–12 weeks.</p>{follow_box()}"""
        sch = [{"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": f"Is it true that {m[0].lower() + m[1:]}?",
                 "acceptedAnswer": {"@type": "Answer", "text": f"No. {f}"}} for m, f in r["items"]]}]
    else:  # tips
        name = tcase(raw); sub = clean(r.get("sub", "")); slug = slugify(name); name = SEO.get(slug, name)
        title = f"{name} | danfitnz"
        desc = f"{hook} {name}: {sub}. Simple, practical fat-loss advice from danfitnz."
        secs = "".join(f"<h2>{k + 1}. {E(a)}</h2><p>{E(b)}</p>" for k, (a, b) in enumerate(r["items"]))
        body = f"""<p class="meta"><a href="/{hub}/">{hubname}</a></p><h1>{E(name)}</h1><p class="lead">{E(hook)} <span class="tag">{E(sub)}</span></p>{secs}{follow_box()}"""
        sch = [{"@type": "Article", "headline": name, "description": desc, "author": {"@id": BASE + "/#org"}, "publisher": {"@id": BASE + "/#org"}, "datePublished": TODAY}]
    path = f"{hub}/{slug}/"
    sch.append(bc([("Home", BASE + "/"), (hubname, f"{BASE}/{hub}/"), (name, f"{BASE}/{path}")]))
    page(path, title, desc[:158], body, sch, "article")
    pages.append(dict(path=path, name=name, hub=hub, desc=desc, type=t))

# hubs
HUBS = {"recipes": ("High-Protein Recipes for Fat Loss", "Easy high-protein meals with calories and protein for every serve: everyday meals, quick meal prep and flavours from around the world, from Mediterranean and Asian to desi favourites."),
        "workouts": ("Beginner Workouts for Fat Loss", "Simple home and gym workouts for beginners: full body, push, pull, legs and core, with sets and reps."),
        "fat-loss-tips": ("Fat Loss Tips and Myths", "Practical fat-loss tips and common diet and gym myths busted: protein, calorie deficit, cardio, sleep and more.")}
for h, (hn, hd) in HUBS.items():
    items = [p for p in pages if p["hub"] == h]
    grid = "".join(f'<a href="/{p["path"]}">{E(p["name"])}<small>{E(clean(p["desc"])[:90])}…</small></a>' for p in items)
    sch = [{"@type": "CollectionPage", "name": hn, "description": hd, "url": f"{BASE}/{h}/"},
           {"@type": "ItemList", "itemListElement": [{"@type": "ListItem", "position": k + 1, "url": f"{BASE}/{p['path']}", "name": p["name"]} for k, p in enumerate(items)]},
           bc([("Home", BASE + "/"), (hn, f"{BASE}/{h}/")])]
    page(f"{h}/", f"{hn} | danfitnz", hd, f"<h1>{E(hn)}</h1><p class='lead'>{E(hd)}</p><div class='grid'>{grid}</div>{follow_box()}", sch)

exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "extra.py")).read())
# home
latest = "".join(f'<a href="/{p["path"]}">{E(p["name"])}<small>{E(HUBS[p["hub"]][0])}</small></a>' for p in pages[:6])
home_body = f"""<div class="hero"><div><h1>Lose fat without extreme diets.</h1><p class="lead">Free workouts, simple meal plans and honest guides from Dan — who lost 20 kg (44 lb) in 5 months while working full-time. Built for busy people, anywhere in the world.</p>
<div class="ctas"><a class="cta" href="/tools/plan-builder/">Build my free 7-day plan</a><a class="cta ghost" href="/workouts/">Find a workout</a></div>
<div class="trust"><span><b>130+</b> free workouts</span><span><b>870+</b> exercise demos</span><span><b>Free</b> calculators</span><span>No sign-up needed</span></div></div>
<a href="/blog/how-i-lost-20kg-in-5-months/"><img src="/media/dan-before-after.jpg" width="1080" height="1350" alt="Dan's before and after: 93 kg to about 73 kg in 5 months" loading="eager"></a></div>
<h2>What do you want to do?</h2><div class="goals">
<a href="/blog/category/fat-loss/"><span>🔥</span>Lose fat<small>Calorie deficit, 16:8 fasting, meal plans</small></a>
<a href="/workouts/#full-body"><span>🏋️</span>Build muscle<small>Gym &amp; home workouts with demos</small></a>
<a href="/recipes/"><span>🥗</span>Eat better<small>High-protein recipes with calories</small></a>
<a href="/blog/beginner-gym-plan-first-8-weeks/"><span>🚀</span>Just starting<small>Your first 8 weeks, step by step</small></a></div>
<h2>Free tools</h2><div class="grid"><a href="/tools/plan-builder/">7-day plan builder<small>Your calories, protein, meals and workouts in 1 minute.</small></a><a href="/tools/calorie-deficit-calculator/">Calorie calculator<small>Maintenance and fat-loss calories (kg or lb).</small></a><a href="/tools/protein-calculator/">Protein calculator<small>How much protein you need per day and per meal.</small></a></div>
<h2>Latest guides</h2><div class="grid">{"".join(f'<a href="/{b["path"]}">{E(b["name"])}<small>{E(CFG["categories"].get(b["cat"], ""))}</small></a>' for b in BLOG_LIST[:6])}</div><p><a href="/blog/">All guides →</a></p>
<h2>Popular workouts</h2><div class="grid"><a href="/workouts/3-day-gym-full-body-plan-beginner/">3-day gym plan for beginners<small>Full body, every exercise demonstrated.</small></a><a href="/workouts/bodyweight-full-body-workout-beginner/">No-equipment home workout<small>Do it in your living room.</small></a><a href="/workouts/hiit-fat-burning-workout-beginner/">20-minute HIIT<small>Fast fat-burning circuit.</small></a></div><p><a href="/workouts/">All 130+ workouts →</a></p>{SIGNUP("home")}
<h2>Quick tips</h2><div class="grid">{latest}</div>
<h2>What danfitnz believes</h2><p>Fat loss doesn't need extreme diets. Eat in a small calorie deficit, get enough protein, lift weights, walk more and sleep well, then repeat for months. Discipline beats motivation.</p>{follow_box()}"""
page("", "danfitnz: Fat Loss Tips, Free Workouts & High-Protein Recipes",
     "Short, simple fitness for busy people everywhere: fat-loss tips, myths busted, beginner workouts and high-protein recipes with calories and protein.",
     home_body, [{"@type": "WebSite", "@id": BASE + "/#site", "name": "danfitnz", "url": BASE + "/", "publisher": {"@id": BASE + "/#org"}, "inLanguage": "en", "potentialAction": {"@type": "SearchAction", "target": BASE + "/search/?q={search_term_string}", "query-input": "required name=search_term_string"}}])

about = f"""<h1>About danfitnz</h1><p class="lead">danfitnz is a fitness brand from Auckland, New Zealand, built to make fat loss simple.</p>
<figure><img src="/media/dan-before-after.jpg" width="1080" height="1350" alt="Dan from danfitnz before and after losing 20 kg: 93 kg to about 73 kg in 5 months" loading="lazy" style="max-width:480px;width:100%;height:auto;border-radius:16px"><figcaption>Dan: 93 kg → about 73 kg in 5 months</figcaption></figure>
<h2>Who's behind danfitnz</h2><p>I'm Dan. Fitness is my passion, but I still ended up at 93 kg working a full-time job. I lost about 20 kg in 5 months with 16:8 intermittent fasting, around 1,800 calories and 130 g of protein a day, training late at night after work. My first month I cut everything and stalled — what worked was structure and real numbers. <a href="/blog/how-i-lost-20kg-in-5-months/">Read the full story →</a></p>
<p>We make short videos and simple guides that help everyday people lose fat without extreme diets: practical tips, the most common myths busted, beginner-friendly workouts, and high-protein recipes that fit a fat-loss plan, with flavours from around the world: everyday Western meals, Mediterranean, Asian, Middle Eastern and desi dishes.</p>
<h2>Our approach</h2><ul><li>A small, sustainable calorie deficit</li><li>Enough protein at every meal</li><li>Strength training 3–4 times a week</li><li>Daily steps and good sleep</li><li>Consistency and discipline over motivation</li></ul>
<h2>Where to watch</h2><p>New videos every day on {", ".join(f'<a href="{u}">{k}</a>' for k, u in SOCIAL.items())}.</p>
<p class="note">Content is general information, not medical advice. Nutrition values are approximate.</p>"""
page("editorial-policy/", "Editorial Policy: How danfitnz Writes and Checks Content", "How danfitnz researches, writes, fact-checks and updates its fitness and nutrition content — and what we will never do.",
     """<h1>Editorial policy</h1><p class="lead">How we research, write, check and update everything on danfitnz.</p>
<h2>Who writes it</h2><p>danfitnz is run by Dan, who lost about 20 kg in 5 months with 16:8 intermittent fasting while working full-time. Dan is not a doctor or dietitian. Content is written from lived experience plus published research, and we say clearly which is which.</p>
<h2>How we research</h2><ul><li>Health and nutrition claims are checked against peer-reviewed studies, systematic reviews or official guidance (e.g. NZ Ministry of Health, WHO), and linked in a numbered Sources list.</li><li>When the evidence is weak or mixed, we say so.</li><li>Numbers (calories, protein, sets and reps) are rounded and given as ranges, not promises.</li></ul>
<h2>How we keep it current</h2><p>Every guide shows its last-updated date. We review core guides at least every 6 months and fix errors as soon as we find them. Spotted a mistake? Message us on Instagram or Facebook.</p>
<h2>What we will never do</h2><ul><li>Promise rapid or guaranteed weight loss, or recommend crash diets.</li><li>Publish fake reviews, testimonials or before/after photos.</li><li>Recommend a product we wouldn't use ourselves. Affiliate links are always labelled — see our <a href="/affiliate-disclosure/">affiliate disclosure</a>.</li></ul>
<h2>Medical note</h2><p>Our content is general information, not medical advice. If you are pregnant, under 18, have a medical condition or take medication, talk to your GP before changing your diet or training.</p>""", [bc([("Home", BASE + "/"), ("Editorial policy", f"{BASE}/editorial-policy/")])])
EXTRA_URLS.append("editorial-policy/")
NOINDEX.add("free/thanks/")
page("free/thanks/", "Check Your Email | danfitnz", "Confirm your email to download the free 7-Day Fat Loss Kickstart.",
     """<h1>Nearly there: check your email 📩</h1><p class="lead">I've just sent you an email. Tap <b>“Confirm &amp; download my free plan”</b> in it and the PDF downloads straight away.</p>
<ul class="check"><li>Not there in 2 minutes? Check spam or the Promotions tab and move it to your inbox.</li><li>Used the wrong email? <a href="/free/">Sign up again</a>.</li></ul>
<h2>While you wait</h2><div class="grid"><a href="/tools/calorie-deficit-calculator/">Find your calorie target<small>Free calculator, kg or lb.</small></a><a href="/workouts/bodyweight-full-body-workout-beginner/">Try a home workout<small>No equipment needed.</small></a><a href="/blog/">Read the guides<small>Fat loss, protein, discipline.</small></a></div>""")

page("about/", "About danfitnz", "danfitnz is a fitness brand by Dan, based in Auckland, New Zealand, sharing fat-loss tips, free workouts and high-protein recipes for people everywhere.", about,
     [{"@type": "AboutPage", "name": "About danfitnz", "url": BASE + "/about/"}])

# static files
# square favicons (Google needs 1:1, multiple of 48px) + site media
def _fav(n):
    from PIL import Image as _I
    ic = _I.open(os.path.join(HERE, "icon.png")).convert("RGBA"); c = _I.new("RGBA", (n, n), (14, 15, 18, 255))
    s = int(n * 0.78); ic.thumbnail((s, s), _I.LANCZOS); c.alpha_composite(ic, ((n - ic.width) // 2, (n - ic.height) // 2)); return c
_fav(48).save(f"{OUT}/favicon.ico", sizes=[(16, 16), (32, 32), (48, 48)])
for _n, _f in [(48, "favicon-48.png"), (96, "favicon-96.png"), (192, "favicon-192.png"), (180, "apple-touch-icon.png"), (512, "favicon-512.png")]: _fav(_n).convert("RGB").save(f"{OUT}/{_f}")
import shutil as _sh2
if os.path.isdir(os.path.join(HERE, "media")):
    os.makedirs(f"{OUT}/media", exist_ok=True)
    for _m in os.listdir(os.path.join(HERE, "media")): _sh2.copy(os.path.join(HERE, "media", _m), f"{OUT}/media/{_m}")
open(f"{OUT}/favicon.svg", "w").write(LOGO.replace(' aria-hidden="true"', ' xmlns="http://www.w3.org/2000/svg"'))
src_icon = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.png")
if os.path.exists(src_icon): shutil.copy(src_icon, f"{OUT}/logo.png")
open(f"{OUT}/.nojekyll", "w").write("")
open(f"{OUT}/{CFG['indexnow_key']}.txt", "w").write(CFG["indexnow_key"])
open(f"{OUT}/today_urls.txt", "w").write("\n".join(u for u in TODAY_POSTS if not any(u.rstrip("/").endswith(n.rstrip("/")) for n in NOINDEX)))
for v in ["google2057ddd5757c6f24.html"]:  # Google Search Console verification
    open(f"{OUT}/{v}", "w").write(f"google-site-verification: {v}")
open(f"{OUT}/404.html", "w").write(f'<!doctype html><meta charset="utf-8">'+GTM_HEAD+'<title>Not found | danfitnz</title><meta name="viewport" content="width=device-width,initial-scale=1"><body style="background:#0E0F12;color:#F5F5F5;font-family:system-ui;padding:40px">'+GTM_BODY+'<h1>Page not found</h1><p><a style="color:#C6FF3D" href="/">Go to danfitnz home</a></p></body>')
# site search: index every page title/description (users can find anything)
_idx = []
for _root, _dirs, _files in os.walk(OUT):
    if "index.html" not in _files: continue
    _rel = os.path.relpath(_root, OUT).replace(os.sep, "/")
    if _rel == "." or _rel.split("/")[0] in ("go", "embed", "pins", "search", "og", "media"): continue
    _h = open(os.path.join(_root, "index.html")).read(4000)
    _t = re.search(r"<title>(.*?)</title>", _h); _d = re.search(r'name="description" content="(.*?)"', _h)
    if not _t: continue
    _idx.append([html.unescape(_t.group(1)).replace(" | danfitnz", ""), "/" + _rel + "/", html.unescape(_d.group(1))[:90] if _d else "", _rel.split("/")[0]])
open(f"{OUT}/search.json", "w").write(json.dumps(_idx, separators=(",", ":")))
page("search/", "Search danfitnz", "Search workouts, exercises, recipes, tools and guides on danfitnz.",
     """<h1>Search</h1><input id="sq" type="search" placeholder="Try: squat, 16:8, protein, chest workout, keema" autofocus style="width:100%;padding:14px 16px;border-radius:14px;border:1px solid #333;background:#16181d;color:#f5f5f5;font-size:17px"><p id="sc" class="meta"></p><div id="sr" class="grid"></div>
<script>var IDX=[],L={workouts:'Workout',exercises:'Exercise',recipes:'Recipe',blog:'Guide',tools:'Tool','fat-loss-tips':'Tip',shop:'Shop'};
fetch('/search.json').then(r=>r.json()).then(d=>{IDX=d;var q=new URLSearchParams(location.search).get('q');if(q){sq.value=q;run()}});
function run(){var q=sq.value.toLowerCase().trim().split(/\s+/).filter(Boolean);if(!q.length){sr.innerHTML='';sc.textContent='';return}
var res=IDX.map(e=>{var t=e[0].toLowerCase(),s=0;for(var w of q){if(t.indexOf(w)>=0)s+=3;else if((e[2]||'').toLowerCase().indexOf(w)>=0)s+=1;else return null}return [s,e]}).filter(Boolean).sort((a,b)=>b[0]-a[0]).slice(0,40);
sc.textContent=res.length+' results';sr.innerHTML=res.map(r=>'<a href="'+r[1][1]+'">'+r[1][0].replace(/[<>&]/g,'')+'<small>'+(L[r[1][3]]||'Page')+' · '+(r[1][2]||'').replace(/[<>&]/g,'')+'</small></a>').join('')}
sq.addEventListener('input',run);</script>""", [])
NOINDEX.add("search/")
# thin-page guard: anything indexable with under 250 words of real text gets noindex,follow (stays on site, out of Google)
def _thin(u):
    f = os.path.join(OUT, u, "index.html")
    if not u or not u.startswith("fat-loss-tips/") or not os.path.exists(f): return False  # only the short video-tip pages
    h = open(f).read()
    if "noindex" in h: return False
    m = re.search(r"<main.*?</main>", h, re.S) or re.search(r"<body.*</body>", h, re.S)
    t = re.sub(r"<[^>]+>", " ", re.sub(r"<(script|style)[^>]*>.*?</\1>", "", m.group(0) if m else h, flags=re.S))
    if len(t.split()) >= 250: return False
    open(f, "w").write(h.replace('content="index,follow,max-image-preview:large"', 'content="noindex,follow"')); return True
for _u in list(dict.fromkeys([*EXTRA_URLS, *[p["path"] for p in pages]])):
    if _u not in NOINDEX and _thin(_u): NOINDEX.add(_u)
urls = ["", "about/", *EXTRA_URLS, *[f"{h}/" for h in HUBS], *[p["path"] for p in pages]]
urls = [u for u in dict.fromkeys(urls) if u not in NOINDEX]
open(f"{OUT}/sitemap.xml", "w").write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
    "".join(f"<url><loc>{BASE}/{u}</loc><lastmod>{TODAY}</lastmod></url>\n" for u in urls) + "</urlset>\n")
bots = ["Googlebot", "Bingbot", "GPTBot", "OAI-SearchBot", "ChatGPT-User", "PerplexityBot", "ClaudeBot", "Claude-SearchBot", "Google-Extended", "Applebot", "Applebot-Extended", "CCBot", "DuckDuckBot"]
open(f"{OUT}/robots.txt", "w").write("".join(f"User-agent: {b}\nAllow: /\n\n" for b in bots) + f"User-agent: *\nAllow: /\n\nSitemap: {BASE}/sitemap.xml\n")
llms = [f"# danfitnz\n\n> Fitness brand from Auckland, New Zealand. Short daily videos and simple guides: fat-loss tips, myths busted, beginner workouts and high-protein recipes (global flavours including desi favourites) with calories and protein per serve. New video every day at 6:30pm NZ time.\n",
        "Core advice: small calorie deficit, enough protein, strength training 3–4x/week, daily steps, good sleep, consistency. Content is general information, not medical advice.\n",
        "## Channels\n" + "".join(f"- [{k}]({u})\n" for k, u in SOCIAL.items())]
for h, (hn, hd) in HUBS.items():
    llms.append(f"\n## {hn}\n" + "".join(f"- [{p['name']}]({BASE}/{p['path']}): {clean(p['desc'])[:140]}\n" for p in pages if p["hub"] == h))
llms.append("\n## Free tools\n" + "".join(f"- [{t['name']}]({BASE}/{t['path']}): {t['desc']}\n" for t in TOOLS_LIST) + f"- [Ask danfitnz]({BASE}/ask/): instant answers from danfitnz guides\n")
llms.append("\n## Blog\n" + "".join(f"- [{b['name']}]({BASE}/{b['path']}): {b['desc']}\n" for b in BLOG_LIST))
open(f"{OUT}/llms.txt", "w").write("".join(llms))
print(len(pages), "articles;", len(urls), "urls ->", OUT)

# rewrite root-relative links for project-site hosting (e.g. /danfitnz/)
if PREFIX:
    for root, _, files in os.walk(OUT):
        for f in files:
            if f.endswith(".html"):
                fp = os.path.join(root, f); h = open(fp).read()
                h = re.sub(r'(href|src)="/(?!/)', lambda m: f'{m.group(1)}="{PREFIX}/', h)
                open(fp, "w").write(h)
