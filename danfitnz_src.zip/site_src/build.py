"""Build the danfitnz static website (SEO + AI-engine friendly) from the Reel content."""
import os, re, json, sys, html, shutil, datetime
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
CFG = json.load(open(os.path.join(HERE, "config.json")))
from content import REELS

BASE = os.environ.get("SITE_BASE", "https://danfitnz.github.io").rstrip("/")
OUT = os.environ.get("SITE_OUT", os.path.join(HERE, "..", "build", "site"))
PREFIX = os.environ.get("SITE_PREFIX", "").rstrip("/")
from zoneinfo import ZoneInfo
TODAY = os.environ.get("SITE_TODAY") or datetime.datetime.now(ZoneInfo("Pacific/Auckland")).date().isoformat()
YT = "https://www.youtube.com/channel/UCOWbB203EHcPglSFcwW2j3g"
SOCIAL = CFG["social"]
from graphics import og_image
E = html.escape
EMOJI = re.compile("[\U0001F000-\U0001FAFF☀-➿️‍]+")

def clean(s): return EMOJI.sub("", s).replace("  ", " ").strip()
SMALL = {"a", "an", "and", "the", "to", "of", "in", "on", "for", "with", "you", "your", "this", "that", "these", "at", "or"}
def tcase(s):
    out = []
    for i, w in enumerate(s.lower().split()):
        if i and w in SMALL: out.append(w); continue
        out.append("-".join(p[:1].upper() + p[1:] for p in w.split("-")))
    t = " ".join(out)
    return re.sub(r"(\d)G\b", r"\1g", t).replace("(no", "(No")
def slugify(s): return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")

CSS = """:root{--bg:#0E0F12;--card:#1C1E24;--lime:#C6FF3D;--text:#F5F5F5;--muted:#A0A3AD;--line:#2A2D35}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--text);font:17px/1.65 Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
a{color:var(--lime)}img{max-width:100%}
.wrap{max-width:760px;margin:0 auto;padding:0 18px}
header.site{border-bottom:1px solid var(--line)}header.site .wrap{display:flex;align-items:center;gap:14px;justify-content:space-between;padding:14px 18px;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:10px;color:var(--text);text-decoration:none;font-weight:900;font-size:22px}
.brand svg{width:30px;height:32px}
nav a{color:var(--text);text-decoration:none;margin-left:16px;font-weight:600;font-size:15px}nav a:hover{color:var(--lime)}
h1{font-size:clamp(30px,6vw,44px);line-height:1.1;font-weight:900;margin:34px 0 10px}
h2{font-size:24px;line-height:1.25;margin:34px 0 8px}h3{font-size:19px;margin:22px 0 4px}
.lead{color:var(--muted);font-size:19px;margin:0 0 20px}
.meta{color:var(--muted);font-size:14px}
.card{background:var(--card);border-radius:16px;padding:18px 20px;margin:16px 0}
.macros{display:flex;gap:12px;flex-wrap:wrap}.macro{background:var(--card);border-radius:14px;padding:14px 18px;min-width:140px}
.macro b{display:block;font-size:30px;font-weight:900}.macro.lime b{color:var(--lime)}.macro span{color:var(--muted);font-size:13px;letter-spacing:.06em}
table{width:100%;border-collapse:collapse;margin:12px 0}td,th{border-bottom:1px solid var(--line);padding:10px 6px;text-align:left}th{color:var(--muted);font-weight:600;font-size:14px}
td.n{color:var(--lime);font-weight:800;white-space:nowrap}
.myth{color:#FF6B6B;font-weight:800;letter-spacing:.04em;font-size:13px}.fact{color:var(--lime);font-weight:800;letter-spacing:.04em;font-size:13px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;margin:18px 0}
.grid a{display:block;background:var(--card);border-radius:14px;padding:16px;text-decoration:none;color:var(--text);font-weight:700}
.grid a small{display:block;color:var(--muted);font-weight:500;margin-top:6px}
.cta{background:var(--lime);color:var(--bg);border-radius:999px;padding:12px 20px;font-weight:800;text-decoration:none;display:inline-block;margin:6px 8px 6px 0}
.tag{display:inline-block;background:var(--card);border-radius:999px;padding:3px 10px;font-size:13px;color:var(--muted);margin-right:6px}
.note{color:var(--muted);font-size:14px;border-left:3px solid var(--line);padding-left:12px}
footer{border-top:1px solid var(--line);margin-top:50px;padding:24px 0;color:var(--muted);font-size:14px}
.ad-slot{display:none}.ads-on .ad-slot{display:block;min-height:120px;margin:22px 0;background:#15171c;border-radius:12px;text-align:center}.ads-on .ad-slot:before{content:"Advertisement";display:block;color:#5c5f68;font-size:11px;letter-spacing:.1em;padding-top:6px}
figure{margin:22px 0}figure img{width:100%;height:auto;border-radius:16px;display:block}figcaption{color:var(--muted);font-size:14px;margin-top:6px}
.toc{background:var(--card);border-radius:16px;padding:14px 20px;margin:18px 0}.toc ol{margin:6px 0 0;padding-left:20px}.toc a{color:var(--text);text-decoration:none}.toc a:hover{color:var(--lime)}
.chips2{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 18px}.chip{background:var(--card);border-radius:999px;padding:7px 13px;color:var(--text);text-decoration:none;font-size:14px;font-weight:600}.chip:hover{color:var(--lime)}
.affgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}.aff{display:block;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;text-decoration:none;color:var(--text)}.aff small{display:block;color:var(--muted);margin:4px 0 8px}.aff span{color:var(--lime);font-weight:700;font-size:14px}
.social{display:flex;gap:8px;flex-wrap:wrap}.social a{background:#111318;border:1px solid var(--line);border-radius:999px;padding:9px 14px;color:var(--text);text-decoration:none;font-weight:700;font-size:14px}.social a.yt{background:#FF0033;border-color:#FF0033;color:#fff}
@media(max-width:520px){nav a{margin:0 14px 0 0}header.site .wrap{justify-content:flex-start}}"""

LOGO = '<svg viewBox="0 0 540 580" aria-hidden="true"><path d="M0 0H230C420 0 540 120 540 290C540 460 420 580 230 580H0Z" fill="#C6FF3D"/><path d="M95 440L235 300L310 375L445 240" fill="none" stroke="#0E0F12" stroke-width="58" stroke-linecap="round" stroke-linejoin="round"/><path d="M370 225H460V315" fill="none" stroke="#0E0F12" stroke-width="58" stroke-linecap="round" stroke-linejoin="round"/></svg>'
ORG = {"@type": "Organization", "@id": BASE + "/#org", "name": "danfitnz", "url": BASE + "/",
       "logo": BASE + "/logo.png", "sameAs": list(SOCIAL.values()),
       "description": "Fitness brand from Auckland, New Zealand: simple fat-loss tips, beginner workouts and high-protein recipes, including desi favourites.",
       "areaServed": "New Zealand"}

def page(path, title, desc, body, schema=None, kind="website", og_path=None):
    url = f"{BASE}/{path}" if path else BASE + "/"
    if not og_path:
        og_path = f"og/{slugify(path) or 'home'}.png"; og_image(f"{OUT}/{og_path}", title.split(" | ")[0])
    graph = [ORG] + (schema or [])
    head = f"""<!doctype html><html lang="en-NZ"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{E(title)}</title><meta name="description" content="{E(desc)}"><link rel="canonical" href="{url}">
<meta name="robots" content="index,follow,max-image-preview:large"><meta name="msvalidate.01" content="564D4B6D7D64D5B6BE5348D73C00EC7C">
<meta property="og:type" content="{kind}"><meta property="og:title" content="{E(title)}"><meta property="og:description" content="{E(desc)}"><meta property="og:url" content="{url}"><meta property="og:image" content="{BASE}/{og_path}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:locale" content="en_NZ"><meta property="og:site_name" content="danfitnz"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:image" content="{BASE}/{og_path}"><link rel="alternate" type="application/rss+xml" title="danfitnz blog" href="{BASE}/feed.xml"><link rel="alternate" hreflang="en-nz" href="{url}">{ADS_HEAD}
<link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>{CSS}</style>
<script type="application/ld+json">{json.dumps({"@context": "https://schema.org", "@graph": graph}, ensure_ascii=False)}</script></head><body class="{'ads-on' if CFG['ads']['enabled'] else ''}">
<header class="site"><div class="wrap"><a class="brand" href="/">{LOGO}danfitnz</a><nav><a href="/blog/">Blog</a><a href="/tools/">Tools</a><a href="/recipes/">Recipes</a><a href="/workouts/">Workouts</a><a href="/fat-loss-tips/">Tips</a><a href="/ask/">Ask</a></nav></div></header>
<main class="wrap">{body}{ad("page-end")}</main>
<footer><div class="wrap">© 2026 danfitnz · Auckland, New Zealand · <a href="/about/">About</a> · <a href="/tools/">Free tools</a> · <a href="/affiliate-disclosure/">Affiliate disclosure</a> · <a href="/feed.xml">RSS</a><br><span class="social" style="margin:10px 0;display:flex">{" ".join(f'<a href="{u}" rel="me" class="{"yt" if k=="YouTube" else ""}">{k}</a>' for k, u in SOCIAL.items())}</span>General fitness and nutrition information only, not medical advice. Check with your GP before starting a new diet or exercise plan, especially if you have a health condition.</div></footer>
</body></html>"""
    d = os.path.join(OUT, path)
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "index.html"), "w").write(head)
    return url

ADC = CFG["ads"].get("adsense_client", "")
ADS_HEAD = f'<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ADC}" crossorigin="anonymous"></script>' if CFG["ads"]["enabled"] and ADC else ""
def ad(slot):
    inner = f'<ins class="adsbygoogle" style="display:block" data-ad-client="{ADC}" data-ad-format="auto" data-full-width-responsive="true"></ins><script>(adsbygoogle=window.adsbygoogle||[]).push({{}});</script>' if CFG["ads"]["enabled"] and ADC else ""
    return f'<div class="ad-slot" data-slot="{slot}">{inner}</div>'
def follow_box():
    links = " ".join(f'<a href="{u}{"?sub_confirmation=1" if k=="YouTube" else ""}" rel="me" class="{"yt" if k=="YouTube" else ""}">{"Subscribe on YouTube" if k=="YouTube" else "Follow on " + k}</a>' for k, u in SOCIAL.items())
    return f'<div class="card"><b>New fat-loss tips every day. Follow danfitnz everywhere:</b><div class="social" style="margin-top:10px">{links}</div></div>'

def bc(items):
    return {"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": n, "item": u} for i, (n, u) in enumerate(items)]}

HUB = {"meal": ("recipes", "High-Protein Desi Recipes"), "workout": ("workouts", "Workouts"),
       "tips": ("fat-loss-tips", "Fat Loss Tips"), "myth": ("fat-loss-tips", "Fat Loss Tips")}
SEO = {
 "3-fat-loss-myths": "3 Fat Loss Myths That Keep You Stuck (and What Actually Works)",
 "3-gym-myths-beginners-believe": "3 Gym Myths Beginners Believe (Busted)",
 "3-cardio-myths": "3 Cardio Myths: You Don't Need Hours on the Treadmill",
 "3-food-myths": "3 Food Myths That Make Dieting Harder",
 "3-supplement-myths": "3 Supplement Myths That Waste Your Money",
 "3-progress-myths": "3 Progress Myths That Make People Quit",
 "5-easy-ways-to-eat-more-protein": "5 Easy Ways to Eat More Protein (Without Shakes)",
 "why-your-weight-jumped-overnight": "Why Your Weight Jumped Overnight (It's Not Fat)",
 "how-to-find-your-calorie-deficit": "How to Find Your Calorie Deficit: The Simple Way",
 "4-ways-to-walk-more-without-trying": "4 Easy Ways to Walk More Steps Every Day",
 "stop-doing-this-in-the-gym": "Gym Mistakes That Kill Your Progress",
 "what-25-30g-protein-looks-like": "What 25–30g of Protein Looks Like in Real Food",
 "fat-loss-stalled-check-these-4": "Fat Loss Stalled? Check These 4 Things First",
 "sleep-better-lose-fat-easier": "Sleep Better, Lose Fat Easier: The Skipped Fat-Loss Habit",
 "smarter-takeaway-picks": "Smarter Takeaway Picks for Fat Loss",
 "if-i-started-from-zero-again": "Starting Your Fitness Journey? What I'd Do From Zero",
 "20-min-home-fat-burner": "20-Minute Home Fat Burner Workout (No Equipment)",
 "beginner-dumbbell-full-body": "Beginner Dumbbell Full Body Workout (30 Minutes)",
 "10-min-desk-worker-reset": "10-Minute Desk Worker Reset Workout",
 "leg-day-for-beginners": "Leg Day for Beginners: 40-Minute Gym Workout",
 "push-day-workout": "Push Day Workout: Chest, Shoulders and Triceps",
 "pull-day-workout": "Pull Day Workout: Back and Biceps",
 "core-workout-no-crunches": "10-Minute Core Workout With No Crunches",
}
pages = []

for i, r in enumerate(REELS):
    t = r["type"]
    if t not in HUB: continue
    raw = " ".join(r["title"])
    hub, hubname = HUB[t]
    hook = clean(r["hook"])
    if hook and hook[-1] not in ".!?": hook += "."
    if t == "meal":
        kcal, prot = r["macros"]; kc = re.sub(r"\D", "", kcal); pg = re.sub(r"\D", "", prot)
        name = tcase(raw)
        title = f"{name} Recipe ({prot} Protein, {kcal} kcal) | danfitnz"
        desc = f"{hook} Easy {name.lower()} recipe for fat loss: about {kc} kcal and {pg}g protein {r['serves'].split('·')[0].strip()}. Simple ingredients, step-by-step method."
        slug = slugify(name)
        ing = "".join(f"<li>{E(x)}</li>" for x in r["ingredients"])
        steps = "".join(f"<li>{E(x)}</li>" for x in r["steps"])
        body = f"""<p class="meta"><a href="/{hub}/">{hubname}</a></p><h1>{E(name)}</h1><p class="lead">{E(hook)} A high-protein, lower-calorie recipe that fits a fat-loss diet.</p>
<div class="macros"><div class="macro"><b>{E(kcal)}</b><span>CALORIES</span></div><div class="macro lime"><b>{E(prot)}</b><span>PROTEIN</span></div></div><p class="meta">{E(r['serves'])} · nutrition is approximate</p>
<h2>Ingredients</h2><ul>{ing}</ul><h2>Method</h2><ol>{steps}</ol>
<h2>Why it works for fat loss</h2><p>Protein keeps you full for longer and helps you hold on to muscle while you're in a calorie deficit. This recipe gets you about {pg}g of protein for roughly {kc} calories, so you can enjoy great flavour while losing fat. Serve it with salad or a small portion of rice or roti to fit your daily calories.</p>
{follow_box()}"""
        sch = [{"@type": "Recipe", "name": name, "description": desc, "author": {"@id": BASE + "/#org"}, "datePublished": TODAY,
                "image": BASE + "/logo.png", "recipeCuisine": r.get("cuisine_label", "Pakistani / Indian"), "recipeCategory": "Main course",
                "keywords": f"high protein, fat loss, {r.get('cuisine', 'desi')}, {name.lower()}", "recipeYield": r["serves"].split("serves")[-1].strip() + " servings" if "serves" in r["serves"] else "1 serving",
                "nutrition": {"@type": "NutritionInformation", "calories": f"{kc} calories", "proteinContent": f"{pg} g"},
                "recipeIngredient": r["ingredients"], "recipeInstructions": [{"@type": "HowToStep", "text": s} for s in r["steps"]]}]
    elif t == "workout":
        name = tcase(raw); sub = clean(r["sub"]); slug = slugify(name); name = SEO.get(slug, name)
        title = f"{name} | danfitnz"
        desc = f"{hook} {name} ({sub}): exercises, sets and reps, plus how to progress. Beginner friendly."
        rows = "".join(f"<tr><td>{E(a)}</td><td class='n'>{E(b)}</td></tr>" for a, b in r["items"])
        body = f"""<p class="meta"><a href="/{hub}/">{hubname}</a></p><h1>{E(name)}</h1><p class="lead">{E(hook)} <span class="tag">{E(sub)}</span></p>
<h2>The workout</h2><table><tr><th>Exercise</th><th>Sets / reps</th></tr>{rows}</table><p><b>{E(clean(r['footer']))}</b></p>
<h2>How to do it</h2><ol><li>Warm up for 5 minutes: brisk walk, arm circles and a few bodyweight squats.</li><li>Do the exercises in order with good form. Slow down rather than rushing reps.</li><li>Rest as listed, then repeat for the number of rounds or sets shown.</li><li>Progress each week by adding one rep, a little weight, or one extra round.</li></ol>
<p class="note">Stop if anything hurts (not the same as feeling the burn). Pair this workout with a small calorie deficit and enough protein for fat loss.</p>
{follow_box()}"""
        sch = [{"@type": "HowTo", "name": name, "description": desc, "totalTime": None,
                "step": [{"@type": "HowToStep", "name": a, "text": f"{a}: {b}"} for a, b in r["items"]]}]
        sch[0].pop("totalTime")
    elif t == "myth":
        name = tcase(raw); sub = clean(r.get("sub", "")); slug = slugify(name); name = SEO.get(slug, name)
        title = f"{name} | danfitnz"
        desc = f"{hook} {name}, and what actually works for fat loss instead."
        secs = "".join(f"<h2>Myth {k + 1}: {E(m)}</h2><p><span class='fact'>THE FACT</span><br>{E(f)}</p>" for k, (m, f) in enumerate(r["items"]))
        body = f"""<p class="meta"><a href="/{hub}/">{hubname}</a></p><h1>{E(name)}</h1><p class="lead">{E(hook)}</p>{secs}
<h2>The bottom line</h2><p>Fat loss comes down to a consistent calorie deficit, enough protein, strength training and good sleep. Ignore the shortcuts and stick to the basics for 8–12 weeks.</p>{follow_box()}"""
        sch = [{"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": f"Is it true that {m[0].lower() + m[1:]}?",
                 "acceptedAnswer": {"@type": "Answer", "text": f"No. {f}"}} for m, f in r["items"]]}]
    else:  # tips
        name = tcase(raw); sub = clean(r.get("sub", "")); slug = slugify(name); name = SEO.get(slug, name)
        title = f"{name} | danfitnz"
        desc = f"{hook} {name}: {sub}. Simple, practical fat-loss advice from danfitnz."
        secs = "".join(f"<h2>{k + 1}. {E(a)}</h2><p>{E(b)}</p>" for k, (a, b) in enumerate(r["items"]))
        body = f"""<p class="meta"><a href="/{hub}/">{hubname}</a></p><h1>{E(name)}</h1><p class="lead">{E(hook)} <span class="tag">{E(sub)}</span></p>{secs}{follow_box()}"""
        sch = [{"@type": "Article", "headline": name, "description": desc, "author": {"@id": BASE + "/#org"}, "publisher": {"@id": BASE + "/#org"}, "datePublished": TODAY}]
    path = f"{hub}/{slug}/"
    sch.append(bc([("Home", BASE + "/"), (hubname, f"{BASE}/{hub}/"), (name, f"{BASE}/{path}")]))
    page(path, title, desc[:158], body, sch, "article")
    pages.append(dict(path=path, name=name, hub=hub, desc=desc, type=t))

# hubs
HUBS = {"recipes": ("High-Protein Recipes for Fat Loss", "Easy high-protein meals with calories and protein for every serve: everyday Kiwi favourites, quick meal prep, global flavours and our signature desi recipes."),
        "workouts": ("Beginner Workouts for Fat Loss", "Simple home and gym workouts for beginners: full body, push, pull, legs and core, with sets and reps."),
        "fat-loss-tips": ("Fat Loss Tips and Myths", "Practical fat-loss tips and common diet and gym myths busted: protein, calorie deficit, cardio, sleep and more.")}
for h, (hn, hd) in HUBS.items():
    items = [p for p in pages if p["hub"] == h]
    grid = "".join(f'<a href="/{p["path"]}">{E(p["name"])}<small>{E(clean(p["desc"])[:90])}…</small></a>' for p in items)
    sch = [{"@type": "CollectionPage", "name": hn, "description": hd, "url": f"{BASE}/{h}/"},
           {"@type": "ItemList", "itemListElement": [{"@type": "ListItem", "position": k + 1, "url": f"{BASE}/{p['path']}", "name": p["name"]} for k, p in enumerate(items)]},
           bc([("Home", BASE + "/"), (hn, f"{BASE}/{h}/")])]
    page(f"{h}/", f"{hn} | danfitnz", hd, f"<h1>{E(hn)}</h1><p class='lead'>{E(hd)}</p><div class='grid'>{grid}</div>{follow_box()}", sch)

exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "extra.py")).read())
# home
latest = "".join(f'<a href="/{p["path"]}">{E(p["name"])}<small>{E(HUBS[p["hub"]][0])}</small></a>' for p in pages[:12])
home_body = f"""<h1>Simple fat loss for real life.</h1><p class="lead">danfitnz shares short, no-nonsense fitness videos from Auckland, New Zealand: fat-loss tips, myths busted, beginner workouts and high-protein recipes, from everyday meals to desi favourites. New videos every day, plus fresh guides on training, motivation, discipline and hormones like cortisol and dopamine.</p>
<a class="cta" href="{YT}?sub_confirmation=1">Subscribe on YouTube</a><a class="cta" href="/recipes/">See the recipes</a>
<h2>Free tools</h2><div class="grid"><a href="/tools/plan-builder/">Build my 7-day plan<small>Personal calories, protein, workouts and meals in 1 minute.</small></a><a href="/tools/calorie-deficit-calculator/">Calorie deficit calculator<small>Your maintenance and fat-loss calories.</small></a><a href="/ask/">Ask danfitnz<small>Type any question, get instant answers.</small></a></div>
<h2>Start here</h2><div class="grid"><a href="/recipes/">High-protein recipes<small>Everyday meals plus desi favourites like karahi and keema, with calories and protein.</small></a><a href="/workouts/">Beginner workouts<small>Home and gym plans with sets and reps.</small></a><a href="/fat-loss-tips/">Fat loss tips and myths<small>What actually works, minus the hype.</small></a></div>
<h2>Latest guides</h2><div class="grid">{"".join(f'<a href="/{b["path"]}">{E(b["name"])}<small>{E(CFG["categories"].get(b["cat"], ""))}</small></a>' for b in BLOG_LIST[:6])}</div><p><a href="/blog/">All guides →</a></p><h2>Quick tips</h2><div class="grid">{latest}</div>
<h2>What danfitnz believes</h2><p>Fat loss doesn't need extreme diets. Eat in a small calorie deficit, get enough protein, lift weights, walk more and sleep well, then repeat for months. Discipline beats motivation.</p>{follow_box()}"""
page("", "danfitnz: Fat Loss Tips, Beginner Workouts & High-Protein Desi Recipes (NZ)",
     "Short, simple fitness from Auckland, NZ: fat-loss tips, myths busted, beginner workouts and high-protein recipes with calories and protein.",
     home_body, [{"@type": "WebSite", "@id": BASE + "/#site", "name": "danfitnz", "url": BASE + "/", "publisher": {"@id": BASE + "/#org"}, "inLanguage": "en-NZ"}])

about = f"""<h1>About danfitnz</h1><p class="lead">danfitnz is a fitness brand from Auckland, New Zealand, built to make fat loss simple.</p>
<p>We make short videos and simple guides that help everyday people lose fat without extreme diets: practical tips, the most common myths busted, beginner-friendly workouts, and high-protein recipes that fit a fat-loss plan, from everyday Kiwi meals to our signature desi (Pakistani and Indian) dishes.</p>
<h2>Our approach</h2><ul><li>A small, sustainable calorie deficit</li><li>Enough protein at every meal</li><li>Strength training 3–4 times a week</li><li>Daily steps and good sleep</li><li>Consistency and discipline over motivation</li></ul>
<h2>Where to watch</h2><p>New videos every day on {", ".join(f'<a href="{u}">{k}</a>' for k, u in SOCIAL.items())}.</p>
<p class="note">Content is general information, not medical advice. Nutrition values are approximate.</p>"""
page("about/", "About danfitnz | Auckland, NZ", "danfitnz is a fitness brand from Auckland, New Zealand sharing fat-loss tips, beginner workouts and high-protein recipes, including desi favourites.", about,
     [{"@type": "AboutPage", "name": "About danfitnz", "url": BASE + "/about/"}])

# static files
open(f"{OUT}/favicon.svg", "w").write(LOGO.replace(' aria-hidden="true"', ' xmlns="http://www.w3.org/2000/svg"'))
src_icon = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.png")
if os.path.exists(src_icon): shutil.copy(src_icon, f"{OUT}/logo.png")
open(f"{OUT}/.nojekyll", "w").write("")
open(f"{OUT}/{CFG['indexnow_key']}.txt", "w").write(CFG["indexnow_key"])
open(f"{OUT}/today_urls.txt", "w").write("\n".join(TODAY_POSTS))
for v in ["google2057ddd5757c6f24.html"]:  # Google Search Console verification
    open(f"{OUT}/{v}", "w").write(f"google-site-verification: {v}")
open(f"{OUT}/404.html", "w").write(f'<!doctype html><meta charset="utf-8"><title>Not found | danfitnz</title><meta name="viewport" content="width=device-width,initial-scale=1"><body style="background:#0E0F12;color:#F5F5F5;font-family:system-ui;padding:40px"><h1>Page not found</h1><p><a style="color:#C6FF3D" href="/">Go to danfitnz home</a></p></body>')
urls = ["", "about/", *EXTRA_URLS, *[f"{h}/" for h in HUBS], *[p["path"] for p in pages]]
open(f"{OUT}/sitemap.xml", "w").write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
    "".join(f"<url><loc>{BASE}/{u}</loc><lastmod>{TODAY}</lastmod></url>\n" for u in urls) + "</urlset>\n")
bots = ["Googlebot", "Bingbot", "GPTBot", "OAI-SearchBot", "ChatGPT-User", "PerplexityBot", "ClaudeBot", "Claude-SearchBot", "Google-Extended", "Applebot", "Applebot-Extended", "CCBot", "DuckDuckBot"]
open(f"{OUT}/robots.txt", "w").write("".join(f"User-agent: {b}\nAllow: /\n\n" for b in bots) + f"User-agent: *\nAllow: /\n\nSitemap: {BASE}/sitemap.xml\n")
llms = [f"# danfitnz\n\n> Fitness brand from Auckland, New Zealand. Short daily videos and simple guides: fat-loss tips, myths busted, beginner workouts and high-protein recipes (everyday meals plus desi/Pakistani/Indian favourites) with calories and protein per serve. New video every day at 6:30pm NZ time.\n",
        "Core advice: small calorie deficit, enough protein, strength training 3–4x/week, daily steps, good sleep, consistency. Content is general information, not medical advice.\n",
        "## Channels\n" + "".join(f"- [{k}]({u})\n" for k, u in SOCIAL.items())]
for h, (hn, hd) in HUBS.items():
    llms.append(f"\n## {hn}\n" + "".join(f"- [{p['name']}]({BASE}/{p['path']}): {clean(p['desc'])[:140]}\n" for p in pages if p["hub"] == h))
llms.append("\n## Free tools\n" + "".join(f"- [{t['name']}]({BASE}/{t['path']}): {t['desc']}\n" for t in TOOLS_LIST) + f"- [Ask danfitnz]({BASE}/ask/): instant answers from danfitnz guides\n")
llms.append("\n## Blog\n" + "".join(f"- [{b['name']}]({BASE}/{b['path']}): {b['desc']}\n" for b in BLOG_LIST))
open(f"{OUT}/llms.txt", "w").write("".join(llms))
print(len(pages), "articles;", len(urls), "urls ->", OUT)

# rewrite root-relative links for project-site hosting (e.g. /danfitnz/)
if PREFIX:
    for root, _, files in os.walk(OUT):
        for f in files:
            if f.endswith(".html"):
                fp = os.path.join(root, f); h = open(fp).read()
                h = re.sub(r'(href|src)="/(?!/)', lambda m: f'{m.group(1)}="{PREFIX}/', h)
                open(fp, "w").write(h)
